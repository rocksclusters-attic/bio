#include <signal.h>

int
main()
{
  int i = SIGUSR1;
  return 0;
}
