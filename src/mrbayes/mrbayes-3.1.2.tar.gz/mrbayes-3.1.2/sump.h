int      DoSump (void);
int      DoSumpParm (char *parmName, char *tkn);
int      GetHeaders (char *h, int *nHeaders);
void     Sort (MrBFlt *item, int count);
