package Data::Stag::null;

=head1 NAME

  Data::Stag::Arr2HTML

=head1 SYNOPSIS


=cut

=head1 DESCRIPTION

=head1 PUBLIC METHODS -

=cut

use strict;
use base qw(Data::Stag::BaseHandler);

use vars qw($VERSION);
$VERSION="0.11";

sub start_event {}
sub end_event {}
sub evbody {}


1;
