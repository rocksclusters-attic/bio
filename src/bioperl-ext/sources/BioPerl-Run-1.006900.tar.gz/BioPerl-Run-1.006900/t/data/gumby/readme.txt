Data in this folder is that which is included with the gumby distribution, modified by Prabhakar et al. from data from:

Chapman M.A., Donaldson I.J., Gilbert J., Grafham D., Rogers J., Green A.R., G?ttgens B. (2004). "Analysis of multiple genomic sequence 
alignments - a web resource, online tools, and lessons learned from analysis of four mammalian SCL loci". Genome Research. 14: 313-318.

Re-distributed with permission.

