/*

Copyright (c) 2003, The Institute for Genomic Research (TIGR), Rockville,
Maryland, U.S.A.  All rights reserved.

*/

#include "align_ext.h"

#include "comparisons_prot.h"

int
best_match_compare(
		register AbScoreRec **i,
		register AbScoreRec **j
	)
{
register AbScoreRec *reali = *i, *realj = *j;
register int  ret_val;

      if ((ret_val = reali->status - realj->status) != 0) {
              return(ret_val);
      } else if ((ret_val = realj->do_first - reali->do_first) != 0) {
              return(ret_val);
      } else if ((ret_val = reali->dist_from_med - realj->dist_from_med) != 0) {
              return(ret_val);
      } else if ((ret_val = realj->links - reali->links) != 0) {
              return(ret_val);
      } else {
              return((int)(realj->score - reali->score));
      }
}

int
duplicate_compare(
		register AbScoreRec **i,
		register AbScoreRec **j
	)
{
register AbScoreRec *reali = *i, *realj = *j;
register int  ret_val;
register int  max_i, max_j, min_i, min_j;

      max_i =  reali->con_seq_num;
      min_i = reali->seq_num;
      if (min_i > max_i) {
              ret_val = min_i;
              min_i = max_i;
              max_i = ret_val;
      }
      max_j =  realj->con_seq_num;
      min_j = realj->seq_num;
      if (min_j > max_j) {
              ret_val = min_j;
              min_j = max_j;
              max_j = ret_val;
      }
      if ((ret_val = max_i - max_j) != 0) {
              return(ret_val);
      } else if ((ret_val = min_i - min_j) != 0) {
              return(ret_val);
      } else {
              return((int)(realj->score - reali->score));
      }
}

int
clone_name_compare(
		register SeqRec *i,
		register SeqRec *j
	)
{
register int  ret_val;

      if ((ret_val = strcmp(i->clone_name, j->clone_name)) != 0) {
              return(ret_val);
      } else if ((ret_val = i->direction - j->direction) != 0) {
              return(ret_val);
      } else {
              return((int)(j->len - i->len));
      }
} 

int
seq_name_compare(
		register SeqRec **i,
		register SeqRec **j
	)
{
register SeqRec *reali = *i, *realj = *j;

	return(strcmp(realj->name, reali->name));
}

int
count_compare(
		register SeqRec **i,
		register SeqRec **j
	)
{
register SeqRec *reali = *i, *realj = *j;
      return(realj->norm_count - reali->norm_count);
}

int
IS_FORWARD(
		SeqRec *seqrec_ptr
	)
{
	reset_coords(seqrec_ptr, FALSE);
	return(((seqrec_ptr->left)->realpos < (seqrec_ptr->right)->realpos) ? FORWARD : REVERSE);
}

int
IS_FORWARD_no_reset(
		SeqRec *seqrec_ptr
)
{
	return(((seqrec_ptr->left)->realpos < (seqrec_ptr->right)->realpos) ? FORWARD : REVERSE);
}

