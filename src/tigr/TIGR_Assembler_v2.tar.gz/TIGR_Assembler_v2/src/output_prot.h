/*

Copyright (c) 2003, The Institute for Genomic Research (TIGR), Rockville,
Maryland, U.S.A.  All rights reserved.

*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <ctype.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <errno.h>
#include "typedefs.h"
#include "matrices.h"
#include "mat_output.h"

#ifndef OUTPUT_PROT_H
#define OUTPUT_PROT_H

void	output	(SeqRec *, SeqRec *, FILE *, FILE *, FILE *, FILE *,
		 char *, char *, char *, int, int, int, int, int, FILE *,
		 int, int, int, FILE *, int);
int	offset_compare	(register SeqRec **, register SeqRec **);
void	comp_seq	(ConPos *, int);

#endif
