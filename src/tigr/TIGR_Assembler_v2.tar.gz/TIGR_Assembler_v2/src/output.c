/*

Copyright (c) 2003, The Institute for Genomic Research (TIGR), Rockville,
Maryland, U.S.A.  All rights reserved.

*/

#include	"asmg_global_ext.h"
#include	"align_ext.h"
#include	"checksum_ext.h"
#include	"comparisons_ext.h"
#include	"consensus_ext.h"
#include	"rep_find_ext.h"

#include	"output_prot.h"

void
output(
		SeqRec *seqrec_array,
		SeqRec *seqrec_end,
		FILE *fp_fasta,
		FILE *fp_coverage,
		FILE *fp_ace,
		FILE *scratch,
		char *asm_prefix,
		char *align_dir,
		char *phd_dir,
		int singletons,
		int fasta_desc,
		int max_full_length,
		int reverse_translate,
		int num_32s,
		FILE *fp_rep,
		int max_span_len,
		int zap_questionable,
		int max_conflicts,
		FILE *fp_dump,
		int repeat_num_cutoff
	)
{
SeqRec	*best_seq, *seqrec_ptr, *pair_ptr;
int	asm_num;
ConPos	*align_ptr, *rem_align_ptr, *align_end;
int	rem_i, rem_last_pos, last_pos;
ConPos	*con_left_end, *con_right_end, *con_seq_ptr, *temp_ptr;
int	contig_seqs, unzapped_seqs;
SeqRec	**seqrec_sort, **sort_ptr, **sort_end;
int	redund, num_ambig, maybe_gap;
int	coverage, total, non_gap, gap, max_base, max_base2, index, index2;
float	ave_redund, perc_N, perc_1x, perc_doub;
int	asm_c2x_left, asm_c2x_right;
ConPos	*asm_c2x_left_ptr, *asm_c2x_right_ptr;
int	c2x_region;
int	c2x_1x_count, c2x_doub_count, c2x_count;
int	*realpos_to_pos, *rtpos_ptr;
unsigned long	seq_sum;
int	seq_len;
int	i_fasta, i_align, i_ace;
#ifdef	DEBUG
int	i_debug;
#endif
int	first_asm = TRUE;
int	first_contig = TRUE;
char	align_file[1024], phd_file[1024], chromat_file[1024];
FILE	*fp_align = NULL, *fp_phd = NULL;
int	print_align;
int	i, j;
int	pos;
char	out_char;
int	length;
int	min_good;
ConPos	*left_seq_ptr, *right_seq_ptr;
char	strand_val;
int	cons_val, quality_class;
int	forward, quality, ambig_cons;
int	qual_for, qual_rev, nonqual_for, nonqual_rev, qual_conflict, nonqual_conflict, num_confirm;
char	*ace_suffix;
char	*name, *db;
int	seq_left, seq_right, left_gapped, right_gapped, left, right, extra_left, extra_right;
ConPos	*left_seg, *right_seg;
SeqRec	*right_seqrec, *left_seqrec;
int	asmbl_len;
time_t	num_secs;
char	string_date[256], phd_time[256];
char	*char_ptr, *char2_ptr;
int	sum_asm_len;
int	status, link_status;
char	inputline[MAX_LINE];

	inputline[MAX_LINE - 2] = 0;

	if (fp_rep != NULL) {
	/* allocate memory for repeat detection */
		sum_asm_len = 0;
		for (best_seq = seqrec_array; best_seq < seqrec_end; best_seq++) {
			reset_coords(best_seq, TRUE);
			if (best_seq->status == COUNTED) {
				continue;
			}
			con_left_end = (best_seq->beg_contig)->latest;
			con_right_end = (best_seq->end_contig)->latest;
			sum_asm_len += ((con_right_end->left)->pos - (con_left_end->right)->pos);
			con_seq_ptr = con_left_end;
			do {
				(con_seq_ptr->best_seqrec)->status = COUNTED;
				con_seq_ptr = con_seq_ptr->best_seg;
			} while (con_seq_ptr != con_left_end);
		}
		if ((sum_asm_len > num_32s) && (num_32s > 0)) {
			sum_asm_len = num_32s;
		}
	
		init_asm_32mers(sum_asm_len);
	
	/* load 32mers for this contig for repeat detection */
		for (best_seq = seqrec_array; best_seq < seqrec_end; best_seq++) {
			if (best_seq->status == LOADED) {
				continue;
			}
			con_left_end = (best_seq->beg_contig)->latest;
			con_right_end = (best_seq->end_contig)->latest;
			con_seq_ptr = con_left_end;
			contig_seqs = 0;
			do {
				contig_seqs++;
				(con_seq_ptr->best_seqrec)->status = LOADED;
				con_seq_ptr = con_seq_ptr->best_seg;
			} while (con_seq_ptr != con_left_end);
			if (contig_seqs > repeat_num_cutoff) {
				load_asm_32mers(con_left_end, con_right_end);
			}
		}
	}

	asm_num = 0;
	for (best_seq = seqrec_array; best_seq < seqrec_end; best_seq++) {
		if (best_seq->status == DONE) {
			continue;
		}
		reset_coords(best_seq, FALSE);
		asm_num++;
		con_left_end = (best_seq->beg_contig)->latest;
		con_right_end = (best_seq->end_contig)->latest;
		con_seq_ptr = con_left_end;
		contig_seqs = 0;
		do {
			contig_seqs++;
			con_seq_ptr = con_seq_ptr->best_seg;
		} while (con_seq_ptr != con_left_end);
		if (reverse_translate || ((contig_seqs == 1) && (!IS_FORWARD_no_reset(best_seq)))) {
#ifdef DEBUG
			fprintf(stderr, "revcomp_contig\n");
			fflush(NULL);
#endif
			revcomp_contig((best_seq->end_contig)->latest);
			temp_ptr = best_seq->beg_contig;
			best_seq->beg_contig = best_seq->end_contig;
			best_seq->end_contig = temp_ptr;
			con_left_end = (best_seq->beg_contig)->latest;
			con_right_end = (best_seq->end_contig)->latest;
			con_seq_ptr = con_left_end;
		}

		if (fp_rep != NULL) {
			/* find 32mers for this contig for repeat detection */
			find_asm_32mers(con_left_end, con_right_end, asm_num, fp_rep, seqrec_array, max_span_len);
		}
		if (contig_seqs && ((seqrec_sort = (SeqRec **)malloc(contig_seqs * sizeof(*seqrec_sort))) == NULL)) {
			fprintf(stderr, "Out of Memory for seqrec_sort\n");
			exit(1);
		}
		sort_ptr = seqrec_sort;
		sort_end = sort_ptr + contig_seqs;
		do {
			*sort_ptr++ = con_seq_ptr->best_seqrec;
			con_seq_ptr = con_seq_ptr->best_seg;
		} while (con_seq_ptr != con_left_end);
		if (sort_ptr != sort_end) {
			fprintf(stderr, "ERROR: number of sequences in contig is inconsistent!\n");
			exit(1);
		}

		last_pos = 0;
		num_ambig = 0;
		maybe_gap = FALSE;
		asm_c2x_left_ptr = NULL;
		asm_c2x_right_ptr = NULL;
		for (con_seq_ptr = con_left_end->right; con_seq_ptr != con_right_end; con_seq_ptr->realpos = last_pos++, con_seq_ptr = con_seq_ptr->right) {
			total = (int)con_seq_ptr->total;
			coverage = (int)con_seq_ptr->coverage;
			if ((asm_c2x_left_ptr == NULL) && (coverage > 1)) {
				asm_c2x_left_ptr = con_seq_ptr;
				asm_c2x_right_ptr = con_seq_ptr;
			} else if (coverage > 1) {
				asm_c2x_right_ptr = con_seq_ptr;
			}
			max_base = (int)con_seq_ptr->base[0];
			index = 0;
			max_base2 = (int)con_seq_ptr->base[1];
			index2 = 1;
			for (j = 1; j < NUM_BASES; j++) {
				if ((int)con_seq_ptr->base[j] > max_base) {
					max_base2 = max_base;
					index2 = index;
					max_base = (int)con_seq_ptr->base[j];
					index = j;
				} else if ((int)con_seq_ptr->base[j] > max_base2) {
					max_base2 = (int)con_seq_ptr->base[j];
					index2 = j;
				}
			}
			gap = (int)con_seq_ptr->base[DNA_GAP];
			non_gap = total - gap;
			if (gap >= non_gap) {
				if (!maybe_gap && ((3 * gap) > (2 * total))) {
					maybe_gap = FALSE;
				} else {
					maybe_gap = TRUE;
				}
				con_seq_ptr->cons_val = '-';
			} else if ((!maybe_gap) && ((3 * max_base) > (2 * total))) {
				con_seq_ptr->cons_val = trans_toupper[index];
			} else {
				maybe_gap = FALSE;
				num_ambig++;
				if ((max_base2 > gap) && ((2 * max_base2) >= max_base) && (max_base2 >= (2 * (non_gap - (max_base + max_base2))))) {
					con_seq_ptr->cons_val = trans_tolower[ambiguity[index][index2]];
				} else if ((2 * max_base) > total) {
					con_seq_ptr->cons_val = trans_tolower[index];
				} else {
					con_seq_ptr->cons_val = trans_tolower[DNA_XN];
				}
			}
		}
		if ((realpos_to_pos = (int *)malloc((unsigned)(((2 * max_full_length) + last_pos) * sizeof(*realpos_to_pos)))) == NULL) {
			fprintf(stderr, "ERROR: Could not allocate memory for realpos_to_pos\n");
			exit(1);
		}
		if (fp_fasta != NULL) {
			if (contig_seqs == 1) {
				fprintf(fp_fasta, ">%s %s_%d\n", best_seq->name, asm_prefix, asm_num);
			} else {
				fprintf(fp_fasta, ">%s_%d\n", asm_prefix, asm_num);
			}
			i_fasta = 0;
		}
		if ((fp_ace != NULL) && (contig_seqs > 1)) {
			fprintf(fp_ace, "\n\nDNA Contig%d\n", asm_num);
			i_ace = 0;
		}
		if ((contig_seqs > 1) || singletons) {
			if (!first_contig) {
				fputc('|', stdout);
				fputc('\n', stdout);
			}
			first_contig = FALSE;
			fprintf(stdout, "sequence\t");
		}
		for (pos = - max_full_length, rtpos_ptr = realpos_to_pos, j = 0; j < max_full_length; rtpos_ptr++, j++) {
			*rtpos_ptr = ++pos;
		}
		pos = 0;
		redund = 0;
		for (con_seq_ptr = con_left_end->right; con_seq_ptr != con_right_end; con_seq_ptr = con_seq_ptr->right, rtpos_ptr++) {
			out_char = con_seq_ptr->cons_val;
			if (out_char == '-') {
				if (pos > 0) {
					con_seq_ptr->pos = pos;
					*rtpos_ptr = pos;
				} else {
					con_seq_ptr->pos = 1;
					*rtpos_ptr = 1;
				}
				if ((fp_ace != NULL) && (contig_seqs > 1)) {
					if (i_ace >= ACE_ROW_LEN) {
						i_ace = 0;
						fputc((int)'\n', fp_ace);
					}
					fputc((int)'*', fp_ace);
					i_ace++;
				}
			} else {
				if ((contig_seqs > 1) || singletons) {
					fputc((int)out_char, stdout);
				}
				if (fp_fasta != NULL) {
					if (i_fasta >= ROW_LEN) {
						i_fasta = 0;
						fputc((int)'\n', fp_fasta);
					}
					fputc((int)out_char, fp_fasta);
					i_fasta++;
				}
				if ((fp_ace != NULL) && (contig_seqs > 1)) {
					if (i_ace >= ACE_ROW_LEN) {
						i_ace = 0;
						fputc((int)'\n', fp_ace);
					}
					fputc((int)out_char, fp_ace);
					i_ace++;
				}
				redund += con_seq_ptr->coverage;
				con_seq_ptr->pos = ++pos;
				*rtpos_ptr = pos;
#ifdef DEBUG
				fflush(NULL);
#endif
			}
		}
		if (fp_fasta != NULL) {
			fputc((int)'\n', fp_fasta);
		}
		for (j = 0; j < max_full_length; rtpos_ptr++, j++) {
			*rtpos_ptr = ++pos;
		}
		rtpos_ptr = realpos_to_pos + max_full_length;
		for (sort_ptr = seqrec_sort; sort_ptr < sort_end; sort_ptr++) {
			seqrec_ptr = *sort_ptr;
			length = seqrec_ptr->len;
			reset_coords(seqrec_ptr, TRUE);
			forward = IS_FORWARD_no_reset(seqrec_ptr);
			if (forward) {
				pos = (seqrec_ptr->left)->realpos;
				align_ptr = seqrec_ptr->align + seqrec_ptr->align_left;
				align_end = seqrec_ptr->align + seqrec_ptr->align_right;
			} else {
				pos = (seqrec_ptr->right)->realpos;
				comp_seq(seqrec_ptr->align, length);
				align_ptr = seqrec_ptr->align + seqrec_ptr->align_right;
				align_end = seqrec_ptr->align + seqrec_ptr->align_left;
			}
			if (pos >= 0) {
				seqrec_ptr->offset = pos;
			} else {
				fprintf(stderr, "ERROR: impossible alignment position %d!\n", pos);
				exit(1);
			}
			con_seq_ptr = align_ptr->latest;
#ifdef FULL_DEBUG
			fprintf(stderr, "gap_fill: %s, offset %d, seq_pos %d c%d %s\n", seqrec_ptr->name, pos, (align_ptr - seqrec_ptr->align) + 1, con_seq_ptr, (con_seq_ptr->best_seqrec)->name);
			fflush(NULL);
#endif
			while (align_ptr != align_end) {
				min_good = align_ptr->init_good;
				if (forward) {
					align_ptr++;
				} else {
					align_ptr--;
				}
				if (min_good > align_ptr->init_good) {
					min_good = align_ptr->init_good;
				}
				con_seq_ptr = con_seq_ptr->right;
				right_seq_ptr = align_ptr->latest;
#ifdef FULL_DEBUG
				fprintf(stderr, "c%dr%dd%d\n", con_seq_ptr, right_seq_ptr, align_ptr - align_end);
				fflush(NULL);
#endif
				while (con_seq_ptr != right_seq_ptr) {
#ifdef DEBUG
					if (con_seq_ptr == NULL) {
						fprintf(stderr, "Impossible con_seq_ptr\n");
						exit(1);
					}
#endif
					if ((left_seq_ptr = (ConPos *)malloc(sizeof(*left_seq_ptr))) == NULL) {
						fprintf(stderr, "Out of Memory for left_seq_ptr(new gap)\n");
						exit(1);
					}
					left_seq_ptr->init_good = min_good;
					left_seq_ptr->init_val = DNA_GAP;
					left_seq_ptr->best_seqrec = seqrec_ptr;
					left_seq_ptr->best_seg = con_seq_ptr->best_seg;
					con_seq_ptr->best_seg = left_seq_ptr;
					con_seq_ptr = con_seq_ptr->right;
#ifdef FULL_DEBUG
					fprintf(stderr, "%d\n", con_seq_ptr);
					fflush(NULL);
#endif
				}
			}
		}
		qsort((char *)seqrec_sort, (size_t)(contig_seqs), sizeof(*seqrec_sort), offset_compare);
		if ((contig_seqs > 1) || singletons) {
			if ((fp_ace != NULL) && (contig_seqs > 1)) {
				fprintf(fp_ace, "\n\n\nBaseQuality Contig%d", asm_num);
				i_ace = ACE_ROW_LEN;
			}
			fprintf(stdout, "\nlsequence\t");
			for (con_seq_ptr = con_left_end->right; con_seq_ptr != con_right_end; con_seq_ptr = con_seq_ptr->right) {
				fputc((int)con_seq_ptr->cons_val, stdout);
			}
			fprintf(stdout, "\nquality\t0x");
#ifdef DEBUG
			i_debug = ROW_LEN;
			fprintf(stderr, "quality");
			fflush(NULL);
#endif
			for (con_seq_ptr = con_left_end->right; con_seq_ptr != con_right_end; con_seq_ptr = con_seq_ptr->right) {
				cons_val = trans_char[(int)con_seq_ptr->cons_val];
				temp_ptr = con_seq_ptr;
				qual_for = FALSE;
				qual_rev = FALSE;
				nonqual_for = FALSE;
				nonqual_rev = FALSE;
				qual_conflict = FALSE;
				nonqual_conflict = FALSE;
				num_confirm = 0;
				ambig_cons = (cons_val > NUM_BASES);
				do {
					forward = IS_FORWARD(temp_ptr->best_seqrec);
					quality = (temp_ptr->init_good >= QUALITY_CUTOFF);
					if ((temp_ptr->init_val == cons_val) && (!ambig_cons)) {
						num_confirm++;
						if (quality) {
							if (forward) {
								qual_for = TRUE;
							} else { /*reverse*/
								qual_rev = TRUE;
							}
						} else { /*nonquality*/
							if (forward) {
								nonqual_for = TRUE;
							} else { /*reverse*/
								nonqual_rev = TRUE;
							}
						}
					} else if (conflict[temp_ptr->init_val][cons_val]) { /*conflict*/
						if (quality) {
							qual_conflict = TRUE;
							((temp_ptr->best_seqrec)->num_conflicts)++;
						} else { /*nonquality*/
							nonqual_conflict = TRUE;
						}
					} else if (ambig_cons && (con_seq_ptr->coverage > 1)) {
						((temp_ptr->best_seqrec)->num_conflicts)++;
					}
					temp_ptr = temp_ptr->best_seg;
				} while (temp_ptr != con_seq_ptr);
				if (ambig_cons) {/*ambiguity*/
					if (con_seq_ptr->coverage > 1) {
						quality_class = QUAL_AMBIG_MULTIPLE;
					} else {
						quality_class = QUAL_AMBIG_SINGLE;
					}
				} else if ((!qual_conflict) && (!nonqual_conflict)) {/*no conflict*/
					if ((qual_for) && (qual_rev)) {
						quality_class = QUAL_BOTH_NOCONFLICT;
					} else if (((qual_for) && (nonqual_rev)) || ((nonqual_for) && (qual_rev))) {
						quality_class = QUAL_NONQUAL_BOTH_NOCONFLICT;
					} else if (((qual_for) || (qual_rev)) && (num_confirm > 1)) {
						quality_class = QUAL_ONE_CONFIRM_NOCONFLICT;
					} else if ((nonqual_for) && (nonqual_rev)) {
						quality_class = NONQUAL_BOTH_NOCONFLICT;
					} else if (num_confirm > 1) {
						quality_class = NONQUAL_ONE_CONFIRM_NOCONFLICT;
					} else if ((qual_for) || (qual_rev)) {
						quality_class = QUAL_SINGLE;
					} else {
						quality_class = NONQUAL_SINGLE;
					}
				} else if (qual_conflict) {/*quality conflict*/
					if ((qual_for) && (qual_rev)) {
						quality_class = QUAL_BOTH_QCONFLICT;
					} else if (((qual_for) && (nonqual_rev)) || ((nonqual_for) && (qual_rev))) {
						quality_class = QUAL_NONQUAL_BOTH_QCONFLICT;
					} else if (((qual_for) || (qual_rev)) && (num_confirm > 1)) {
						quality_class = QUAL_ONE_CONFIRM_QCONFLICT;
					} else if ((nonqual_for) && (nonqual_rev)) {
						quality_class = NONQUAL_BOTH_QCONFLICT;
					} else if (num_confirm > 1) {
						quality_class = NONQUAL_ONE_CONFIRM_QCONFLICT;
					} else if ((qual_for) || (qual_rev)) {
						quality_class = QUAL_SINGLE_QCONFLICT;
					} else {
						seqrec_ptr = con_seq_ptr->best_seqrec;
						fprintf(stderr, "WARNING: Should never have a nonquality match with a quality conflict %s(%d)!\n", seqrec_ptr->name, (con_seq_ptr - seqrec_ptr->align) - seqrec_ptr->align_left);
						quality_class = NONQUAL_SINGLE_QCONFLICT;
					}
				} else {/*nonquality conflict*/
					if ((qual_for) && (qual_rev)) {
						quality_class = QUAL_BOTH_NQCONFLICT;
					} else if (((qual_for) && (nonqual_rev)) || ((nonqual_for) && (qual_rev))) {
						quality_class = QUAL_NONQUAL_BOTH_NQCONFLICT;
					} else if (((qual_for) || (qual_rev)) && (num_confirm > 1)) {
						quality_class = QUAL_ONE_CONFIRM_NQCONFLICT;
					} else if ((nonqual_for) && (nonqual_rev)) {
						quality_class = NONQUAL_BOTH_NQCONFLICT;
					} else if (num_confirm > 1) {
						quality_class = NONQUAL_ONE_CONFIRM_NQCONFLICT;
					} else if ((qual_for) || (qual_rev)) {
						quality_class = QUAL_SINGLE_NQCONFLICT;
					} else {
						quality_class = NONQUAL_SINGLE_NQCONFLICT;
					}
				}
				fprintf(stdout, "%02X", quality_class);
				if (fp_dump != NULL) {
					fprintf(fp_dump, "%d\t%d\t%d\t%d\t%d\t%d\t%c\t%d\n", con_seq_ptr->realpos + 1, con_seq_ptr->base[0], con_seq_ptr->base[1], con_seq_ptr->base[2], con_seq_ptr->base[3], con_seq_ptr->base[4], con_seq_ptr->cons_val, quality_class);
				}
#ifdef DEBUG
				if (i_debug >= ROW_LEN) {
					i_debug = 0;
					fputc((int)'\n', stderr);
				} else {
					fputc((int)' ', stderr);
				}
				fprintf(stderr, "%d", quality_class);
				i_debug++;
				fflush(NULL);
#endif
				con_seq_ptr->best_seg = (ConPos *)NULL;
				con_seq_ptr->best_seqrec = (SeqRec *)NULL;
				if ((fp_ace != NULL) && (contig_seqs > 1) && (cons_val != DNA_GAP)) {
					if (i_ace >= ACE_ROW_LEN) {
						i_ace = 0;
						fputc((int)'\n', fp_ace);
					} else {
						fputc((int)' ', fp_ace);
					}
					fprintf(fp_ace, "%d", 10 * (int)con_seq_ptr->cons_good);
					i_ace++;
				}
			}
			if (zap_questionable) {
				unzapped_seqs = 0;
				for (sort_ptr = seqrec_sort; sort_ptr < sort_end; sort_ptr++) {
					seqrec_ptr = *sort_ptr;
					status = seqrec_ptr->status;
					link_status = seqrec_ptr->link_status;
					if (seqrec_ptr->num_conflicts >= max_conflicts) {
						if (link_status == LINKED) {
							pair_ptr = seqrec_array + seqrec_ptr->pair;
							if ((pair_ptr->num_conflicts >= max_conflicts) || (pair_ptr->status == REP_CONTAIN)) {
								seqrec_ptr->status = ZAP_CONFLICT;
							} else {
								if (status == REP_CONTAIN) {
									seqrec_ptr->status = REP_LINKED;
								}
								unzapped_seqs++;
							}
						} else {
							seqrec_ptr->status = ZAP_CONFLICT;
						}
					} else if (status == REP_CONTAIN) {
						if (link_status == LINKED) {
							pair_ptr = seqrec_array + seqrec_ptr->pair;
							if (pair_ptr->num_conflicts < max_conflicts) {
								seqrec_ptr->status = REP_LINKED;
								unzapped_seqs++;
							}
						} else if (link_status == NO_MATE) {
							seqrec_ptr->status = REP_NO_MATE;
							unzapped_seqs++;
						}
					} else {
						unzapped_seqs++;
					}
				}
			}
			if ((contig_seqs > 1) && (*align_dir != '\0')) {
				if (first_asm) {
					first_asm = FALSE;
					if (mkdir(align_dir, (mode_t)0750) < 0) {
						if (errno == EEXIST) {
							sprintf(align_file, "/bin/rm -r %s", align_dir);
							system(align_file);
							if (mkdir(align_dir, (mode_t)0750) < 0) {
								fprintf(stderr, "ERROR: Could not make directory %s!\n", align_dir);
								exit(1);
							}
						} else {
							fprintf(stderr, "ERROR: Could not make directory %s!\n", align_dir);
							exit(1);
						}
					}
				}
				sprintf(align_file, "%s/%s_%d.align", align_dir, asm_prefix, asm_num);
				if (!(fp_align = fopen(align_file, "w"))) {
					fprintf(stderr, "ERROR: align output file \"%s\" is not writeable!\n", align_file);
					exit(1);
				}
				seq_sum = checkinit();
				seq_len = 0;
				for (con_seq_ptr = con_left_end->right; con_seq_ptr != con_right_end; con_seq_ptr = con_seq_ptr->right) {
					seq_sum = checkbase((int)con_seq_ptr->cons_val, seq_sum);
					seq_len++;
				}
				seq_sum = checkfinal(seq_sum);
				fprintf(fp_align, "##%s_%d %d %d bases, %lX checksum.\n", asm_prefix, asm_num, zap_questionable ? unzapped_seqs : contig_seqs, seq_len, seq_sum);
				i_align = 0;
			} else {
				fp_align = NULL;
			}
			for (con_seq_ptr = con_left_end->right; con_seq_ptr != con_right_end; con_seq_ptr = con_seq_ptr->right) {
				out_char = con_seq_ptr->cons_val;
				if (fp_align != NULL) {
					if (i_align >= ROW_LEN) {
						i_align = 0;
						fputc((int)'\n', fp_align);
					}
					fputc((int)out_char, fp_align);
					i_align++;
				}
				con_seq_ptr->cons_val = trans_char[(int)out_char];
			}
			if (fp_align != NULL) {
				fputc((int)'\n', fp_align);
			}
		} else {
			fp_align = NULL;
		}
		if ((fp_ace != NULL) && (contig_seqs > 1)) {
			fprintf(fp_ace, "\n\n\nSequence Contig%d", asm_num);
			for (sort_ptr = seqrec_sort; sort_ptr < sort_end; sort_ptr++) {
				seqrec_ptr = *sort_ptr;
				length = seqrec_ptr->len;
				forward = IS_FORWARD(seqrec_ptr);
				name = seqrec_ptr->name;
				if (forward) {
					ace_suffix = "";
					extra_left = seqrec_ptr->clear_left - 1;
					extra_right = seqrec_ptr->full_len - seqrec_ptr->clear_right;
					left = (seqrec_ptr->left)->realpos - (seqrec_ptr->align_left + extra_left);
					right = (seqrec_ptr->right)->realpos + (length - (seqrec_ptr->align_right + 1)) + extra_right;
				} else { /* REVERSE */
					ace_suffix = ".comp";
					extra_right = seqrec_ptr->clear_left - 1;
					extra_left = seqrec_ptr->full_len - seqrec_ptr->clear_right;
					right = (seqrec_ptr->left)->realpos + seqrec_ptr->align_left + extra_right;
					left = (seqrec_ptr->right)->realpos - ((length - (seqrec_ptr->align_right + 1)) + extra_left);
				}
				fprintf(fp_ace, "\nAssembled_from  %s%s  %d  %d", name, ace_suffix, rtpos_ptr[left], rtpos_ptr[right]);
				fprintf(fp_ace, "\nAssembled_from* %s%s  %d  %d", name, ace_suffix, left + 1, right + 1);
				if (forward) {
					for (i = 0, align_ptr = seqrec_ptr->align; (i < length) && (align_ptr->latest == (ConPos *)NULL); i++, align_ptr++);
				} else {
					for (i = 0, align_ptr = seqrec_ptr->align + (length - 1); (i < length) && (align_ptr->latest == (ConPos *)NULL); i++, align_ptr--);
				}
				if (i == length) {
					fprintf(stderr, "ERROR: alignment is NULL!\n");
					exit(1);
				}
				while ((i < length) && (align_ptr->latest != (ConPos *)NULL)) {
					con_seq_ptr = align_ptr->latest;
					if ((con_seq_ptr->best_seg == (ConPos *)NULL) && (align_ptr->init_val == con_seq_ptr->cons_val)) {
						last_pos = con_seq_ptr->pos;
						rem_i = i;
						rem_last_pos = last_pos;
						rem_align_ptr = align_ptr;
						for (; (i >= 0) && (con_seq_ptr != (ConPos *)NULL) && (last_pos == con_seq_ptr->pos) && (align_ptr->init_val == con_seq_ptr->cons_val); i--, last_pos--) {
							con_seq_ptr->best_seg = align_ptr;
							con_seq_ptr->best_seqrec = seqrec_ptr;
							if (forward) {
								align_ptr--;
							} else {
								align_ptr++;
							}
							con_seq_ptr = align_ptr->latest;
						}
						i = rem_i;
						last_pos = rem_last_pos;
						align_ptr = rem_align_ptr;
						con_seq_ptr = align_ptr->latest;
						for (; (i < length) && (con_seq_ptr != (ConPos *)NULL) && (last_pos == con_seq_ptr->pos) && (align_ptr->init_val == con_seq_ptr->cons_val); i++, last_pos++) {
							con_seq_ptr->best_seg = align_ptr;
							con_seq_ptr->best_seqrec = seqrec_ptr;
							if (forward) {
								align_ptr++;
							} else {
								align_ptr--;
							}
							con_seq_ptr = align_ptr->latest;
						}
					} else {
						i++;
						if (forward) {
							align_ptr++;
						} else {
							align_ptr--;
						}
					}
				}
			}
			for (con_seq_ptr = con_right_end->left; con_seq_ptr != con_left_end; con_seq_ptr = con_seq_ptr->left) {
				if ((right_seqrec = con_seq_ptr->best_seqrec) != (SeqRec *)NULL) {
					right_seg = left_seg = con_seq_ptr;
					break;
				}
			}
			for (; TRUE; con_seq_ptr = con_seq_ptr->left) {
				if ((con_seq_ptr == con_left_end) || ((left_seqrec = con_seq_ptr->best_seqrec) != (SeqRec *)NULL)) {
					if ((con_seq_ptr == con_left_end) || (left_seqrec != right_seqrec)) {
						if (IS_FORWARD(right_seqrec)) {
							ace_suffix = "";
							extra_left = right_seqrec->clear_left - 1;
							left = (left_seg->best_seg - right_seqrec->align) + 1 + extra_left;
							right = (right_seg->best_seg - right_seqrec->align) + 1 + extra_left;
							left_gapped = left + ((left_seg->realpos - (right_seqrec->left)->realpos) - (left_seg->pos - (right_seqrec->left)->pos));
							right_gapped = right + ((right_seg->realpos - (right_seqrec->left)->realpos) - (right_seg->pos - (right_seqrec->left)->pos));
						} else { /* REVERSE */
							ace_suffix = ".comp";
							extra_left = right_seqrec->full_len - right_seqrec->clear_right;
							length = right_seqrec->len;
							left = (length - (left_seg->best_seg - right_seqrec->align)) + extra_left;
							right = (length - (right_seg->best_seg - right_seqrec->align)) + extra_left;
							left_gapped = left + ((left_seg->realpos - (right_seqrec->right)->realpos) - (left_seg->pos - (right_seqrec->right)->pos));
							right_gapped = right + ((right_seg->realpos - (right_seqrec->right)->realpos) - (right_seg->pos - (right_seqrec->right)->pos));
						}
						name = right_seqrec->name;
						fprintf(fp_ace, "\nBase_segment  %d %d  %s%s  %d %d", left_seg->pos, right_seg->pos, name, ace_suffix, left, right);
						fprintf(fp_ace, "\nBase_segment* %d %d  %s%s  %d %d", left_seg->realpos + 1, right_seg->realpos + 1, name, ace_suffix, left_gapped, right_gapped);
						if (con_seq_ptr == con_left_end) {
							break;
						}
						right_seg = left_seg = con_seq_ptr;
						right_seqrec = left_seqrec;
					} else {
						left_seg = con_seq_ptr;
					}
				}
			}
		}
		pos = 0;
		c2x_region = FALSE;
		c2x_1x_count = 0;
		c2x_count = 0;
		asm_c2x_left = 0;
		asm_c2x_right = 0;
		for (con_seq_ptr = con_left_end->right; con_seq_ptr != con_right_end; con_seq_ptr = con_seq_ptr->right) {
			if (asm_c2x_left_ptr == con_seq_ptr) {
				c2x_region = TRUE;
			}
			if (con_seq_ptr->cons_val != DNA_GAP) {
				pos++;
				if (c2x_region) {
					con_seq_ptr->cons_val = 'N';
					if (c2x_count == 0) {
						asm_c2x_left = pos;
					}
					c2x_count++;
					if (con_seq_ptr->coverage == 1) {
						c2x_1x_count++;
					}
				}
			}
			if (asm_c2x_right_ptr == con_seq_ptr) {
				c2x_region = FALSE;
				asm_c2x_right = pos;
			}
		}
		asmbl_len = pos;
		if (asmbl_len > 0) {
			ave_redund = (float) redund / (float) asmbl_len;
			perc_N = ((float) num_ambig * 100.0) / (float) asmbl_len;
		} else {
			ave_redund = 0.0;
			perc_N = 0.0;
		}
		num_secs = time((time_t *)NULL);
		strftime(string_date, 100, "%D %T", localtime(&num_secs));
		if ((contig_seqs > 1) || singletons) {
			fprintf(stdout, "\nasmbl_id\t%d\nseq_id\t\ncom_name\t\ntype\t\nmethod\t%s\ned_status\t\nredundancy\t%4.2f\nperc_N\t%4.2f\nseq#\t%d\nfull_cds\t\ncds_start\t\ncds_end\t\ned_pn\t%s\ned_date\t%s\ncomment\t\nframeshift\t\n", asm_num, "asmg", ave_redund, perc_N, contig_seqs, "GRA", string_date);
		}
#ifdef DEBUG
		fprintf(stderr, "\nasmbl_id\t%d\nseq_id\t\ncom_name\t\ntype\t\nmethod\t%s\ned_status\t\nredundancy\t%4.2f\nperc_N\t%4.2f\nseq#\t%d\nfull_cds\t\ncds_start\t\ncds_end\t\ned_pn\t%s\ned_date\t%s\ncomment\t\nframeshift\t\n", asm_num, "asmg", ave_redund, perc_N, contig_seqs, "GRA", string_date);
		fflush(NULL);
#endif
		if ((contig_seqs > 1) || singletons) {
			for (sort_ptr = seqrec_sort; sort_ptr < sort_end; sort_ptr++) {
				seqrec_ptr = *sort_ptr;
				forward = IS_FORWARD(seqrec_ptr);
				length = seqrec_ptr->len;
				if (forward) {
					ace_suffix = "";
					extra_left = seqrec_ptr->clear_left - 1;
					extra_right = seqrec_ptr->full_len - seqrec_ptr->clear_right;
					seq_left = seqrec_ptr->align_left + 1 + extra_left;
					seq_right = seqrec_ptr->align_right + 1 + extra_left;
					left = seq_left;
					right = seq_right;
					right_gapped = right + (((seqrec_ptr->right)->realpos - (seqrec_ptr->left)->realpos) - (seqrec_ptr->align_right - seqrec_ptr->align_left));
					left_seq_ptr = seqrec_ptr->left;
					right_seq_ptr = seqrec_ptr->right;
				} else { /* REVERSE */
					ace_suffix = ".comp";
					extra_right = seqrec_ptr->clear_left - 1;
					extra_left = seqrec_ptr->full_len - seqrec_ptr->clear_right;
					seq_right = seqrec_ptr->align_left + 1 + extra_right;
					seq_left = seqrec_ptr->align_right + 1 + extra_right;
					left = (length - seqrec_ptr->align_right) + extra_left;
					right = (length - seqrec_ptr->align_left) + extra_left;
					right_gapped = right + (((seqrec_ptr->left)->realpos - (seqrec_ptr->right)->realpos) - (seqrec_ptr->align_right - seqrec_ptr->align_left));
					left_seq_ptr = seqrec_ptr->right;
					right_seq_ptr = seqrec_ptr->left;
				}
				name = seqrec_ptr->name;
				db = seqrec_ptr->db;
				fprintf(stdout, "\nseq_name\t%s\nasm_lend\t%d\nasm_rend\t%d\nseq_lend\t%d\nseq_rend\t%d\nbest\t0\ncomment\t\ndb\t%s\noffset\t%d\nlsequence\t", name, left_seq_ptr->pos, right_seq_ptr->pos, seq_left, seq_right, db, seqrec_ptr->offset);
#ifdef DEBUG
				fprintf(stderr, "\nseq_num\t%d\nseq_name\t%s\nasm_lend\t%d\nasm_rend\t%d\nseq_lend\t%d\nseq_rend\t%d\nbest\t0\ncomment\t\ndb\t%s\noffset\t%d\n", seqrec_ptr - seqrec_array, name, left_seq_ptr->pos, right_seq_ptr->pos, seq_left, seq_right, db, seqrec_ptr->offset);
				fflush(NULL);
#endif
				if ((fp_ace != NULL) && (contig_seqs > 1)) {
					fprintf(fp_ace, "\n\nDNA %s%s\n", name, ace_suffix);
				}
				if (zap_questionable) {
					print_align = (fp_align != NULL) && (seqrec_ptr->status != REP_CONTAIN) && (seqrec_ptr->status != ZAP_CONFLICT);
				} else {
					print_align = (fp_align != NULL);
				}
				if (print_align) {
					fprintf(fp_align, "#%s%s%s", db, (*db == '\0') ? "" : "|", name);
				}
				fseek(scratch, seqrec_ptr->filepos, 0);
				fread(inputline, sizeof(*inputline), seqrec_ptr->full_len, scratch);
				if (!forward) {
					revcomp(inputline, seqrec_ptr->full_len);
				}
				for (i = 0, align_ptr = seqrec_ptr->align; (i < length); i++, align_ptr++) {
					con_seq_ptr = align_ptr->latest;
					if (fp_coverage != NULL) {
						if (con_seq_ptr != NULL) {
							strand_val = con_seq_ptr->cons_val;
							if (strand_val == 'N') {
								if (!forward) {
									con_seq_ptr->cons_val = 'R';
								} else {
									con_seq_ptr->cons_val = 'F';
								}
							} else if (((strand_val == 'F') && (!forward)) || ((strand_val == 'R') && (forward))) {
								con_seq_ptr->cons_val = 'B';
							}
						}
					}
				}
				if (forward) {
					for (i = 0, align_ptr = seqrec_ptr->align; (i < length) && (align_ptr->latest == (ConPos *)NULL); i++, align_ptr++);
				} else {
					for (i = 0, align_ptr = seqrec_ptr->align + (length - 1); (i < length) && (align_ptr->latest == (ConPos *)NULL); i++, align_ptr--);
				}
				if (i == length) {
					fprintf(stderr, "ERROR: alignment is NULL!\n");
					exit(1);
				}
				con_seq_ptr = align_ptr->latest;
				last_pos = con_seq_ptr->realpos;
				if (last_pos != seqrec_ptr->offset) {
					fprintf(stderr, "ERROR: alignment is inconsistent!\n");
					exit(1);
				}
				last_pos--;
				if (print_align) {
					if (seqrec_ptr->offset >= 0) {
						fprintf(fp_align, "(%d)", seqrec_ptr->offset);
					} else {
						fprintf(stderr, "ERROR: impossible alignment position %d!\n", seqrec_ptr->offset);
						exit(1);
					}
					if (!forward) {
						fprintf(fp_align, " [RC]");
					} else {
						fprintf(fp_align, " []");
					}
					rem_i = i;
					rem_last_pos = last_pos;
					rem_align_ptr = align_ptr;
					seq_sum = checkinit();
					seq_len = 0;
					for (j = 0, char_ptr = inputline + extra_left; j < i; j++, char_ptr++) {
						seq_sum = checkbase((int)*char_ptr, seq_sum);
						seq_len++;
					}
					for (; (i < length) && (align_ptr->latest != (ConPos *)NULL); i++, char_ptr++) {
						con_seq_ptr = align_ptr->latest;
						pos = con_seq_ptr->realpos;
						for (last_pos++; last_pos < pos; last_pos++) {
							seq_sum = checkbase((int)'-', seq_sum);
							seq_len++;
						}
						if (last_pos > pos) {
							fprintf(stderr, "ERROR: impossible alignment position %d-%d!\n", last_pos, pos);
						/*	exit(1);*/
						}
						seq_sum = checkbase((int)*char_ptr, seq_sum);
						seq_len++;
						if (forward) {
							align_ptr++;
						} else {
							align_ptr--;
						}
					}
					for (; i < length; i++, char_ptr++) {
						seq_sum = checkbase((int)*char_ptr, seq_sum);
						seq_len++;
					}
					seq_sum = checkfinal(seq_sum);
					fprintf(fp_align, " %d bases, %lX checksum. {%d %d} <%d %d>\n", seq_len, seq_sum, seq_left, seq_right, left_seq_ptr->pos, right_seq_ptr->pos);
					i = rem_i;
					last_pos = rem_last_pos;
					align_ptr = rem_align_ptr;
					i_align = 0;
				}
				if ((fp_ace != NULL) && (contig_seqs > 1)) {
					i_ace = 0;
					for (j = 0, char_ptr = inputline; j < extra_left; j++, char_ptr++) {
						if (i_ace >= ACE_ROW_LEN) {
							i_ace = 0;
							fputc((int)'\n', fp_ace);
						}
						fputc((int)trans_tolower[(int)*char_ptr], fp_ace);
						i_ace++;
					}
				}
				for (j = 0, char_ptr = inputline + extra_left; j < i; j++, char_ptr++) {
					if ((fp_ace != NULL) && (contig_seqs > 1)) {
						if (i_ace >= ACE_ROW_LEN) {
							i_ace = 0;
							fputc((int)'\n', fp_ace);
						}
						fputc((int)trans_tolower[(int)*char_ptr], fp_ace);
						i_ace++;
					}
				}
				for (; (i < length) && (align_ptr->latest != (ConPos *)NULL); i++, char_ptr++) {
					con_seq_ptr = align_ptr->latest;
					pos = con_seq_ptr->realpos;
					for (last_pos++; last_pos < pos; last_pos++) {
						if (print_align) {
							if (i_align >= ROW_LEN) {
								i_align = 0;
								fputc((int)'\n', fp_align);
							}
							fputc((int)'-', fp_align);
							i_align++;
						}
						fputc((int)'-', stdout);
						if ((fp_ace != NULL) && (contig_seqs > 1)) {
							if (i_ace >= ACE_ROW_LEN) {
								i_ace = 0;
								fputc((int)'\n', fp_ace);
							}
							fputc((int)'*', fp_ace);
							i_ace++;
						}
					}
					if (last_pos > pos) {
						fprintf(stderr, "ERROR: impossible alignment position %d-%d!\n", last_pos, pos);
						exit(1);
					}
					if (print_align) {
						if (i_align >= ROW_LEN) {
							i_align = 0;
							fputc((int)'\n', fp_align);
						}
						fputc((int)trans_toupper[(int)*char_ptr], fp_align);
						i_align++;
					}
					fputc((int)trans_toupper[(int)*char_ptr], stdout);
					if ((fp_ace != NULL) && (contig_seqs > 1)) {
						if (i_ace >= ACE_ROW_LEN) {
							i_ace = 0;
							fputc((int)'\n', fp_ace);
						}
						fputc((int)trans_toupper[(int)*char_ptr], fp_ace);
						i_ace++;
					}
					if (forward) {
						align_ptr++;
					} else {
						align_ptr--;
					}
				}
				for (; i < length; i++, char_ptr++) {
					if ((fp_ace != NULL) && (contig_seqs > 1)) {
						if (i_ace >= ACE_ROW_LEN) {
							i_ace = 0;
							fputc((int)'\n', fp_ace);
						}
						fputc((int)trans_tolower[(int)*char_ptr], fp_ace);
						i_ace++;
					}
				}
				if ((fp_ace != NULL) && (contig_seqs > 1)) {
					for (j = 0; j < extra_right; j++, char_ptr++) {
						if (i_ace >= ACE_ROW_LEN) {
							i_ace = 0;
							fputc((int)'\n', fp_ace);
						}
						fputc((int)trans_tolower[(int)*char_ptr], fp_ace);
						i_ace++;
					}
				}
				if (print_align) {
					fputc((int)'\n', fp_align);
				}
				fputc((int)'\n', stdout);
				if ((fp_ace != NULL) && (contig_seqs > 1)) {
					fprintf(fp_ace, "\n\nSequence %s%s\n", seqrec_ptr->name, ace_suffix);
					fprintf(fp_ace, "Clipping  %d %d\n", left, right);
					fprintf(fp_ace, "Clipping* %d %d\n", left, right_gapped);
					fprintf(fp_ace, "Description  ");
					if (*phd_dir != '\0') {
						sprintf(phd_file, "%s/%s.phd.1", phd_dir, seqrec_ptr->name);
						if (!(fp_phd = fopen(phd_file, "r"))) {
							fprintf(stderr, "WARNING: phd output file \"%s\" is not readable!\n", phd_file);
						}
					}
					if (fasta_desc && (seqrec_ptr->consed_filepos >= 0)) {
						fseek(scratch, seqrec_ptr->consed_filepos, 0);
						fgets(inputline, MAX_LINE, scratch);
						fputs(inputline, fp_ace);
					} else if (fp_phd != NULL) {
						strcpy(chromat_file, seqrec_ptr->name);
						strcpy(phd_time, string_date);
						while (fgets(inputline, MAX_LINE, fp_phd) != NULL) {
							if (strncmp(inputline, "CHROMAT_FILE: ", 14) == 0) {
								for (char_ptr = inputline + 14, char2_ptr = chromat_file; (*char_ptr != '\n') && (*char_ptr != '\0'); *char2_ptr++ = *char_ptr++);
								*char2_ptr = '\0';
							} else if (strncmp(inputline, "TIME: ", 6) == 0) {
								for (char_ptr = inputline + 6, char2_ptr = phd_time; (*char_ptr != '\n') && (*char_ptr != '\0'); *char2_ptr++ = *char_ptr++);
								*char2_ptr = '\0';
							} else if (strncmp(inputline, "BEGIN_DNA", 9) == 0) {
								break;
							}
						}
						fprintf(fp_ace, "CHROMAT_FILE %s PHD_FILE: %s.phd.1 TIME: %s", chromat_file, seqrec_ptr->name, phd_time);
					} else {
						fprintf(fp_ace, "CHROMAT_FILE %s PHD_FILE: %s.phd.1 TIME: %s", seqrec_ptr->name, seqrec_ptr->name, string_date);
					}
					if (fp_phd != NULL) {
						fclose(fp_phd);
					}
				}
				seqrec_ptr->status = DONE;
			}
		} else {
			for (sort_ptr = seqrec_sort; sort_ptr < sort_end; sort_ptr++) {
				seqrec_ptr = *sort_ptr;
				seqrec_ptr->status = DONE;
			}
		}
		if ((fp_ace != NULL) && (contig_seqs > 1)) {
			fprintf(fp_ace, "\n\n");
		}
		if (fp_coverage != NULL) {
			c2x_doub_count = 0;
			for (con_seq_ptr = asm_c2x_left_ptr; con_seq_ptr != NULL; con_seq_ptr = con_seq_ptr->right) {
				if (con_seq_ptr->cons_val == 'B') {
					c2x_doub_count++;
				}
				if (con_seq_ptr == asm_c2x_right_ptr) {
					break;
				}
			}
			if (c2x_count > 0) {
				perc_1x = ((float) c2x_1x_count * 100.0) / (float) c2x_count;
				perc_doub = ((float) c2x_doub_count * 100.0) / (float) c2x_count;
			} else {
				perc_1x = 0.0;
				perc_doub = 0.0;
			}
			fprintf(fp_coverage, "%s\t%d\t%d\t%d\t%d\t%d\t%4.2f\t%4.2f\t%4.2f\n", asm_prefix, asm_num, contig_seqs, asmbl_len, asm_c2x_left, asm_c2x_right, perc_N, perc_1x, perc_doub);
		}
		free(seqrec_sort);
		free(realpos_to_pos);
		if (fp_align != NULL) {
			fclose(fp_align);
		}
	}
	if (fp_rep != NULL) {
		free_32_store_asm();
	}
	return;
}
 
int
offset_compare(
		register SeqRec **i,
		register SeqRec **j
	)
{
register SeqRec *reali = *i, *realj = *j;

      return(reali->offset - realj->offset);
}


void
comp_seq(
		ConPos *left_end,
		int length
	)
{
int	i;

	for (i = 0; i < length; i++, left_end++) {
		left_end->init_val = trans_comp[left_end->init_val];
	}
	return;
}
