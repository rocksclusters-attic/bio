/*

Copyright (c) 2003, The Institute for Genomic Research (TIGR), Rockville,
Maryland, U.S.A.  All rights reserved.

*/

/*  typedefs.h include file */

#ifndef TYPEDEFS_H
#define TYPEDEFS_H

/* smith/waterman 2d array */

typedef struct simcell {
	int score;
	int max;
	unsigned short row;
	unsigned short col;
	short cur_match;
	unsigned short NorthGap;
	unsigned err_val;
	unsigned queue;
} SimCel;

/* 32 memory hashing function structs */

typedef struct quads {
	struct quads *next;
	unsigned seq_num;
	unsigned short pos;
} QuadHash;

typedef struct r32 {
	struct r32 *next_hash;
	struct quads *next;
	unsigned ident1;
	unsigned ident2;
	unsigned count;
	unsigned seq_num;
} R32Hash;

typedef struct r32asm {
	struct r32asm *next_hash;
	unsigned ident1;
	unsigned ident2;
	unsigned count;
} R32Asm;


/* weighted average */

typedef struct incmatrix {
	int base[5];
	int total;
	int init_val;
	unsigned good;
} IncMat;

typedef struct submatrix {
	int base[6];
} SubMat;

typedef struct scores {
	int extent;
	unsigned hits;
	unsigned short pos;
	unsigned short hit_pos;
	struct scores *next;
} ScoreRec;

typedef struct abbrev_scores {
	int dist_from_med;
	unsigned seq_num;
	unsigned con_seq_num;
#ifdef SHOWSTATS
	unsigned num_matches;
#endif
	unsigned order;
	struct abbrev_scores *next;
	unsigned short pos;
	unsigned short hit_pos;
	unsigned hits;
	int score;
	unsigned links;
	unsigned short do_first;
	char strand;
	char status;
} AbScoreRec;

struct entry; /* place holder for self referencing loop in SeqRec and ConPos */

#ifdef TIGR_EDITOR

typedef struct colpos {
	struct colpos *best_seg;
	short forward;
	char init_val;
	unsigned char init_good;
} ColPos;

typedef struct basepos {
	struct basepos *right;
	struct basepos *left;
	ColPos *best_seg;
	int pos;
	int realpos;
	unsigned short base[5];
	unsigned short total;
	unsigned short coverage;
	unsigned short quality_class;
	char cons_val;
	char init_val;
	unsigned char cons_good;
	unsigned char init_good;
} ConPos;

#else

/* 1 ConPos (consensus position) is allocated per nucleotide per sequence */ 
/* this is the major memeory usage in the tigr asembler */

typedef struct basepos {
	struct basepos *latest;		/* currency ??????		   */
	struct basepos *right;		/* next node in doubly linked list */
	struct basepos *left;		/* prev node in doubly linked list */
	struct basepos *best_seg;	/* points to head node in circular linked list */
	struct entry *best_seqrec;	/* pointer to best seq record (below) */
	int pos;			/* counter for nucleotides - gaps -  mem save ? */
	int realpos;			/* counter for nucleotides - no gaps -mem save ? */
	unsigned short base[5];		/* counts for number of the A,C,T,G,and gaps  */
	unsigned short total;		/* total num of bases = A+C+T+G+gaps ???  */
	unsigned short coverage;	/* depth of coverage at this nt base */
	char cons_val;			/* quality score/value for nt (0,15) */
	char init_val;			/* initial/first seen nt sequence */
	unsigned char cons_good;	/* quality code (0,60) */
	unsigned char init_good;	/* quality code (1,5) */
} ConPos;

#endif


/* one SeqRec is allocated per sequence */

typedef struct entry {
	unsigned short align_left;	/* currently aligned coordinates */
	unsigned short align_right;	/* ???? */
	unsigned short no_vec_left;
	unsigned short no_vec_right;
	unsigned short clear_left;
	unsigned short clear_right;
	unsigned short len;		/* clear length-length w/ hi quality values */
	unsigned short full_len;	/* total length-length regardless of quality vals */
	unsigned short num_conflicts;	/* number of nt's conflicting in sequence match */
	char *name;			/* name of the sequence */
	char *clone_name;		/* name of the clone */
	char *db;			/* name of the database */
	int count;
	int norm_count;
	int offset;
	int max_score;
	int pair;			/* clone mate array index ???? */
	int min_len;			/* clone statistics - minimum length */
	int med_len;			/* clone statistics - medium length */
	int max_len;			/* clone statistics - maximum length */
	long filepos;			/* file position in raw sequence */
	long consed_filepos;		/* pointer into the fasta line */
	long dl_filepos;		/*  ????? */
	long class_filepos;
	ConPos *align;
	ConPos *right;
	ConPos *left;
	ConPos *beg_contig;
	ConPos *end_contig;
	AbScoreRec *score_array;
	char status;
	char link_status;
	char direction;
	char tandem;
} SeqRec;

#endif
