/*

Copyright (c) 2003, The Institute for Genomic Research (TIGR), Rockville,
Maryland, U.S.A.  All rights reserved.

*/

#include <stdio.h>
#include <stdlib.h>
#include "typedefs.h"
#include "matrices.h"

#ifndef REP_FIND_PROT_H
#define REP_FIND_PROT_H

#define MY_BLOCK	1024

static R32Asm	*free_ptr,
		*store;
static int	left,
		store_size,
		increment;
static R32Asm	**hash_array;

void	init_asm_32mers		(register int);
void	re_init_asm_32mers	(register int);
R32Asm*	get_32_asm		();
void	free_32_store_asm	();
void	load_asm_32mers		(ConPos *, ConPos *);
void	find_asm_32mers		(ConPos *, ConPos *, int, FILE *, SeqRec *, int);

#endif
