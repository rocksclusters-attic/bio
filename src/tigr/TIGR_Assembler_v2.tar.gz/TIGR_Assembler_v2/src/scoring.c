/*

Copyright (c) 2003, The Institute for Genomic Research (TIGR), Rockville,
Maryland, U.S.A.  All rights reserved.

*/

#include "32_store_ext.h"
#include "align_ext.h"
#include "comparisons_ext.h"
#include "consensus_ext.h"

#include "scoring_prot.h"

void
initHisto(
		int *histo
	)
{
	int i;
	for (i = -1; i <= (HIST_SIZE + 1); i++ )
		histo[i] = 0;
}

void
graphRecordCounts(
		int *histo,
		int *num_32s,
		R32Hash **hash_array,
		R32Hash **hash_end
	)
{
	R32Hash	**hash_rec,
		*cur;
	int	count;

	for (hash_rec = hash_array; hash_rec < hash_end; hash_rec++) {
		for (cur = *hash_rec; cur != NULL; cur = cur->next_hash) {
			count = cur->count;
			(*num_32s)++;
			if (count <= HIST_SIZE) {
				histo[count]++;
			} else {
				histo[HIST_SIZE + 1]++;
			}
		}
	}
}

void
computeRecordStats(
		int *histo,
		int *num_32s,
		int *median_count,
		int *median,
		int *median_1_5,
		int *median_2,
		int *median_2_5,
		int *median_3,
		int *median_4,
		int *diff1,
		int *diff2,
		int *diff3,
		int *diff4
	)
{
	int	count,
		i;

	*median_count = ((*num_32s - (histo[0] + histo[1])) / 2) + (histo[0] + histo[1]);
	for (i = 0, count = 0; i <= (HIST_SIZE + 1); i++) {
		count += histo[i];
		if (count > *median_count) {
			*median = i;
			break;
		}
	}
	if (*median < 2) {
		*median = 2;
	}
	*median_1_5 = (3 * (*median)) / 2;
	*median_2 = 2 * (*median);
	*median_2_5 = (5 * (*median)) / 2;
	*median_3 = 3 * (*median);
	*median_4 = 4 * (*median);
	*diff1 = *median_1_5 - *median;
	*diff2 = *median_2 - *median_1_5;
	*diff3 = *median_2_5 - *median_2;
	*diff4 = *median_3 - *median_2_5;
	fprintf(stderr, "hit stats: median %d, num_32s %d\n", *median, *num_32s);
	for (i = 0; i <= (HIST_SIZE + 1); i++) {
		fprintf(stderr, "%d : %d\n", i, histo[i]);
	}
	fflush(NULL);
}

void
computeRecordScores(
		R32Hash **hash_array,
		R32Hash **hash_end,
		int median,
		int median_1_5,
		int median_2,
		int median_2_5,
	 	int median_3,
		int median_4,
		int diff1,
		int diff2,
		int diff3,
		int diff4
	)
{
	R32Hash	**hash_rec,
		*cur;
	int	count;

	for (hash_rec = hash_array; hash_rec < hash_end; hash_rec++) {
		for (cur = *hash_rec; cur != NULL; cur = cur->next_hash) {
			count = cur->count;
			if (count == 0) {
				cur->count = REP_32_FACTOR;
			} else if (count >= median_4) {
				cur->count = MIN_32_FACTOR;
			} else if (count <= median) {
				cur->count = MAX_32_FACTOR;
			} else if (count <= median_1_5) {
				cur->count = MED1_32_FACTOR + ((median_1_5 - count) * (MAX_32_FACTOR - MED1_32_FACTOR)) / diff1;
			} else if (count <= median_2) {
				cur->count = MED2_32_FACTOR + ((median_2 - count) * (MED1_32_FACTOR - MED2_32_FACTOR)) / diff2;
			} else if (count <= median_2_5) {
				cur->count = MED3_32_FACTOR + ((median_2_5 - count) * (MED2_32_FACTOR - MED3_32_FACTOR)) / diff3;
			} else if (count <= median_3) {
				cur->count = MED4_32_FACTOR + ((median_3 - count) * (MED3_32_FACTOR - MED4_32_FACTOR)) / diff4;
			} else {
				cur->count = MIN_32_FACTOR + ((median_4 - count) * (MED4_32_FACTOR - MIN_32_FACTOR)) / median;
			}
		}
	}
}

void
computePairRecords(
		SeqRec *seqrec_array,
		int start_seq,
		int stop_seq,
		int num_seqs,
		R32Hash **hash_array,
		int search_tandem,
		FILE *scratch
	)
{
	SeqRec *seqrec_ptr;
	double double_score;
	int  num_over_thresh = 0,
	     length,
	     ident1,
	     ident2,
	     pos,
	     count,
	     cur_seq_num,
	     score,
	     hit_length,
	     min_hit_length,
	     max_score,
	     extent,
	     diff_extent,
	     hit_pos,
	     left_pos,
	     right_pos,
	     hit_overlap,
	     seq_num,
	     tmp_term,
	     ret_val = 0;
	R32Hash  **hash_rec,
	     *cur;
	QuadHash *quad_cur;
	ScoreRec *score_rec,
	     *score_array,
	     *score_end,
	     *score_next,
	     *score_prev;
	AbScoreRec *abscore_rec,
	     *abscore_next,
	     **abscore_prev;
	unsigned short quad_val;
	char inputline[MAX_LINE],
	     *char_ptr,
	     *char2_ptr;


	if ((score_array = (ScoreRec *)malloc((unsigned)(num_seqs * sizeof(*score_array)))) == NULL) {
		fprintf(stderr, "ERROR: Could not allocate memory for score_array\n");
		exit(1);
	}
	score_end = score_array + num_seqs;
	for (score_rec = score_array, seqrec_ptr = seqrec_array; score_rec < score_end; score_rec++, seqrec_ptr++) {
		score_rec->hits = 0;
	}
	
	for(seqrec_ptr = seqrec_array + start_seq; (seq_num = seqrec_ptr - seqrec_array) < stop_seq; seqrec_ptr++) {
		length = seqrec_ptr->len;
		fseek(scratch, seqrec_ptr->class_filepos, 0);
		fread(inputline, sizeof(*inputline), length, scratch);
		/* FORWARD STRAND */
		char_ptr = inputline;
		char2_ptr = inputline + HASH_KEY_SIZE;
		for (quad_val = 0, ident1 = 0, ident2 = 0, pos = 0; pos < HASH_KEY_SIZE; pos++, char_ptr++, char2_ptr++) {
			ident1 <<= 2;
			ident1 += ((unsigned)*char_ptr);
			ident2 <<= 2;
			ident2 += ((unsigned)*char2_ptr);
			quad_val <<= 1;
			quad_val += (((unsigned)*char_ptr) >> 1);
		}
		pos += HASH_IDENT_SIZE;
		while (TRUE) {
			hash_rec = hash_array + quad_val;
			for (cur = *hash_rec; ((ident2 > cur->ident2) || ((ident2 == cur->ident2) && (ident1 > cur->ident1))); cur = cur->next_hash);
			count = cur->count;
#ifdef DEBUG
			if ((ident2 != cur->ident2) || (ident1 != cur->ident1)) {
				fprintf(stderr, "ERROR: ident != cur->ident\n");
				exit(1);
			}
#endif
			if (search_tandem || (count > REP_32_FACTOR)) {
				for (quad_cur = cur->next; quad_cur != NULL; quad_cur = quad_cur->next) {
					cur_seq_num = quad_cur->seq_num;
					hit_pos = quad_cur->pos;
					if (seq_num == cur_seq_num) {
						if (pos != hit_pos) {
							seqrec_ptr->tandem = FORWARD;
						}
						continue;
					}
					score_rec = &score_array[cur_seq_num];
					extent = pos - hit_pos;
					if (score_rec->hits == 0) {
						score_rec->pos = pos;
						score_rec->hit_pos = hit_pos;
						score_rec->extent = extent;
						score_rec->next = NULL;
					} else {
						while (TRUE) {
							diff_extent = extent - score_rec->extent;
							if ((diff_extent < MAX_DIFF_EXTENT) && (diff_extent > (- MAX_DIFF_EXTENT))) {
								break;
							}
							score_next = score_rec->next;
							if (score_next == NULL) {
								if ((score_next = (ScoreRec *)malloc((unsigned)sizeof(*(score_rec->next)))) == NULL) {
									fprintf(stderr, "ERROR: Could not allocate memory for score_rec->next\n");
									exit(1);
								}
								score_rec->next = score_next;
								score_next->pos = pos;
								score_next->hit_pos = hit_pos;
								score_next->extent = extent;
								score_next->next = NULL;
								score_next->hits = 0;
								score_rec = score_next;
								break;
							}
							score_rec = score_next;
						}
					}
					score_rec->hits += count;
				}
			}
			if (pos >= length) {
				break;
			}
			ident1 <<= 2;
			ident1 += ((unsigned)*char_ptr);
			ident2 <<= 2;
			ident2 += ((unsigned)*char2_ptr);
			quad_val <<= 1;
			quad_val += (((unsigned)*char_ptr) >> 1);
			pos++;
			char_ptr++;
			char2_ptr++;
		}
		num_over_thresh = 0;
		for (score_rec = score_array, max_score = seqrec_ptr->max_score; score_rec < score_end; score_rec++) {
			score = score_rec->hits;
			if (score > 0) {
				score_next = score_rec;
				cur_seq_num = score_rec - score_array;
				hit_length = (seqrec_array + cur_seq_num)->len;
				if (length < hit_length) {
					min_hit_length = length;
				} else {
					min_hit_length = hit_length;
				}
				min_hit_length -= (HASH_IDKEY_SIZE - HASH_STEP_SIZE);
				min_hit_length /= HASH_STEP_SIZE;
				do {
					if ((abscore_rec = (AbScoreRec *)malloc((unsigned)sizeof(*abscore_rec))) == NULL) {
						fprintf(stderr, "ERROR: Could not allocate memory for abscore_rec\n");
						exit(1);
					}
					abscore_rec->hits = score_next->hits;
					double_score = (double)score_next->hits;
					pos = score_next->pos;
					hit_pos = score_next->hit_pos;
					left_pos = pos - hit_pos;
					if (left_pos < 0) {
						left_pos = 0;
					}
					right_pos = pos + (hit_length - hit_pos);
					if (right_pos > length) {
						right_pos = length;
					}
					hit_overlap = right_pos - left_pos;
					hit_overlap -= (HASH_IDKEY_SIZE - HASH_STEP_SIZE);
					hit_overlap /= HASH_STEP_SIZE;
#ifdef DEBUG
					fprintf(stderr, "score %d: %s vs %s, left_pos %d, right_pos %d, pos %d, hit_pos %d, length %d, hit_length %d, min_hit_length %d, hit_overlap %d\n", score_next->hits, seqrec_ptr->name, (seqrec_array + cur_seq_num)->name, left_pos, right_pos, pos, hit_pos, length, hit_length, min_hit_length, hit_overlap);
					fflush(NULL);
#endif
					tmp_term = (50 * ((3 * min_hit_length) + hit_overlap));
					double_score *= (double)tmp_term;
					tmp_term = (min_hit_length * hit_overlap);
					double_score /= (double)tmp_term;
					score = (int)double_score;
					if (score > max_score) {
						max_score = score;
					}
					abscore_rec->strand = FORWARD;
					abscore_rec->do_first = 0;
					abscore_rec->links = 0;
					abscore_rec->dist_from_med = MAX_PAIR_DIST;
					abscore_rec->pos = pos;
					abscore_rec->hit_pos = hit_pos;
					abscore_rec->score = score;
					abscore_rec->status = UNTESTED;
					abscore_rec->con_seq_num = seq_num;
					abscore_rec->seq_num = cur_seq_num;
					num_over_thresh++;
					score_next = score_next->next;
					for (abscore_prev = &(seqrec_ptr->score_array), abscore_next = *abscore_prev; (abscore_next != NULL) && (score < abscore_next->score); abscore_prev = &(abscore_next->next), abscore_next = *abscore_prev);
					*abscore_prev = abscore_rec;
					abscore_rec->next = abscore_next;
				} while (score_next != NULL);
				score_next = score_rec->next;
				while (score_next != NULL) {
					score_prev = score_next;
					score_next = score_next->next;
					free(score_prev);
				}
				score_rec->hits = 0;
			}
		}
		seqrec_ptr->max_score = max_score;
		seqrec_ptr->count += num_over_thresh;
#ifdef DEBUG
		fprintf(stderr, "score stats: %s, max_score %d, num_o_t %d\n", seqrec_ptr->name, max_score, num_over_thresh);
		fflush(NULL);
#endif
		/* REVERSE STRAND virtually identical code */
		revcomp(inputline, length);
		char_ptr = inputline;
		char2_ptr = inputline + HASH_KEY_SIZE;
		for (quad_val = 0, ident1 = 0, ident2 = 0, pos = 0; pos < HASH_KEY_SIZE; pos++, char_ptr++, char2_ptr++) {
			ident1 <<= 2;
			ident1 += ((unsigned)*char_ptr);
			ident2 <<= 2;
			ident2 += ((unsigned)*char2_ptr);
			quad_val <<= 1;
			quad_val += (((unsigned)*char_ptr) >> 1);
		}
		pos += HASH_IDENT_SIZE;
		while (TRUE) {
			hash_rec = hash_array + quad_val;
			for (cur = *hash_rec; ((ident2 > cur->ident2) || ((ident2 == cur->ident2) && (ident1 > cur->ident1))); cur = cur->next_hash);
			count = cur->count;
#ifdef DEBUG
			if ((ident2 != cur->ident2) || (ident1 != cur->ident1)) {
				fprintf(stderr, "ERROR: ident != cur->ident\n");
				exit(1);
			}
#endif
			if (search_tandem || (count > REP_32_FACTOR)) {
				for (quad_cur = cur->next; quad_cur != NULL; quad_cur = quad_cur->next) {
					cur_seq_num = quad_cur->seq_num;
					hit_pos = quad_cur->pos;
					if (seq_num == cur_seq_num) {
						seqrec_ptr->tandem = REVERSE;
						continue;
					}
					score_rec = &score_array[cur_seq_num];
					extent = pos - hit_pos;
					if (score_rec->hits == 0) {
						score_rec->pos = pos;
						score_rec->hit_pos = hit_pos;
						score_rec->extent = extent;
						score_rec->next = NULL;
					} else {
						while (TRUE) {
							diff_extent = extent - score_rec->extent;
							if ((diff_extent < MAX_DIFF_EXTENT) && (diff_extent > (- MAX_DIFF_EXTENT))) {
								break;
							}
							score_next = score_rec->next;
							if (score_next == NULL) {
								if ((score_next = (ScoreRec *)malloc((unsigned)sizeof(*(score_rec->next)))) == NULL) {
									fprintf(stderr, "ERROR: Could not allocate memory for score_rec->next\n");
									exit(1);
								}
								score_rec->next = score_next;
								score_next->pos = pos;
								score_next->hit_pos = hit_pos;
								score_next->extent = extent;
								score_next->next = NULL;
								score_next->hits = 0;
								score_rec = score_next;
								break;
							}
							score_rec = score_next;
						}
					}
					score_rec->hits += count;
				}
			}
			if (pos >= length) {
				break;
			}
			ident1 <<= 2;
			ident1 += ((unsigned)*char_ptr);
			ident2 <<= 2;
			ident2 += ((unsigned)*char2_ptr);
			quad_val <<= 1;
			quad_val += (((unsigned)*char_ptr) >> 1);
			pos++;
			char_ptr++;
			char2_ptr++;
		}
		num_over_thresh = 0;
		for (score_rec = score_array, max_score = seqrec_ptr->max_score; score_rec < score_end; score_rec++) {
			score = score_rec->hits;
			if (score > 0) {
				score_next = score_rec;
				cur_seq_num = score_rec - score_array;
				hit_length = (seqrec_array + cur_seq_num)->len;
				if (length < hit_length) {
					min_hit_length = length;
				} else {
					min_hit_length = hit_length;
				}
				min_hit_length -= (HASH_IDKEY_SIZE - HASH_STEP_SIZE);
				min_hit_length /= HASH_STEP_SIZE;
				do {
					if ((abscore_rec = (AbScoreRec *)malloc((unsigned)sizeof(*abscore_rec))) == NULL) {
						fprintf(stderr, "ERROR: Could not allocate memory for abscore_rec\n");
						exit(1);
					}
					abscore_rec->hits = score_next->hits;
					double_score = (double)score_next->hits;
					pos = score_next->pos;
					hit_pos = score_next->hit_pos;
					left_pos = pos - hit_pos;
					if (left_pos < 0) {
						left_pos = 0;
					}
					right_pos = pos + (hit_length - hit_pos);
					if (right_pos > length) {
						right_pos = length;
					}
					hit_overlap = right_pos - left_pos;
					hit_overlap -= (HASH_IDKEY_SIZE - HASH_STEP_SIZE);
					hit_overlap /= HASH_STEP_SIZE;
#ifdef DEBUG
					fprintf(stderr, "score %d: %s vs %s, left_pos %d, right_pos %d, pos %d, hit_pos %d, length %d, hit_length %d, min_hit_length %d, hit_overlap %d\n", score_next->hits, seqrec_ptr->name, (seqrec_array + cur_seq_num)->name, left_pos, right_pos, pos, hit_pos, length, hit_length, min_hit_length, hit_overlap);
					fflush(NULL);
#endif
					tmp_term = (50 * ((3 * min_hit_length) + hit_overlap));
					double_score *= (double)tmp_term;
					tmp_term = (min_hit_length * hit_overlap);
					double_score /= (double)tmp_term;
					score = (int)double_score;
					if (score > max_score) {
						max_score = score;
					}
					abscore_rec->strand = REVERSE;
					abscore_rec->do_first = 0;
					abscore_rec->links = 0;
					abscore_rec->dist_from_med = MAX_PAIR_DIST;
					abscore_rec->pos = (length - pos) + 1;
					abscore_rec->hit_pos = hit_pos;
					abscore_rec->score = score;
					abscore_rec->status = UNTESTED;
					abscore_rec->con_seq_num = seq_num;
					abscore_rec->seq_num = cur_seq_num;
					num_over_thresh++;
					score_next = score_next->next;
					for (abscore_prev = &(seqrec_ptr->score_array), abscore_next = *abscore_prev; (abscore_next != NULL) && (score < abscore_next->score); abscore_prev = &(abscore_next->next), abscore_next = *abscore_prev);
					*abscore_prev = abscore_rec;
					abscore_rec->next = abscore_next;
				} while (score_next != NULL);
				score_next = score_rec->next;
				while (score_next != NULL) {
					score_prev = score_next;
					score_next = score_next->next;
					free(score_prev);
				}
				score_rec->hits = 0;
			}
		}
		seqrec_ptr->max_score = max_score;
		seqrec_ptr->count += num_over_thresh;
#ifdef DEBUG
		fprintf(stderr, "score stats: %s, max_score %d, num_o_t %d\n", seqrec_ptr->name, max_score, num_over_thresh);
		fflush(NULL);
#endif
	}
	
	free(score_array);
}

void
graphSequenceLengths(
		int *histo,
		SeqRec *seqrec_array,
		int num_seqs
	)
{
	SeqRec	*seqrec_ptr;
	int	count;

	for (seqrec_ptr = seqrec_array; (seqrec_ptr - seqrec_array) < num_seqs; seqrec_ptr++) {
		count = seqrec_ptr->len;
		if (count <= HIST_SIZE) {
			histo[count]++;
		} else {
			histo[HIST_SIZE + 1]++;
		}
	}
}

void
computeSequenceStats(
		int *histo,
		SeqRec *seqrec_array,
		int num_seqs,
		int *median,
		int *total_count,
		int *thresh,
		int *next_restart,
		int merged
	)
{
	SeqRec	*seqrec_ptr,
		*seqrec_end = seqrec_array + num_seqs;
	int	count,
		norm_length,
		med_length,
		median_count,
		i;

	median_count = num_seqs / 2;
	for (i = 0, count = 0; i <= (HIST_SIZE + 1); i++) {
		count += histo[i];
		if (count > median_count) {
			med_length = i;
			break;
		}
	}
	initHisto(histo);
	*total_count = 0;
	norm_length = 10 * med_length;
	for (seqrec_ptr = seqrec_array; seqrec_ptr < seqrec_end; seqrec_ptr++) {
		count = seqrec_ptr->count;
		*total_count += count;
		count *= norm_length;
		count /= (seqrec_ptr->len + med_length);
		seqrec_ptr->norm_count = count;
		if (count <= HIST_SIZE) {
			histo[count]++;
		} else {
			histo[HIST_SIZE + 1]++;
		}
	}
	median_count = ((num_seqs - histo[0]) / 2) + histo[0];
	for (i = 0, count = 0; i <= (HIST_SIZE + 1); i++) {
		count += histo[i];
		if (count >= median_count) {
			*median = i;
			break;
		}
	}
	if (*median < 2) {
		*median = 2;
	}
	*thresh = (int)((1.75 * (float)(*median)) + 0.5);
	if (*thresh <= *median) {
		*thresh = *median + 1;
	}
	*next_restart = num_seqs / 2;
	if (*next_restart < merged) {
		*next_restart = merged;
	}

	fprintf(stderr, "median sequence length: %d\n", med_length);
	fprintf(stderr, "hit stats: median %d, num_seqs %d, thresh %d\n", *median, num_seqs, *thresh);
	for (i = 0; i <= (HIST_SIZE + 1); i++) {
		fprintf(stderr, "%d : %d\n", i, histo[i]);
	}
	fflush(NULL);
}

void
normalizeSequences(
		SeqRec *seqrec_array,
		int num_seqs,
		int median,
		int thresh
	)
{
	SeqRec	**seqrec_sort,
		*seqrec_end = seqrec_array + num_seqs,
		*seqrec_ptr,
		**sort_ptr,
		**sort_end;
	int	show_seqs;

	if ((seqrec_sort = (SeqRec **)malloc(num_seqs * sizeof(*seqrec_sort))) == NULL) {
		fprintf(stderr, "Out of Memory for seqrec_sort\n");
		exit(1);
	}
	sort_ptr = seqrec_sort;
	for (seqrec_ptr = seqrec_array; seqrec_ptr < seqrec_end; seqrec_ptr++) {
		if (seqrec_ptr->norm_count >= thresh) {
			*sort_ptr++ = seqrec_ptr;
		}
	}
	sort_end = sort_ptr;
	show_seqs = sort_end - seqrec_sort;
	qsort((char *)seqrec_sort, (size_t)(show_seqs), sizeof(*seqrec_sort), count_compare);
	if (show_seqs > 0) {
		fprintf(stderr, "%d Sequences in potential repeat regions (matches/median):\n", show_seqs);
	}
	for (sort_ptr = seqrec_sort; sort_ptr < sort_end; sort_ptr++) {
		seqrec_ptr = *sort_ptr;
		fprintf(stderr, "%s\t\t%3.1f\n", seqrec_ptr->name, ((float)seqrec_ptr->norm_count / (float) median));
	}
	free(seqrec_sort);
}

void
orderByFile(
		SeqRec *seqrec_array,
		int num_seqs,
		FILE *fp_order
	)
{
	AbScoreRec
		*abscore_rec;
	SeqRec	**seqrec_sort,
		*seqrec_ptr,
		*seqrec_end,
		*seqrec_ptr_1,
		*seqrec_ptr_2,
		**sort_ptr,
		**sort_end,
		search_seqrec;
	int	seq_num,
		seq_num_1,
		seq_num_2,
		do_first,
		num_seq_names;
	char	inputline[MAX_LINE],
		seq_name_1[MAX_LINE],
		seq_name_2[MAX_LINE];

	if ((seqrec_sort = (SeqRec **)malloc(num_seqs * sizeof(*seqrec_sort))) == NULL) {
		fprintf(stderr, "Out of Memory for seqrec_sort\n");
		exit(1);
	}
	sort_ptr = seqrec_sort;
	seqrec_end = seqrec_array + num_seqs;
	for (seqrec_ptr = seqrec_array; seqrec_ptr < seqrec_end; seqrec_ptr++) {
		*sort_ptr++ = seqrec_ptr;
	}
	sort_end = sort_ptr;
	qsort((char *)seqrec_sort, (size_t)(num_seqs), sizeof(*seqrec_sort), seq_name_compare);
	if (fgets(inputline, MAX_LINE, fp_order) == NULL) {
		fprintf(stderr, "No order input!\n");
		exit(1);
	}
	do {
		if (inputline[MAX_LINE - 2] != '\0') {
			fprintf(stderr, "ERROR: Line too long in order input file!\n%s\n", inputline);
			exit(1);
		}
		if ((num_seq_names = sscanf(inputline, "%d %s %s", &do_first, seq_name_1, seq_name_2)) < 2) {
			fprintf(stderr, "ERROR: Improper format in order input file!\n%s\n", inputline);
			exit(1);
		}
		if (do_first < 0) {
			do_first = 0;
			fprintf(stderr, "WARNING: order < 0 in order file - setting to 0!\n");
		} else if (do_first > USHRT_MAX) {
			do_first = USHRT_MAX;
			fprintf(stderr, "WARNING: order > %d in order file - setting to %d!\n", USHRT_MAX, USHRT_MAX);
		}
		if (--num_seq_names == 1) {
			search_seqrec.name = seq_name_1;
			seqrec_ptr = &search_seqrec;
			if ((sort_ptr = (SeqRec **)bsearch((void *)&seqrec_ptr, (void *)seqrec_sort, (size_t)num_seqs, sizeof(*seqrec_sort), seq_name_compare)) == NULL) {
				fprintf(stderr, "ERROR: seq_name (%s) in order input file not found in input!\n", seq_name_1);
				continue;
			}
			seqrec_ptr_1 = *sort_ptr;
			for (abscore_rec = seqrec_ptr_1->score_array; abscore_rec != NULL; abscore_rec = abscore_rec->next) {
				abscore_rec->do_first = do_first;
#ifdef SHOWSTATS
				fprintf(stderr, "%s(%s) vs %s score %d hits %d stat %d strand %d pos %d h_pos %d dist %d num %d ord %d do %d\n", seq_name_1, (seqrec_array + abscore_rec->con_seq_num)->name, (seqrec_array + abscore_rec->seq_num)->name, (int)abscore_rec->score, (int)abscore_rec->hits, (int)abscore_rec->status, (int)abscore_rec->strand, (int)abscore_rec->pos, (int)abscore_rec->hit_pos, abscore_rec->dist_from_med, (int)abscore_rec->num_matches, (int)abscore_rec->order, (int)abscore_rec->do_first);
#endif
			}
		} else { /* two seq_names */
			search_seqrec.name = seq_name_1;
			seqrec_ptr = &search_seqrec;
			if ((sort_ptr = (SeqRec **)bsearch((void *)&seqrec_ptr, (void *)seqrec_sort, (size_t)num_seqs, sizeof(*seqrec_sort), seq_name_compare)) == NULL) {
				fprintf(stderr, "ERROR: seq_name (%s) in order input file not found in input!\n", seq_name_1);
				continue;
			}
			seqrec_ptr_1 = *sort_ptr;
			seq_num_1 = seqrec_ptr_1 - seqrec_array;
			search_seqrec.name = seq_name_2;
			seqrec_ptr = &search_seqrec;
			if ((sort_ptr = (SeqRec **)bsearch((void *)&seqrec_ptr, (void *)seqrec_sort, (size_t)num_seqs, sizeof(*seqrec_sort), seq_name_compare)) == NULL) {
				fprintf(stderr, "ERROR: seq_name (%s) in order input file not found in input!\n", seq_name_2);
				continue;
			}
			seqrec_ptr_2 = *sort_ptr;
			seq_num_2 = seqrec_ptr_2 - seqrec_array;
			for (abscore_rec = seqrec_ptr_1->score_array; abscore_rec != NULL; abscore_rec = abscore_rec->next) {
				if (abscore_rec->seq_num == seq_num_2) {
					abscore_rec->do_first = do_first;
#ifdef SHOWSTATS
		fprintf(stderr, "%s(%s) vs %s score %d hits %d stat %d strand %d pos %d h_pos %d dist %d num %d ord %d do %d\n", seq_name_1, (seqrec_array + abscore_rec->con_seq_num)->name, (seqrec_array + abscore_rec->seq_num)->name, (int)abscore_rec->score, (int)abscore_rec->hits, (int)abscore_rec->status, (int)abscore_rec->strand, (int)abscore_rec->pos, (int)abscore_rec->hit_pos, abscore_rec->dist_from_med, (int)abscore_rec->num_matches, (int)abscore_rec->order, (int)abscore_rec->do_first);
#endif
				}
			}
			for (abscore_rec = seqrec_ptr_2->score_array; abscore_rec != NULL; abscore_rec = abscore_rec->next) {
				if (abscore_rec->seq_num == seq_num_1) {
					abscore_rec->do_first = do_first;
#ifdef SHOWSTATS
		fprintf(stderr, "%s(%s) vs %s score %d hits %d stat %d strand %d pos %d h_pos %d dist %d num %d ord %d do %d\n", seq_name_2, (seqrec_array + abscore_rec->con_seq_num)->name, (seqrec_array + abscore_rec->seq_num)->name, (int)abscore_rec->score, (int)abscore_rec->hits, (int)abscore_rec->status, (int)abscore_rec->strand, (int)abscore_rec->pos, (int)abscore_rec->hit_pos, abscore_rec->dist_from_med, (int)abscore_rec->num_matches, (int)abscore_rec->order, (int)abscore_rec->do_first);
#endif
				}
			}
		}
	} while(fgets(inputline, MAX_LINE, fp_order) != NULL);
	free(seqrec_sort);
}

void
orderScoreRecords(
		SeqRec *seqrec_array,
		int num_seqs,
		int total_count,
		int median_1_5,
		int low_scores,
		AbScoreRec **abscore_sort,
		AbScoreRec **absort_end,
		AbScoreRec ***resort_end
	)
{
	AbScoreRec
		**absort_ptr = abscore_sort,
		*abscore_next,
		*abscore_rec;
	SeqRec	*seqrec_ptr,
		*seqrec_end = seqrec_array + num_seqs;
	int	i,
		count,
		seq_num,
		first_low;

	for (seqrec_ptr = seqrec_array; seqrec_ptr < seqrec_end; seqrec_ptr++) {
		count = seqrec_ptr->norm_count;
#ifdef SHOWSTATS
		fprintf(stderr, "%s, len %d, norm_count %d, count %d, tandem %d\n", seqrec_ptr->name, (int)seqrec_ptr->len, count, (int)seqrec_ptr->count, (int)seqrec_ptr->tandem);
		fflush(NULL);
#endif
		seq_num = seqrec_ptr - seqrec_array;
		first_low = TRUE;
		for (i = 1, abscore_rec = seqrec_ptr->score_array; abscore_rec != NULL; i++, abscore_rec = abscore_rec->next) {
			*absort_ptr++ = abscore_rec;
			abscore_rec->order = i;
#ifdef SHOWSTATS
			abscore_rec->num_matches = count + (seqrec_array + abscore_rec->seq_num)->norm_count;
#endif
			if (abscore_rec->do_first > 0) {
				continue;
			}
			if ((abscore_rec->score < (100 * MIN_32_FACTOR)) && (i > median_1_5) && (!low_scores)) {
				if (first_low) {
					first_low = FALSE;
				} else {
					abscore_rec->status = LOW_SCORE;
				}
			}
		}
	}
#ifdef SHOWSTATS
	fprintf(stderr, "total_count %d\n", total_count);
	fflush(NULL);
#endif
	if (abscore_sort < absort_end) {
		qsort((char *)abscore_sort, (size_t)total_count, sizeof(*abscore_sort), duplicate_compare);
		for (absort_ptr = abscore_sort, abscore_rec = *absort_ptr, absort_ptr++; absort_ptr < absort_end; absort_ptr++, abscore_rec = abscore_next) {
			abscore_next = *absort_ptr;
			if (
				(abscore_next->con_seq_num == abscore_rec->seq_num) && 
				(abscore_next->seq_num == abscore_rec->con_seq_num) && 
				(abscore_rec->status == abscore_next->status) && 
				(abscore_next->do_first == abscore_rec->do_first)
			   ) {
				if (abscore_next->order > abscore_rec->order) {
					abscore_next->status = DUPLICATE;
				} else {
					abscore_rec->status = DUPLICATE;
				}
			}
		}
		qsort((char *)abscore_sort, (size_t)total_count, sizeof(*abscore_sort), best_match_compare);
	}

	for (*resort_end = abscore_sort; *resort_end < absort_end; (*resort_end)++) {
		abscore_rec = **resort_end;
		if (abscore_rec->status != UNTESTED) {
			break;
		}
	}
	fprintf(stderr,"total pairwise matches %d nonduplicate/repeat/low %d\n", absort_end - abscore_sort, *resort_end - abscore_sort);
}

void
printScoreOrder(
		SeqRec *seqrec_array,
		int num_seqs,
		AbScoreRec **abscore_sort,
		AbScoreRec **absort_end,
		char *abscore_filename
	)
{
	AbScoreRec	**absort_ptr;
	FILE		*fp_abscore;

	if (!(fp_abscore = fopen(abscore_filename, "w"))) {
		fprintf(stderr, "ERROR: abscore output file \"%s\" is not writeable!\n", abscore_filename);
		exit(1);
	}
	for(absort_ptr = abscore_sort; absort_ptr < absort_end; absort_ptr++) {
		fprintf(fp_abscore, "%s %s\n",
			seqrec_array[(*absort_ptr)->seq_num].name,
			seqrec_array[(*absort_ptr)->con_seq_num].name);
	}
	fclose(fp_abscore);
}

void
resort_scores(
		register AbScoreRec **abscore_sort,
		register AbScoreRec **absort_end,
		register SeqRec *seqrec_array
	)
{
register ConPos		*latest;
register AbScoreRec	*abscore_rec;
register AbScoreRec	**absort_ptr;
register SeqRec		*seqrec_ptr, *pair, *con_seq_ptr;
register int		seq_dir, pair_dir, score_dir;
register int		pos, hit_pos, dist1, dist2;

	for (absort_ptr = abscore_sort; absort_ptr < absort_end; absort_ptr++) {
		abscore_rec = *absort_ptr;
		score_dir = abscore_rec->strand;
		pos = abscore_rec->pos;
		hit_pos = abscore_rec->hit_pos;
		seqrec_ptr = seqrec_array + abscore_rec->seq_num;
		con_seq_ptr = seqrec_array + abscore_rec->con_seq_num;
		reset_coords(seqrec_ptr, FALSE);
		seq_dir = IS_FORWARD_no_reset(seqrec_ptr);
		if (!score_dir) {
			seq_dir = 1 - seq_dir;
		}
		if (con_seq_ptr->pair < 0) {
			dist1 = MAX_PAIR_DIST;
		} else {
			pair = seqrec_array + con_seq_ptr->pair;
			reset_coords(pair, FALSE);
			pair_dir = IS_FORWARD_no_reset(pair);
			if (((seqrec_ptr->beg_contig)->latest != (pair->beg_contig)->latest) || (seq_dir == pair_dir)){
				dist1 = MAX_PAIR_DIST;
			} else {
				if ((latest = get_latest(seqrec_ptr->align + (hit_pos - 1))) == NULL) {
					dist1 = -1;
				} else if (seq_dir) { /* FORWARD */
					dist1 = ((pair->left)->pos - (latest->pos - (pos - 1))) + 1;
				} else { /* REVERSE */
					dist1 = ((latest->pos + (pos - 1)) - (pair->left)->pos) + 1;
				}
				if ((dist1 < pair->min_len) || (dist1 > pair->max_len)) {
					dist1 = MAX_PAIR_DIST;
				} else {
					dist1 -= pair->med_len;
					if (dist1 < 0) {
						dist1 = - dist1;
					}
				}
			}
		}
		if (seqrec_ptr->pair < 0) {
			dist2 = MAX_PAIR_DIST;
		} else {
			pair = seqrec_array + seqrec_ptr->pair;
			reset_coords(pair, FALSE);
			pair_dir = IS_FORWARD_no_reset(pair);
			seqrec_ptr = con_seq_ptr;
			reset_coords(seqrec_ptr, FALSE);
			seq_dir = IS_FORWARD_no_reset(seqrec_ptr);
			if (!score_dir) {
				seq_dir = 1 - seq_dir;
			}
			if (((seqrec_ptr->beg_contig)->latest != (pair->beg_contig)->latest) || (seq_dir == pair_dir)){
				dist2 = MAX_PAIR_DIST;
			} else {
				if ((latest = get_latest(seqrec_ptr->align + (pos - 1))) == NULL) {
					dist2 = -1;
				} else if (seq_dir) { /* FORWARD */
					dist2 = ((pair->left)->pos - (latest->pos - (hit_pos - 1))) + 1;
				} else { /* REVERSE */
					dist2 = ((latest->pos + (hit_pos - 1)) - (pair->left)->pos) + 1;
				}
				if ((dist2 < pair->min_len) || (dist2 > pair->max_len)) {
					dist2 = MAX_PAIR_DIST;
				} else {
					dist2 -= pair->med_len;
					if (dist2 < 0) {
						dist2 = - dist2;
					}
				}
			}
		}
		if (dist1 < dist2) {
			abscore_rec->dist_from_med = dist1;
		} else {
			abscore_rec->dist_from_med = dist2;
		}
	}
	qsort((void *)abscore_sort, (size_t)(absort_end - abscore_sort), sizeof(*abscore_sort), best_match_compare);
}
