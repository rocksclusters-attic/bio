/*

Copyright (c) 2003, The Institute for Genomic Research (TIGR), Rockville,
Maryland, U.S.A.  All rights reserved.

*/

#include "typedefs.h"
#include "matrices.h"

#ifndef ASMG_GLOBAL_EXT_H
#define ASMG_GLOBAL_EXT_H

extern IncMat	incr_matrix[6 * NUM_LABELS];
extern SubMat	sub_matrix[36 * NUM_LABELS];
extern char	trans_case[6 * NUM_LABELS];
extern char	trans_toupper[6 * NUM_LABELS];
extern char	trans_tolower[6 * NUM_LABELS];
extern char	trans_class[6 * NUM_LABELS];
extern char	trans_comp[6 * NUM_LABELS];
extern char	trans_char[256];
extern char	trans_char_ace[256];

#endif
