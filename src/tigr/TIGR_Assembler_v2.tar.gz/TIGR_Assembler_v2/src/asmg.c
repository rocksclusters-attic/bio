/*

Copyright (c) 2003, The Institute for Genomic Research (TIGR), Rockville,
Maryland, U.S.A.  All rights reserved.

*/

#include	<stdio.h>
#include	<stdlib.h>
#include	<unistd.h>
#include	"typedefs.h"
#include	"matrices.h"
#include	"asmg_global.h"

#include	"32_hash_ext.h"
#include	"32_store_ext.h"
#include	"align_ext.h"
#include	"consensus_ext.h"
#include	"output_ext.h"
#include	"scoring_ext.h"
#include	"usage_ext.h"

int main (
		int argc,
		char **argv
	)
{
int	merged,
	next_restart,
	restart_inc = 64;
int	score_restart = 100 * MAX_32_FACTOR;
char	*asm_prefix = "asm";
R32Hash	**hash_array, **hash_end;
AbScoreRec	**abscore_sort, **absort_end, **resort_end;
SeqRec	*seqrec_array, *seqrec_end;
int	no_norm = FALSE;
char	*program_name;
char	*scratch_filename,
	*fasta_filename,
	*coverage_filename,
	*contig_filename,
	*ace_filename,
	*qual_filename,
	*order_filename,
	*rep_filename,
	*dump_filename,
	*abscore_filename;
char	*align_dir = "", *phd_dir = "";
int	fasta_desc = FALSE;
FILE	*fp_ace = NULL, *fp_qual = NULL, *fp_order = NULL, *fp_rep = NULL, *fp_dump = NULL;
FILE	*scratch, *fp_fasta = NULL, *fp_coverage = NULL, *fp_contig = NULL, *fp_abscore = NULL;
int	num_seqs = 42000;
int	tot_length;
int	num_32s = 0;
int	est_cov = 10;
int	median, thresh, median_1_5, median_2_5, median_2, median_3, median_4, diff1, diff2, diff3, diff4;
int	median_count;
int	total_count;
int	max_err_32 = 5;
int	reg_min_len = 50, reg_max_end = 15;
int	stringent_min_len = 100, stringent_max_end = 7;
int	lax_min_len = 25, lax_max_end = 30;
float	min_per_incr = 6.0,
	reg_min_per = 88.0,
	stringent_min_per = 94.0,
	lax_min_per = 76.0,
	min_per_diff = 18.0;
int	histo_store[HIST_SIZE + 3],
	*histo = histo_store + 1,
	singletons = FALSE,
	contig_ace_format = FALSE,
	just_translate = FALSE,
	zap_questionable = FALSE,
	reverse_translate = FALSE,
	stop_repeats = FALSE,
 	low_scores = FALSE,
 	do_relink = FALSE,
 	search_tandem = FALSE,
	exclude_seqs = FALSE,
	abscore_sort_listing = FALSE,
	max_full_length,
	max_span_len = MAX_SPAN_LEN,
	max_conflicts = MAX_CONFLICTS,
	repeat_num_cutoff = REPEAT_NUM_CUTOFF;

	program_name = *argv;
	argv++;
	argc--;

	while ((argc > 0) && (*argv != NULL) && (*argv)[0] == '-') {
		if ((*argv)[1] == 'f') {
			if ((*argv)[2] == '\0') {
				fasta_filename = *(++argv);
				argc--;
			} else {
				fasta_filename = &(*argv)[2];
			}
			if (!(fp_fasta = fopen(fasta_filename, "w"))) {
				fprintf(stderr, "ERROR: fasta output file \"%s\" is not writeable!\n", fasta_filename);
				exit(1);
			}
		} else if ((*argv)[1] == 'J') {
			if ((*argv)[2] == '\0') {
				dump_filename = *(++argv);
				argc--;
			} else {
				dump_filename = &(*argv)[2];
			}
			if (!(fp_dump = fopen(dump_filename, "w"))) {
				fprintf(stderr, "ERROR: dump output file \"%s\" is not writeable!\n", dump_filename);
				exit(1);
			}
		} else if ((*argv)[1] == 'F') {
			if ((*argv)[2] == '\0') {
				rep_filename = *(++argv);
				argc--;
			} else {
				rep_filename = &(*argv)[2];
			}
			if (!(fp_rep = fopen(rep_filename, "w"))) {
				fprintf(stderr, "ERROR: repeat output file \"%s\" is not writeable!\n", rep_filename);
				exit(1);
			}
		} else if ((*argv)[1] == 'A') {
			if ((*argv)[2] == '\0') {
				ace_filename = *(++argv);
				argc--;
			} else {
				ace_filename = &(*argv)[2];
			}
			if (!(fp_ace = fopen(ace_filename, "w"))) {
				fprintf(stderr, "ERROR: ace output file \"%s\" is not writeable!\n", ace_filename);
				exit(1);
			}
		} else if ((*argv)[1] == 'q') {
			if ((*argv)[2] == '\0') {
				qual_filename = *(++argv);
				argc--;
			} else {
				qual_filename = &(*argv)[2];
			}
			if (!(fp_qual = fopen(qual_filename, "r"))) {
				fprintf(stderr, "ERROR: quality values input file \"%s\" is not readable!\n", qual_filename);
				exit(1);
			}
		} else if ((*argv)[1] == 'O') {
			if ((*argv)[2] == '\0') {
				order_filename = *(++argv);
				argc--;
			} else {
				order_filename = &(*argv)[2];
			}
			if (!(fp_order = fopen(order_filename, "r"))) {
				fprintf(stderr, "ERROR: order input file \"%s\" is not readable!\n", order_filename);
				exit(1);
			}
		} else if ((*argv)[1] == 'C') {
			if ((*argv)[2] == '\0') {
				contig_filename = *(++argv);
				argc--;
			} else {
				contig_filename = &(*argv)[2];
			}
			if (!(fp_contig = fopen(contig_filename, "r"))) {
				fprintf(stderr, "ERROR: contig input file \"%s\" is not readable!\n", contig_filename);
				exit(1);
			}
		} else if ((*argv)[1] == 'c') {
			if ((*argv)[2] == '\0') {
				coverage_filename = *(++argv);
				argc--;
			} else {
				coverage_filename = &(*argv)[2];
			}
			if (!(fp_coverage = fopen(coverage_filename, "w"))) {
				fprintf(stderr, "ERROR: coverage output file \"%s\" is not writeable!\n", coverage_filename);
				exit(1);
			}
		} else if ((*argv)[1] == 'a') {
			if ((*argv)[2] == '\0') {
				align_dir = *(++argv);
				argc--;
			} else {
				align_dir = &(*argv)[2];
			}
		} else if ((*argv)[1] == 'D') {
			if ((*argv)[2] == '\0') {
				phd_dir = *(++argv);
				argc--;
			} else {
				phd_dir = &(*argv)[2];
			}
		} else if ((*argv)[1] == 'y') {
			if ((*argv)[2] == '\0') {
				repeat_num_cutoff = atoi(*(++argv));
				argc--;
			} else {
				repeat_num_cutoff = atoi(&(*argv)[2]);
			}
			if (repeat_num_cutoff < 0) {
				fprintf(stderr, "ERROR: repeat_num_cutoff must be >= 0\n");
				exit(1);
			}
		} else if ((*argv)[1] == 'z') {
			if ((*argv)[2] == '\0') {
				max_conflicts = atoi(*(++argv));
				argc--;
			} else {
				max_conflicts = atoi(&(*argv)[2]);
			}
			if (max_conflicts <= 0) {
				fprintf(stderr, "ERROR: max_conflicts must be > 0\n");
				exit(1);
			}
		} else if ((*argv)[1] == 'S') {
			if ((*argv)[2] == '\0') {
				max_span_len = atoi(*(++argv));
				argc--;
			} else {
				max_span_len = atoi(&(*argv)[2]);
			}
			if (max_span_len <= 0) {
				fprintf(stderr, "ERROR: max_span_len must be > 0\n");
				exit(1);
			}
		} else if ((*argv)[1] == 'e') {
			if ((*argv)[2] == '\0') {
				reg_max_end = atoi(*(++argv));
				argc--;
			} else {
				reg_max_end = atoi(&(*argv)[2]);
			}
			if (reg_max_end <= 0) {
				fprintf(stderr, "ERROR: max_end must be > 0\n");
				exit(1);
			}
			stringent_max_end = reg_max_end / 2;
			lax_max_end = 2 * reg_max_end;
		} else if ((*argv)[1] == 'l') {
			if ((*argv)[2] == '\0') {
				reg_min_len = atoi(*(++argv));
				argc--;
			} else {
				reg_min_len = atoi(&(*argv)[2]);
			}
			if (reg_min_len <= 0) {
				fprintf(stderr, "ERROR: min_len must be > 0\n");
				exit(1);
			}
			stringent_min_len = 2 * reg_min_len;
			lax_min_len = reg_min_len / 2;
		} else if ((*argv)[1] == 'p') {
			if ((*argv)[2] == '\0') {
				sscanf(*(++argv), "%f", &reg_min_per);
				argc--;
			} else {
				sscanf(&(*argv)[2], "%f", &reg_min_per);
			}
			if ((reg_min_per < 0.0) || (reg_min_per > 100.0)) {
				fprintf(stderr, "ERROR: min_per must be > 0 and < 100\n");
				exit(1);
			}
			reg_min_per = (((float)MATCH * reg_min_per) + ((float)MISMATCH * (100.0 - reg_min_per))) /(float)MATCH;
			min_per_incr = (100.0 - reg_min_per) / 2.0;
			stringent_min_per = reg_min_per + min_per_incr;
			lax_min_per = reg_min_per - (2.0 * min_per_incr);
			min_per_diff = stringent_min_per - lax_min_per;
		} else if ((*argv)[1] == 'r') {
			if ((*argv)[2] == '\0') {
				restart_inc = atoi(*(++argv));
				argc--;
			} else {
				restart_inc = atoi(&(*argv)[2]);
			}
			if (restart_inc <= 0) {
				fprintf(stderr, "ERROR: restart_inc must be > 0\n");
				exit(1);
			}
		} else if ((*argv)[1] == 'g') {
			if ((*argv)[2] == '\0') {
				max_err_32 = atoi(*(++argv));
				argc--;
			} else {
				max_err_32 = atoi(&(*argv)[2]);
			}
			if (max_err_32 <= 0) {
				fprintf(stderr, "ERROR: max_err_32 must be > 0\n");
				exit(1);
			}
		} else if ((*argv)[1] == 'n') {
			if ((*argv)[2] == '\0') {
				asm_prefix = *(++argv);
				argc--;
			} else {
				asm_prefix = &(*argv)[2];
			}
		} else if ((*argv)[1] == 's') {
			singletons = TRUE;
		} else if ((*argv)[1] == 'N') {
			no_norm = TRUE;
		} else if ((*argv)[1] == 'd') {
			fasta_desc = TRUE;
		} else if ((*argv)[1] == 'P') {
			contig_ace_format = TRUE;
		} else if ((*argv)[1] == 't') {
			search_tandem = FALSE;
		} else if ((*argv)[1] == 'u') {
			search_tandem = TRUE;
		} else if ((*argv)[1] == 'L') {
			low_scores = TRUE;
		} else if ((*argv)[1] == 'x') {
			exclude_seqs = TRUE;
		} else if ((*argv)[1] == 'X') {
			stop_repeats = TRUE;
		} else if ((*argv)[1] == 'T') {
			just_translate = TRUE;
		} else if ((*argv)[1] == 'Z') {
			zap_questionable = TRUE;
		} else if ((*argv)[1] == 'R') {
			just_translate = TRUE;
			reverse_translate = TRUE;
		} else if ((*argv)[1] == 'H') {
			abscore_sort_listing = TRUE;
			if ((*argv)[2] == '\0') {
				abscore_filename = *(++argv);
				argc--;
			} else {
				abscore_filename = &(*argv)[2];
			}
		} else { /*particularly 'h' for help*/
			usage();
			exit(1);
		}
		argc--;
		argv++;
	}

	if (argc != 1) {
		usage();
		exit(1);
	}

	scratch_filename = *argv;

	if ((scratch = fopen(scratch_filename, "w+")) == NULL) {
		fprintf(stderr, "ERROR: Could not create scratch file \"%s\"\n", scratch_filename);
		exit(1);
	}

	defineSequenceRecords(&seqrec_array,
			      &num_seqs,
			      &tot_length,
			      &merged,
			      &max_full_length,
			      stdin,
			      fp_qual,
			      scratch,	
			      fasta_desc);
	seqrec_end = seqrec_array + num_seqs;

	if (!just_translate) {
		{
			num_32s = 0;
			initHash(tot_length, num_seqs, est_cov, &hash_array, &hash_end);
			buildHash(seqrec_array, seqrec_end, hash_array, scratch);
			initHisto(histo);
			graphRecordCounts(histo, &num_32s, hash_array, hash_end);
			computeRecordStats(histo, &num_32s, &median_count, &median,
				&median_1_5, &median_2, &median_2_5, &median_3,
				&median_4, &diff1, &diff2, &diff3, &diff4);
			computeRecordScores(hash_array, hash_end, median, median_1_5,
				median_2, median_2_5, median_3, median_4,
				diff1, diff2, diff3, diff4);
			computePairRecords(seqrec_array, 0, num_seqs, num_seqs, hash_array,
				search_tandem, scratch);
			freeHash(hash_array);
		}
		{
			initHisto(histo);
			graphSequenceLengths(histo, seqrec_array, num_seqs);
			computeSequenceStats(histo, seqrec_array, num_seqs,
				&median, &total_count, &thresh, &next_restart,
				merged);
			if(!no_norm)
				normalizeSequences(seqrec_array, num_seqs, median, thresh);
		}

		if (total_count && ((abscore_sort = (AbScoreRec **)malloc((unsigned)(total_count * sizeof(*abscore_sort)))) == NULL)) {
			fprintf(stderr, "ERROR: Could not allocate memory for abscore_sort\n");
			exit(1);
		}
		absort_end = abscore_sort + total_count;

		if(fp_order) {
			orderByFile(seqrec_array, num_seqs, fp_order);
		}

		orderScoreRecords(seqrec_array, num_seqs, total_count, median_1_5, low_scores, abscore_sort, absort_end, &resort_end);

		if(abscore_sort_listing) {
			printScoreOrder(seqrec_array, num_seqs, abscore_sort, absort_end, abscore_filename);		
			exit(1);
		}
		
		allocateConsensus(seqrec_array, seqrec_end, incr_matrix, scratch);
		if(fp_contig != NULL) {
			defineExistingContigs(&seqrec_array, &num_seqs, &tot_length, &merged, &max_full_length,
				fp_contig, contig_ace_format, exclude_seqs);
		}

		processScoreRecords(seqrec_array, seqrec_end, abscore_sort, absort_end, resort_end, no_norm, next_restart,
			merged, score_restart, restart_inc, do_relink, stop_repeats, max_err_32, median_1_5,
			reg_min_per, reg_min_len, reg_max_end, lax_min_per, lax_min_len, lax_max_end,
			stringent_min_per, stringent_min_len, stringent_max_end, min_per_incr, min_per_diff, sub_matrix);
	}
	else {
		allocateConsensus(seqrec_array, seqrec_end, incr_matrix, scratch);
	}

	output(seqrec_array, seqrec_end, fp_fasta, fp_coverage, fp_ace, scratch,
	       asm_prefix, align_dir, phd_dir, singletons, fasta_desc, max_full_length, reverse_translate,
	       num_32s, fp_rep, max_span_len, zap_questionable, max_conflicts, fp_dump, repeat_num_cutoff);

	fclose(scratch);
	unlink(scratch_filename);
	return(0);
}
