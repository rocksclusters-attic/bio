/*

Copyright (c) 2003, The Institute for Genomic Research (TIGR), Rockville,
Maryland, U.S.A.  All rights reserved.

*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "typedefs.h"
#include "matrices.h"

#ifndef ALIGN_PROT_H
#define ALIGN_PROT_H

int	find_align	(ConPos *, ConPos *, ConPos *, ConPos *, ConPos *, ConPos *,
			 int, int, int, int, SubMat *, int, int, float, int);
int	consensus	(ConPos *, int);
void	cell_incr	(ConPos *, ConPos *);
void	cell_incr_gap	(ConPos *, ConPos *, ConPos *);
void	cell_create_gap	(ConPos *, ConPos *, ConPos *);
ConPos*	get_latest	(register ConPos *);
void	reset_coords	(register SeqRec *, int);
void	processScoreRecords	(SeqRec *, SeqRec *, AbScoreRec **, AbScoreRec **, AbScoreRec **,
				 int, int, int, int, int, int, int, int, int, float, int, int,
				 float, int, int, float, int, int, float, float, SubMat *);

#endif
