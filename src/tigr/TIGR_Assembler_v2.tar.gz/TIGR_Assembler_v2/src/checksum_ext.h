/*

Copyright (c) 2003, The Institute for Genomic Research (TIGR), Rockville,
Maryland, U.S.A.  All rights reserved.

*/

#ifndef CHECKSUM_EXT_H
#define CHECKSUM_EXT_H

extern unsigned long	checkbase	(register int, register unsigned long);
extern unsigned long	checkinit	();
extern unsigned long	checkfinal	(register unsigned long);

#endif
