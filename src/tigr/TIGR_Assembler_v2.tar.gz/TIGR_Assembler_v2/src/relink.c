/*

Copyright (c) 2003, The Institute for Genomic Research (TIGR), Rockville,
Maryland, U.S.A.  All rights reserved.

*/

#include	"align_ext.h"
#include	"comparisons_ext.h"

#include	"relink_prot.h"

void
relink(
		SeqRec *seqrec_array,
		SeqRec *seqrec_end
	)
{
register int	*links_ptr;
register SeqRec	*seqrec_ptr, *seqrec2_ptr, *pair_ptr, *best_seqrec, *pair_best;
register ConPos *con_seq_ptr, *con_left_end;
register AbScoreRec	*abscore_rec;
register int	pair_num;
register int	seq_dir, pair_dir;
register int	dist1, dist2;
register int	con_right_pos, con_left_pos;

	if (first_time) {
		first_time = FALSE;
		if ((seqrec_end - seqrec_array) && ((links_array = (int *)malloc((seqrec_end - seqrec_array) * sizeof(*links_array))) == NULL)) {
			fprintf(stderr, "Out of Memory for links_array\n");
			exit(1);
		}
		links_end = links_array + (seqrec_end - seqrec_array);
	}
	for (seqrec_ptr = seqrec_array; seqrec_ptr < seqrec_end; seqrec_ptr++) {
		reset_coords(seqrec_ptr, FALSE);
		seqrec_ptr->link_status = UNLINKED;
	}
	for (seqrec_ptr = seqrec_array; seqrec_ptr < seqrec_end; seqrec_ptr++) {
		if (seqrec_ptr->link_status == LINKED) {
			continue;
		}
		for (links_ptr = links_array; links_ptr < links_end; links_ptr++) {
			*links_ptr = 0;
		}
		con_right_pos = (((seqrec_ptr->end_contig)->latest)->left)->pos;
		con_left_end = (seqrec_ptr->beg_contig)->latest;
		con_left_pos = (con_left_end->right)->pos;
		best_seqrec = con_left_end->best_seqrec;
		con_seq_ptr = con_left_end;
		do {
			seqrec2_ptr = con_seq_ptr->best_seqrec;
			seqrec2_ptr->link_status = LINKED;
			pair_num = seqrec2_ptr->pair;
			if ((pair_num >= 0) && ((pair_best = (((pair_ptr = seqrec_array + pair_num)->beg_contig)->latest)->best_seqrec) != best_seqrec)) {
				seq_dir = IS_FORWARD(seqrec2_ptr);
				pair_dir = IS_FORWARD(pair_ptr);
				if (seq_dir == FORWARD) {
					dist1 = (con_right_pos - (seqrec2_ptr->left)->pos) + 1;
				} else { /* REVERSE */
					dist1 = ((seqrec2_ptr->left)->pos - con_left_pos) + 1;
				}
				if (pair_dir == FORWARD) {
					dist2 = ((((pair_ptr->end_contig)->latest)->left)->pos - (pair_ptr->left)->pos) + 1;
				} else { /* REVERSE */
					dist2 = ((pair_ptr->left)->pos - (((pair_ptr->beg_contig)->latest)->right)->pos) + 1;
				}
				if (((dist1 + dist2) - MAX_MATCH_LEN) <= seqrec2_ptr->max_len) {
					links_array[pair_best - seqrec_array]++;
				}
			}
			con_seq_ptr = con_seq_ptr->best_seg;
		} while (con_seq_ptr != con_left_end);
		do {
			seqrec2_ptr = con_seq_ptr->best_seqrec;
			for (abscore_rec = seqrec2_ptr->score_array; abscore_rec != NULL; abscore_rec = abscore_rec->next) {
				abscore_rec->links = links_array[(((seqrec_array + abscore_rec->seq_num)->beg_contig)->latest)->best_seqrec - seqrec_array];
			}
			con_seq_ptr = con_seq_ptr->best_seg;
		} while (con_seq_ptr != con_left_end);
	}
}
