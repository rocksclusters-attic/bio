/*

Copyright (c) 2003, The Institute for Genomic Research (TIGR), Rockville,
Maryland, U.S.A.  All rights reserved.

*/

#include "typedefs.h"
#include "matrices.h"

#ifndef ALIGN_EXT_H
#define ALIGN_EXT_H

extern int	find_align	(ConPos *, ConPos *, ConPos *, ConPos *, ConPos *, ConPos *,
			 int, int, int, int, SubMat *, int, int, float, int);
extern int	consensus	(ConPos *, int);
extern void	cell_incr	(ConPos *, ConPos *);
extern void	cell_incr_gap	(ConPos *, ConPos *, ConPos *);
extern void	cell_create_gap	(ConPos *, ConPos *, ConPos *);
extern ConPos*	get_latest	(register ConPos *);
extern void	reset_coords	(register SeqRec *, int);
extern void	processScoreRecords	(SeqRec *, SeqRec *, AbScoreRec **, AbScoreRec **, AbScoreRec **,
					 int, int, int, int, int, int, int, int, int, float, int, int,
	 				 float, int, int, float, int, int, float, float, SubMat *);

#endif
