/*

Copyright (c) 2003, The Institute for Genomic Research (TIGR), Rockville,
Maryland, U.S.A.  All rights reserved.

*/

#include "usage_prot.h"

void
usage()
{
	fprintf(stderr, "\
Usage: TIGR_Assembler [options] scratch_file < input_file > output_file\n\
  scratch_file - is the name of temporary data file TIGR_Assembler initially creates and\n\
    later deletes at the end of execution.\n\
  input_file - is the name of the multiple fasta formatted input file of DNA\n\
    sequences. The format of the fasta description line should be:\n\
    >seq_name minimum_clone_length maximum_clone_length median_clone_length clear_end5 clear_end3\n\
    or\n\
    >db|seq_name minimum_clone_length maximum_clone_length median_clone_length clear_end5 clear_end3\n\
    e.g.\n\
    >GHIBF57F 500 3000 1750 33 587\n\
  output_file - is the name of the lassie formatted file which TIGR_Assembler generates\n\
    to describe the set of assemblies TIGR_Assembler constructs. This is basically a flat\n\
    file representation of the assembly and asmbl_link tables.\n\
options:\n\
  -a alignment_directory - is the name of a directory that TIGR_Assembler creates to store\n\
    alignment files in GDE flat format.\n\
  -A ace_output_file - tells TIGR_Assembler to generate \"ace\" output in the file\n\
    name given.\n\
  -c coverage_filename - output coverage file using the coverage_filename\n\
  -C contig_file - is for \"jumpstarting\" the alignment process with a previously\n\
    aligned set of contigs in the same format as the GDE alignment files.\n\
  -d - is a flag saying to use the fasta description line as the description line in the\n\
    \"ace\" file output.\n\
  -D phd_dir - specifies the directory for .phd files for the description line in the\n\
    \"ace\" file output.\n\
  -e maximum_end - is the maximum length at the end of a DNA fragment that does\n\
    not match another overlapping DNA fragment (sometimes referred to as\n\
    overhang) that will not disqualify a DNA fragment from becoming part of an\n\
    assembly.\n\
  -f fasta_file - is the multiple fasta formatted file TIGR_Assembler creates of the\n\
    consensus sequences of all assemblies including singletons.\n\
  -F repeat_file - is the file of repeat information TIGR_Assembler creates based on the\n\
    consensus sequences of all assemblies including singletons.\n\
  -g max_err_32 - is the maximum number + 1 of alignment errors (mismatches\n\
    or gaps) allowed within any contiguous 32 base pairs in the overlap region\n\
    between two DNA fragments in the same assembly. This is meant to split apart\n\
    splice variants which have short splice differences and would not be\n\
    disqualified by the -p minimum_percent parameter.\n\
  -J dump_file - is the file of profile information TIGR_Assembler creates based on the\n\
    consensus sequences of all assemblies including singletons if -s is used.\n\
  -l minimum_length - is the minimum length two DNA fragments must overlap to\n\
    be considered as a possible assembly.\n\
  -L - is a flag which causes even very LOW pairwise scores to be considered - caution\n\
    using this flag may cause longer run time and a worse assembly.\n\
  -n asm_prefix - is the prefix for assembly names in the fasta file and file\n\
    names in the alignment directory - default is \"asm\".\n\
  -N - is a flag which indicates the DNA fragments in the input_file should not\n\
    be treated as random genomic fragments for the purpose of determining repeat\n\
    regions.\n\
  -O order_file - specifies which sequences should be merged first in what order.\n\
    The format is three fields per line: # seq_name1 seq_name2  - but seq_name2 is\n\
    optional. Larger numbers in the first field are merged first. If seq_name2 is not\n\
    given then all sequences matching seq_name1 will be merged first.\n\
  -p minimum_percent - is the minimum percent identity that two DNA fragments\n\
    must achieve over their entire region of overlap in order to be considered\n\
    as a possible assembly. Adjustments are made by the program to take into\n\
    account that the ends of sequences are lower quality and doubled base calls\n\
    are the most frequent sequencing error.\n\
  -P - is a flag which indicates the contig_file is in \"ace\" format.\n\
  -q quality_file - is a multiple fasta format file of quality values corresponding\n\
    to the sequences in the input_file. The quality values must be in the same order\n\
    as the sequences - however sequences without quality values may be skipped.\n\
  -r resort# - specifies how many sequences should be merged before resorting the\n\
    possible merges based on clone constraints.\n\
  -R - is a flag which causes no new merging to take place but just generates a\n\
    reverse compliment of the contig_file.\n\
  -s - is a flag which indicates that singletons (assemblies made up of a single\n\
    DNA fragment) should be included in the lassie output_file - the default is\n\
    not to include singletons.\n\
  -S max_span_len - max_span_len is the maximum size of clones to be used to determine\n\
    which repeats are spanned by clones (only use with -F option) default is 5000.\n\
  -t - is a flag which causes tandem 32mers (a tandem 32mer is a 32mer which occurs\n\
    more than once in at least one sequence read) to be ignored (this is now the default\n\
    behavior and this flag is for backward compatability).\n\
  -T - is a flag which causes no new merging to take place but just a translation of\n\
    the contig_file from one format to another.\n\
  -u - is a flag which causes tandem 32mers to be used for pairwise comparison opposite\n\
    of the -t flag which is now the default).\n\
  -x - is a flag which causes sequences which appear in the contig file (-C option)\n\
    but not in the input_file to be ignored (usually TIGR Assembler exits).\n\
  -X - is a flag which causes merging to stop when only sequences which appear to be\n\
    repeats are left and these cannot be merged based on clone length constraints.\n\
  -y repeat_num_cutoff - repeat_num_cutoff is the number of sequences a contig must\n\
    have more than in order to be used to determine repeats for the -F option\n\
    (default is 1 - use 0 to include singletons).\n\
  -z num_conflicts - num_conflicts is the number of quality conflicts a sequence must\n\
    have with the consensus sequence to be left out of the GDE .align file if a good\n\
    clone mate does not exist in the same assembly (default is 2).\n\
  -Z - is a flag which causes sequences which appear to be misassembled due to being\n\
    contained in a repeat or having quality conflicts (see -z) and not having a good\n\
    clone mate in the same assembly to be left out of the GDE .align file.\n\
");
	return;
}
