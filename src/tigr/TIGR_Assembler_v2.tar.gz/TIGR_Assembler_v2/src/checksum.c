/*

Copyright (c) 2003, The Institute for Genomic Research (TIGR), Rockville,
Maryland, U.S.A.  All rights reserved.

*/

#include "checksum_prot.h"

unsigned long checkbase(
		register int base,
		register unsigned long checksum
	)
{
		return(crctab[((int)checksum ^ (toupper(base))) & 0xff] ^ (checksum >> 8));
}

unsigned long checkinit()
{
	return(0xffffffffUL);
}

unsigned long checkfinal(
		register unsigned long checksum
	)
{
		return(checksum ^ 0xffffffffUL);
}
