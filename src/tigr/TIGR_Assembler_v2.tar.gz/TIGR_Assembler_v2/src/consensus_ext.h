/*

Copyright (c) 2003, The Institute for Genomic Research (TIGR), Rockville,
Maryland, U.S.A.  All rights reserved.

*/

#include <stdio.h>
#include "typedefs.h"
#include "matrices.h"

#ifndef CONSENSUS_EXT_H
#define CONSENSUS_EXT_H

extern void	defineSequenceRecords	(SeqRec **, int *, int *, int *, int *, 
					 FILE *, FILE *, FILE *, int);
extern void	defineExistingContigs	(SeqRec **, int *, int *, int *, int *,
					 FILE *, int, int);
extern void	cell_incr_unlink	(ConPos *, ConPos *);
extern ConPos*	cell_new_gap		(ConPos *, ConPos *);
extern void	create_conseq		(ConPos *, char *, char *, ConPos *,
					 ConPos *, IncMat *, SeqRec *);
extern void	fix_seqrec_ptr		(SeqRec *);
extern void*	allocateConsensus	(SeqRec *, SeqRec *, IncMat *, FILE *);
extern void	revcomp			(char *, int);
extern void	revcomp_contig		(ConPos *);
extern void	check_realpos		(ConPos *, ConPos *);
extern void	print_consensus		(ConPos *, ConPos *);

#endif
