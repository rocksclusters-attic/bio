/*

Copyright (c) 2003, The Institute for Genomic Research (TIGR), Rockville,
Maryland, U.S.A.  All rights reserved.

*/

#include	"comparisons_ext.h"
#include	"consensus_ext.h"
#include	"relink_ext.h"
#include	"scoring_ext.h"

#include	"align_prot.h"

int
find_align(
		ConPos *query_seq,
		ConPos *qseq_end,
		ConPos *q_match,
		ConPos *db_seq,
		ConPos *dbseq_end,
		ConPos *db_match,
		int qseq_len,
		int dbseq_len,
	   	int row_match,
		int col_match,
		SubMat *sub_matrix,
		int min_len,
		int max_end,
		float min_per,
		int max_err_32
	)
{
ConPos	*db_beg = db_seq,
	*db_end = db_match;
int	trace_extra = dbseq_len - col_match;
int	cur_match, bad_zone, max_good;
int	prev_char, cur_char, next_char;
int	repeat;
int	db_prev_char, db_cur_char, db_next_char;
char	*trace_back, *trace_ptr, *trace_start;
int	NWest, North, West;
int	Max1, Max2;
int	maxscore;
int	err_decr, old_err_decr, query_good, db_good;
int	double_w;
int	offset;
SubMat	*firstindex, *gapindex, *cur_firstindex, *cur_gapindex;
SimCel	*ptr_row0, *ptr_row1, *ptr_row0_j, *ptr_row1_j, *row_end, *swap_row;
SimCel	*free_ptr_row0, *free_ptr_row1;
ConPos	*dbseq_ptr, *next_dbseq_ptr;
ConPos	*qseq_ptr, *next_qseq_ptr;
int	best_score, debug_best_score;
int	i, row, col, start_row, start_col, first_col;
int	dbseq_len_p1 = dbseq_len + 1;
int	max_col = dbseq_len - max_end, max_row = qseq_len - max_end;
int	min_col = max_end + 1, min_row = max_end + 1;
int	restart, ext_beg, ext_end, q_ext_beg, q_ext_end;
int	debug_maxscore;
char	*debug_trace_start;
int	debug_row, debug_col, debug_start_row, debug_start_col;
int	return_val;
int	max_overhang, max_overhang2, align_len;
int	WestGap, realGap, QrealGap;
int	realpos, pos;
int	score1, score2;
int	reset_col = FALSE, reset_count = 0;

	max_err_32 *= 2;
	max_err_32--;
	if (row_match > max_row) {
		max_row = row_match;
	}
	if (col_match > max_col) {
		max_col = col_match;
	}
	if (row_match < min_row) {
		min_row = row_match;
	}
	if (col_match < min_col) {
		min_col = col_match;
	}
#ifdef DEBUG
	fprintf(stderr, "find_align q_len %d, db_len %d, min_len %d, max_end %d, min_per %f, max_err_32 %d, row_match %d, col_match %d\n", qseq_len, dbseq_len, min_len, max_end, min_per, max_err_32, row_match, col_match);
	fflush(stderr);
#endif
	free_ptr_row0 = ptr_row0 = (SimCel *)malloc((unsigned)(dbseq_len_p1 * sizeof(*ptr_row0)));
	free_ptr_row1 = ptr_row1 = (SimCel *)malloc((unsigned)(dbseq_len_p1 * sizeof(*ptr_row1)));
	trace_back = (char *)malloc((unsigned)((qseq_len + 1) * dbseq_len_p1 * sizeof(*trace_back)));
	if ((ptr_row1 == NULL) || (ptr_row0 == NULL) || (trace_back == NULL)) {
		fprintf(stderr, "WARNING: Out of Memory in find_align\n");
		free((char *)free_ptr_row0);
		free((char *)free_ptr_row1);
		free((char *)trace_back);
		return(OUT_OF_MEMORY);
	}
	trace_ptr = trace_back;
	for (ptr_row0_j = ptr_row0, row_end = ptr_row0 + col_match, col = 1; ptr_row0_j <= row_end; ptr_row0_j++, trace_ptr++, col++) {
		ptr_row0_j->score = 0;
		ptr_row0_j->max = 0;
		ptr_row0_j->row = 1;
		ptr_row0_j->col = col;
		ptr_row0_j->queue = (unsigned)0xFFFFFFFF;
		ptr_row0_j->cur_match = max_err_32;
		ptr_row0_j->NorthGap = FALSE;
		*trace_ptr = STOP;
	}
	trace_ptr += trace_extra;
	ptr_row1_j = ptr_row1;
	ptr_row1_j->score = 0;
	ptr_row1_j->max = 0;
	ptr_row1_j->col = 1;
	ptr_row1_j->queue = (unsigned)0xFFFFFFFF;
	ptr_row1_j->cur_match = max_err_32;
	ptr_row1_j->NorthGap = FALSE;
	maxscore = 0;
	debug_maxscore = 0;
	start_row = 1;
	start_col = 1;
	trace_start = trace_back;
	first_col = 2;

	for (
		qseq_ptr = query_seq,
		next_qseq_ptr = qseq_ptr->right,
		prev_char = (int)(qseq_ptr->left)->cons_val,
		cur_char = (int)qseq_ptr->cons_val,
		next_char = (int)next_qseq_ptr->cons_val,
		row = 2;

		TRUE;
	
		qseq_ptr = next_qseq_ptr,
		next_qseq_ptr = next_qseq_ptr->right,
		row++,
		prev_char = cur_char,
		cur_char = next_char,
		next_char = (int)next_qseq_ptr->cons_val
	    ) {

		ptr_row1_j = ptr_row1;
		ptr_row1_j->row = row;
		query_good = (int)qseq_ptr->cons_good;
		firstindex = sub_matrix + cur_char + (query_good * NUM_LABELS);
		gapindex = sub_matrix + DNA_GAP + (query_good * NUM_LABELS);
		if ((query_good <= 1) && (cur_char < NUM_BASES) && ((cur_char == prev_char) || (cur_char == next_char))) {
			repeat = TRUE;
		} else {
			repeat = FALSE;
		}
		QrealGap = (cur_char != DNA_GAP);
		if (qseq_ptr == q_match) {
			db_end = dbseq_end;
			for (
				trace_ptr -= trace_extra,
				ptr_row0_j = ptr_row0 + col_match + 1,
				row_end = ptr_row0 + dbseq_len,
				col = col_match + 2;

				ptr_row0_j <= row_end;

				ptr_row0_j++,
				col++,
				trace_ptr++
			    ) {
				ptr_row0_j->score = 0;
				ptr_row0_j->max = 0;
				ptr_row0_j->row = row - 1;
				ptr_row0_j->col = col;
				ptr_row0_j->queue = (unsigned)0xFFFFFFFF;
				ptr_row0_j->cur_match = max_err_32;
				ptr_row0_j->NorthGap = FALSE;
				*trace_ptr = STOP;
			}
			reset_col = TRUE;
			trace_extra = col_match - 1;
		}
		*trace_ptr = STOP;
		trace_ptr++;
		ptr_row0_j = ptr_row0;
		next_dbseq_ptr = db_beg;
		dbseq_ptr = db_beg->left;
		db_prev_char = (int)dbseq_ptr->cons_val;
		db_cur_char = (int)next_dbseq_ptr->cons_val;
		col = first_col;
		WestGap = FALSE;
		do {
			dbseq_ptr = next_dbseq_ptr;
			next_dbseq_ptr = next_dbseq_ptr->right;
			db_next_char = (int)next_dbseq_ptr->cons_val;
			realGap = (db_cur_char != DNA_GAP);
			db_good = dbseq_ptr->cons_good;
			offset = db_good * (6 * NUM_LABELS);
			cur_firstindex = firstindex + offset;
			cur_gapindex = gapindex + offset;
			if ((query_good > 1) && (db_good > 1)) {
				err_decr = 4;
			} else {
				err_decr = 1;
			}
			if (
				(db_good <= 1) &&
				(db_cur_char < NUM_BASES) &&
				(
					(db_cur_char == db_prev_char) ||
					(db_cur_char == db_next_char)
				)
			   ) {
				double_w = TRUE;
			} else {
				double_w = FALSE;
			}
			if (WestGap || double_w) {
				West = ptr_row1_j->score + (cur_gapindex->base[db_cur_char] / 3);
			} else {
				West = ptr_row1_j->score + cur_gapindex->base[db_cur_char];
			}
			ptr_row1_j++;
			cur_match = cur_firstindex->base[db_cur_char];
			if (
				(
					(!realGap) &&
					(ptr_row0_j->NorthGap || repeat)
				) ||
				(
					(!QrealGap) &&
					(WestGap || double_w)
				)
			   ) {
				cur_match /= 3;
			}
			NWest = ptr_row0_j->score + cur_match;
			ptr_row0_j++;
			if (ptr_row0_j->NorthGap || repeat) {
				North = ptr_row0_j->score + (cur_firstindex->base[DNA_GAP] / 3);
			} else {
				North = ptr_row0_j->score + cur_firstindex->base[DNA_GAP];
			}
			if (North < West) {
				Max1 = West;
			} else {
				Max1 = North;
			}
			if (NWest < 0) {
				Max2 = 0;
			} else {
				Max2 = NWest;
			}
			if (Max1 < Max2) {
				Max1 = Max2;
			}
			{ register int	tmp_col, tmp_row;
			if (Max1 <= 0) {
				WestGap = FALSE;
				*trace_ptr = STOP;
				ptr_row1_j->row = tmp_row = row;
				ptr_row1_j->col = tmp_col = col;
				ptr_row1_j->max = 0;
				ptr_row1_j->NorthGap = FALSE;
				ptr_row1_j->queue = (unsigned)0xFFFFFFFF;
				ptr_row1_j->cur_match = max_err_32;
			} else if (Max1 == West) {
				if (realGap) {
					WestGap = TRUE;
				} /* else leave as is */
				*trace_ptr = WEST;
				ptr_row1_j->row = tmp_row = (ptr_row1_j - 1)->row;
				ptr_row1_j->col = tmp_col = (ptr_row1_j - 1)->col;
				ptr_row1_j->max = (ptr_row1_j - 1)->max;
				ptr_row1_j->NorthGap = FALSE;
				ptr_row1_j->cur_match = (ptr_row1_j - 1)->cur_match;
				if (ptr_row1_j->cur_match >= 0) {
					ptr_row1_j->err_val = (ptr_row1_j - 1)->err_val;
					ptr_row1_j->queue = (ptr_row1_j - 1)->queue;
					if (realGap) {
						if (double_w) {
							err_decr = 1;
						}
						if (ptr_row1_j->queue & (unsigned)0x80000000) {
							old_err_decr = 0;
						} else {
							if (ptr_row1_j->err_val & (unsigned)0x80000000) {
								old_err_decr = 1;
							} else {
								old_err_decr = 4;
							}
						}
						old_err_decr -= err_decr;
						ptr_row1_j->cur_match += old_err_decr;
						ptr_row1_j->queue <<= 1;
						ptr_row1_j->err_val <<= 1;
						if (err_decr == 1) {
							ptr_row1_j->err_val++;
						}
					}
				}
			} else if (Max1 == North) {
				WestGap = FALSE;
				*trace_ptr = NORTH;
				ptr_row1_j->row = tmp_row = ptr_row0_j->row;
				ptr_row1_j->col = tmp_col = ptr_row0_j->col;
				ptr_row1_j->max = ptr_row0_j->max;
				if (QrealGap) {
					ptr_row1_j->NorthGap = TRUE;
				} else {
					ptr_row1_j->NorthGap = ptr_row0_j->NorthGap;
				}
				ptr_row1_j->cur_match = ptr_row0_j->cur_match;
				if (ptr_row1_j->cur_match >= 0) {
					ptr_row1_j->err_val = ptr_row0_j->err_val;
					ptr_row1_j->queue = ptr_row0_j->queue;
					if (QrealGap) {
						if (repeat) {
							err_decr = 1;
						}
						if (ptr_row1_j->queue & (unsigned)0x80000000) {
							old_err_decr = 0;
						} else {
							if (ptr_row1_j->err_val & (unsigned)0x80000000) {
								old_err_decr = 1;
							} else {
								old_err_decr = 4;
							}
						}
						old_err_decr -= err_decr;
						ptr_row1_j->cur_match += old_err_decr;
						ptr_row1_j->queue <<= 1;
						ptr_row1_j->err_val <<= 1;
						if (err_decr == 1) {
							ptr_row1_j->err_val++;
						}
					}
				}
			} else { /* if (Max1 == NWest) */
				*trace_ptr = NWEST;
				ptr_row1_j->row = tmp_row = (ptr_row0_j - 1)->row;
				ptr_row1_j->col = tmp_col = (ptr_row0_j - 1)->col;
				ptr_row1_j->max = (ptr_row0_j - 1)->max;
				if (realGap && QrealGap) {
					WestGap = FALSE;
					ptr_row1_j->NorthGap = FALSE;
				} else if (!realGap && !QrealGap) {
					ptr_row1_j->NorthGap = (ptr_row0_j - 1)->NorthGap;
				} else if (realGap) {
					WestGap = TRUE;
					ptr_row1_j->NorthGap = FALSE;
				} else {
					WestGap = FALSE;
					ptr_row1_j->NorthGap = TRUE;
				}
				ptr_row1_j->cur_match = (ptr_row0_j - 1)->cur_match;
				if (ptr_row1_j->cur_match >= 0) {
					ptr_row1_j->err_val = (ptr_row0_j - 1)->err_val;
					ptr_row1_j->queue = (ptr_row0_j - 1)->queue;
					if (realGap || QrealGap) {
						if ((repeat && !realGap) || (double_w && !QrealGap)) {
							err_decr = 1;
						}
						if (ptr_row1_j->queue & (unsigned)0x80000000) {
							old_err_decr = 0;
						} else {
							if (ptr_row1_j->err_val & (unsigned)0x80000000) {
								old_err_decr = 1;
							} else {
								old_err_decr = 4;
							}
						}
						ptr_row1_j->queue <<= 1;
						ptr_row1_j->err_val <<= 1;
						if (cur_match >= GAP_GAP_SCORE) {
							ptr_row1_j->queue++;
						} else {
							old_err_decr -= err_decr;
							if (err_decr == 1) {
								ptr_row1_j->err_val++;
							}
						}
						ptr_row1_j->cur_match += old_err_decr;
					}
				}
			}
			ptr_row1_j->score = Max1;
			if (debug_maxscore < Max1) {
				debug_maxscore = Max1;
				debug_start_row = ptr_row1_j->row;
				debug_start_col = ptr_row1_j->col;
				debug_trace_start = trace_ptr;
				bad_zone = (ptr_row1_j->cur_match < 0);
			}
			if (Max1 > ptr_row1_j->max) {
				ptr_row1_j->max = Max1;
				if (
					(maxscore < Max1) &&
					(col > col_match) &&
					(tmp_row <= row_match) &&
					(tmp_col <= col_match) &&
					(row > row_match) && 
					(
						(col > max_col) || (row > max_row)
					) &&
					(
						(tmp_row <= min_row) || (tmp_col <= min_col)
					) &&
					(ptr_row1_j->cur_match >= 0)
				   ) {
					maxscore = Max1;
					start_row = ptr_row1_j->row;
					start_col = ptr_row1_j->col;
					trace_start = trace_ptr;
				}
			}
			}
			col++;
			trace_ptr++;
			db_prev_char = db_cur_char;
			db_cur_char = db_next_char;
		} while (dbseq_ptr != db_end);
		swap_row = ptr_row0;
		ptr_row0 = ptr_row1;
		ptr_row1 = swap_row;
		if (qseq_ptr == qseq_end) {
			break;
		}
		if (reset_col) {
			reset_count++;
			if (reset_count == 2) {
				reset_col = FALSE;
			} else {
				first_col += (col_match - 1);
				ptr_row0 += (col_match - 1);
				ptr_row1 += (col_match - 1);
				db_beg = db_match;
			}
			ptr_row1_j = ptr_row1;
			ptr_row1_j->score = 0;
			ptr_row1_j->max = 0;
			ptr_row1_j->col = col_match;
			ptr_row1_j->queue = (unsigned)0xFFFFFFFF;
			ptr_row1_j->cur_match = max_err_32;
			ptr_row1_j->NorthGap = FALSE;
		}
		trace_ptr += trace_extra;
	}

	free((char *)free_ptr_row0);
	free((char *)free_ptr_row1);

	row = trace_start - trace_back;
	col = row % dbseq_len_p1;
	row /= dbseq_len_p1;
	debug_row = debug_trace_start - trace_back;
	debug_col = debug_row % dbseq_len_p1;
	debug_row /= dbseq_len_p1;
#ifdef DEBUG
	fprintf(stderr, "find_align maxscore %d, start_col %d, col %d, start_row %d, row %d\n", maxscore, start_col, col, start_row, row);
	fprintf(stderr, "find_align debug_maxscore %d, debug_start_col %d, debug_col %d, debug_start_row %d, debug_row %d\n", debug_maxscore, debug_start_col, debug_col, debug_start_row, debug_row);
	fflush(stderr);
#endif

	return_val = GOOD_MATCH;
	align_len = row - start_row + 1;
	if (align_len < min_len) {
		return_val |= LENGTH_TOO_SHORT;
	}
	if ((start_col > min_col) && (start_row > min_row)) {
		return_val |= POSSIBLE_CHIMERA;
	}
	if ((max_col > col) && (max_row > row)) {
		return_val |= POSSIBLE_CHIMERA;
	}
	max_overhang = (start_col > start_row) ? start_row : start_col;
	max_overhang2 = ((dbseq_len - col) > (qseq_len - row)) ? (qseq_len - row) : (dbseq_len - col);
	if (max_overhang2 > max_overhang) {
		max_overhang = max_overhang2;
	}
	if ((max_overhang * 2) > align_len) {
		return_val |= LENGTH_TOO_SHORT;
	}

	for (i = 1, qseq_ptr = query_seq; i < row; qseq_ptr = qseq_ptr->right, i++);
	for (i = 1, dbseq_ptr = db_seq; i < col; dbseq_ptr = dbseq_ptr->right, i++);

	best_score = 0;
	trace_ptr = trace_start;
	while (*trace_ptr != STOP) {
		if (*trace_ptr == WEST) {
			trace_ptr--;
			max_good = (qseq_ptr->right)->cons_good;
			if (max_good < qseq_ptr->cons_good) {
				max_good = qseq_ptr->cons_good;
			}
			score1 = (sub_matrix + (int)dbseq_ptr->cons_val + ((max_good * NUM_LABELS) + ((int)dbseq_ptr->cons_good * (6 * NUM_LABELS))))->base[(int)dbseq_ptr->cons_val];
			if (score1 > 0) {
				score1 /= 3;
			}
			best_score += score1;
			dbseq_ptr = dbseq_ptr->left;
		} else if (*trace_ptr == NWEST) {
			trace_ptr -= dbseq_len_p1;
			trace_ptr--;
			score1 = (sub_matrix + (int)dbseq_ptr->cons_val + (((int)qseq_ptr->cons_good * NUM_LABELS) + ((int)dbseq_ptr->cons_good * (6 * NUM_LABELS))))->base[(int)dbseq_ptr->cons_val];
			score2 = (sub_matrix + (int)qseq_ptr->cons_val + (((int)qseq_ptr->cons_good * NUM_LABELS) + ((int)dbseq_ptr->cons_good * (6 * NUM_LABELS))))->base[(int)qseq_ptr->cons_val];
			if (dbseq_ptr->cons_val == DNA_GAP) {
				if (score2 > 0) {
					score2 /= 3;
				}
				best_score += score2;
			} else if (qseq_ptr->cons_val == DNA_GAP) {
				best_score += score1;
			} else if (score1 < score2) {
				best_score += score1;
			} else {
				best_score += score2;
			}
			qseq_ptr = qseq_ptr->left;
			dbseq_ptr = dbseq_ptr->left;
		} else { /* == NORTH */
			trace_ptr -= dbseq_len_p1;
			max_good = (dbseq_ptr->right)->cons_good;
			if (max_good < dbseq_ptr->cons_good) {
				max_good = dbseq_ptr->cons_good;
			}
			score1 = (sub_matrix + (int)qseq_ptr->cons_val + (((int)qseq_ptr->cons_good * NUM_LABELS) + (max_good * (6 * NUM_LABELS))))->base[(int)qseq_ptr->cons_val];
			if (score1 > 0) {
				score1 /= 3;
			}
			best_score += score1;
			qseq_ptr = qseq_ptr->left;
		}
	}

	if (best_score <= 0) {
		best_score = 1;
	}
#ifdef DEBUG
	fprintf(stderr, "find_align best_score %d, %%match %f\n", best_score, (((float)maxscore * 100.0) / (float)best_score));
	fflush(stderr);
#endif
	if ((((float)maxscore * 100.0) / (float)best_score) < min_per) {
		return_val |= PERCENT_TOO_SMALL;
	}

	if (return_val != GOOD_MATCH) {
		if (maxscore < debug_maxscore) {
			for (i = 1, qseq_ptr = query_seq; i < debug_row; qseq_ptr = qseq_ptr->right, i++);
			for (i = 1, dbseq_ptr = db_seq; i < debug_col; dbseq_ptr = dbseq_ptr->right, i++);
		
			debug_best_score = 0;
			trace_ptr = debug_trace_start;
			while (*trace_ptr != STOP) {
				if (*trace_ptr == WEST) {
					trace_ptr--;
					max_good = (qseq_ptr->right)->cons_good;
					if (max_good < qseq_ptr->cons_good) {
						max_good = qseq_ptr->cons_good;
					}
					score1 = (sub_matrix + (int)dbseq_ptr->cons_val + ((max_good * NUM_LABELS) + ((int)dbseq_ptr->cons_good * (6 * NUM_LABELS))))->base[(int)dbseq_ptr->cons_val];
					if (score1 > 0) {
						score1 /= 3;
					}
					debug_best_score += score1;
					dbseq_ptr = dbseq_ptr->left;
				} else if (*trace_ptr == NWEST) {
					trace_ptr -= dbseq_len_p1;
					trace_ptr--;
					score1 = (sub_matrix + (int)dbseq_ptr->cons_val + (((int)qseq_ptr->cons_good * NUM_LABELS) + ((int)dbseq_ptr->cons_good * (6 * NUM_LABELS))))->base[(int)dbseq_ptr->cons_val];
					score2 = (sub_matrix + (int)qseq_ptr->cons_val + (((int)qseq_ptr->cons_good * NUM_LABELS) + ((int)dbseq_ptr->cons_good * (6 * NUM_LABELS))))->base[(int)qseq_ptr->cons_val];
					if (dbseq_ptr->cons_val == DNA_GAP) {
						if (score2 > 0) {
							score2 /= 3;
						}
						debug_best_score += score2;
					} else if (qseq_ptr->cons_val == DNA_GAP) {
						debug_best_score += score1;
					} else if (score1 < score2) {
						debug_best_score += score1;
					} else {
						debug_best_score += score2;
					}
					qseq_ptr = qseq_ptr->left;
					dbseq_ptr = dbseq_ptr->left;
				} else { /* == NORTH */
					trace_ptr -= dbseq_len_p1;
					max_good = (dbseq_ptr->right)->cons_good;
					if (max_good < dbseq_ptr->cons_good) {
						max_good = dbseq_ptr->cons_good;
					}
					score1 = (sub_matrix + (int)qseq_ptr->cons_val + (((int)qseq_ptr->cons_good * NUM_LABELS) + (max_good * (6 * NUM_LABELS))))->base[(int)qseq_ptr->cons_val];
					if (score1 > 0) {
						score1 /= 3;
					}
					debug_best_score += score1;
					qseq_ptr = qseq_ptr->left;
				}
			}

			if (debug_best_score <= 0) {
				debug_best_score = 1;
			}
#ifdef DEBUG
			fprintf(stderr, "find_align debug_best_score %d, %%match %f\n", debug_best_score, (((float)debug_maxscore * 100.0) / (float)debug_best_score));
			fflush(stderr);
#endif
			if (((debug_row - debug_start_row + 1) >= min_len) && ((((float)debug_maxscore * 100.0) / (float)debug_best_score) >= min_per)) {
				if (bad_zone) {
					return_val |= SPLICE_VARIANT;
				} else {
					return_val |= POSSIBLE_CHIMERA;
				}
			}
		}
		if ((return_val == PERCENT_TOO_SMALL) && ((((float)maxscore * 100.0) / (float)best_score) >= (min_per - 10.0))) {
			return_val |= POSSIBLE_MATCH;
		}
		free((char *)trace_back);
		return(return_val);
	}

	restart = FALSE;
	if ((start_col < (start_row + EXTRA_EXTEND)) && ((db_seq->left)->left != NULL)) {
		restart = TRUE;
		ext_beg = (5 * (start_row - start_col)) / 4;
		if (ext_beg < 0) {
			ext_beg = 0;
		}
		ext_beg += (2 * EXTRA_EXTEND);
		for (i = 1, db_seq = db_seq->left; ((i < ext_beg) && (db_seq->left != NULL)); db_seq = db_seq->left, i++);
		if (db_seq->left == NULL) {
			db_seq = db_seq->right;
			ext_beg = i - 1;
		}
		q_ext_beg = 0;
	} else if (((start_col + EXTRA_EXTEND) > start_row) && ((query_seq->left)->left != NULL)) {
		restart = TRUE;
		q_ext_beg = (5 * (start_col - start_row)) / 4;
		if (q_ext_beg < 0) {
			q_ext_beg = 0;
		}
		q_ext_beg += (2 * EXTRA_EXTEND);
		for (i = 1, query_seq = query_seq->left; ((i < q_ext_beg) && (query_seq->left != NULL)); query_seq = query_seq->left, i++);
		if (query_seq->left == NULL) {
			query_seq = query_seq->right;
			q_ext_beg = i - 1;
		}
		ext_beg = 0;
	} else {
		ext_beg = 0;
		q_ext_beg = 0;
	}
	if (((dbseq_len - col) < ((qseq_len - row) + EXTRA_EXTEND)) && ((dbseq_end->right)->right != NULL)) {
		restart = TRUE;
		ext_end = (5 * ((qseq_len - row) - (dbseq_len - col))) / 4;
		if (ext_end < 0) {
			ext_end = 0;
		}
		ext_end += (2 * EXTRA_EXTEND);
		for (i = 1, dbseq_end = dbseq_end->right; ((i < ext_end) && (dbseq_end->right != NULL)); dbseq_end = dbseq_end->right, i++);
		if (dbseq_end->right == NULL) {
			dbseq_end = dbseq_end->left;
			ext_end = i - 1;
		}
		q_ext_end = 0;
	} else if ((((dbseq_len - col) + EXTRA_EXTEND) > (qseq_len - row)) && ((qseq_end->right)->right != NULL)) {
		restart = TRUE;
		q_ext_end = (5 * ((dbseq_len - col) - (qseq_len - row))) / 4;
		if (q_ext_end < 0) {
			q_ext_end = 0;
		}
		q_ext_end += (2 * EXTRA_EXTEND);
		for (i = 1, qseq_end = qseq_end->right; ((i < q_ext_end) && (qseq_end->right != NULL)); qseq_end = qseq_end->right, i++);
		if (qseq_end->right == NULL) {
			qseq_end = qseq_end->left;
			q_ext_end = i - 1;
		}
		ext_end = 0;
	} else {
		ext_end = 0;
		q_ext_end = 0;
	}
	if (restart) {
#ifdef DEBUG
		fprintf(stderr, "restarting find_align q_ext_beg %d, q_ext_end %d, ext_beg %d, ext_end %d\n", q_ext_beg, q_ext_end, ext_beg, ext_end);
		fflush(stderr);
#endif
		free((char *)trace_back);
		max_err_32++;
		max_err_32 /= 2;
		return(find_align(query_seq, qseq_end, q_match, db_seq, dbseq_end, db_match,
				  (qseq_len + q_ext_beg + q_ext_end), (dbseq_len + ext_beg + ext_end),
				  (row_match + q_ext_beg), (col_match + ext_beg), sub_matrix, min_len,
				  max_end, min_per, max_err_32));
	}

	for (i = 1, qseq_ptr = query_seq; i <= row; qseq_ptr = qseq_ptr->right, i++);
	qseq_end = qseq_ptr;
	qseq_ptr = qseq_ptr->left;
	for (i = 1, dbseq_ptr = db_seq; i <= col; dbseq_ptr = dbseq_ptr->right, i++);
	dbseq_end = dbseq_ptr;
	dbseq_ptr = dbseq_ptr->left;

	trace_ptr = trace_start;
	while (*trace_ptr != STOP) {
		if (*trace_ptr == WEST) {
			trace_ptr--;
			cell_incr_gap(dbseq_ptr, qseq_ptr, qseq_ptr->right);
			dbseq_ptr = dbseq_ptr->left;
		} else if (*trace_ptr == NWEST) {
			trace_ptr -= dbseq_len_p1;
			trace_ptr--;
			cell_incr(dbseq_ptr, qseq_ptr);
			qseq_ptr = qseq_ptr->left;
			dbseq_ptr = dbseq_ptr->left;
		} else { /* == NORTH */
			trace_ptr -= dbseq_len_p1;
/* need to use next_qseq_ptr because cell_create_gap alters qseq_ptr->left */
			next_qseq_ptr = qseq_ptr->left;
			cell_create_gap(qseq_ptr, dbseq_ptr, dbseq_ptr->right);
			qseq_ptr = next_qseq_ptr;
		}
	}

	if (start_col < start_row) {
		(dbseq_ptr->right)->left = qseq_ptr;
		qseq_ptr->right = dbseq_ptr->right;
		for (; dbseq_ptr->left != NULL; dbseq_ptr = dbseq_ptr->left, qseq_ptr = qseq_ptr->left) {
			if (qseq_ptr->left == NULL) {
				fprintf(stderr, "ERROR: Alignment should have been restarted by increasing left end!\n");
				exit(1);
			}
			dbseq_ptr->latest = (ConPos *)NULL;
		}
		while (qseq_ptr->left != NULL) {
			qseq_ptr = qseq_ptr->left;
		}
		qseq_ptr = qseq_ptr->right;
		dbseq_ptr->right = qseq_ptr;
		qseq_ptr->left = dbseq_ptr;
		start_row = 1;
	} else {
		for (next_dbseq_ptr = dbseq_ptr; qseq_ptr->left != NULL; qseq_ptr = qseq_ptr->left, next_dbseq_ptr = next_dbseq_ptr->left) {
			qseq_ptr->latest = (ConPos *)NULL;
			if (next_dbseq_ptr->left == NULL) {
				fprintf(stderr, "ERROR: Alignment should have been restarted by increasing left end!!\n");
				exit(1);
			}
		}
	}
	qseq_ptr = qseq_end;
	if ((dbseq_len - col) < (qseq_len - row)) {
		(dbseq_end->left)->right = qseq_ptr;
		qseq_ptr->left = dbseq_end->left;
		for (; dbseq_end->right != NULL; dbseq_end = dbseq_end->right, qseq_ptr = qseq_ptr->right) {
			if (qseq_ptr->right == NULL) {
				fprintf(stderr, "ERROR: Alignment should have been restarted by increasing right end!\n");
				exit(1);
			}
			dbseq_end->latest = (ConPos *)NULL;
		}
		while (qseq_ptr->right != NULL) {
			qseq_ptr = qseq_ptr->right;
		}
		qseq_ptr = qseq_ptr->left;
		dbseq_end->left = qseq_ptr;
		qseq_ptr->right = dbseq_end;
		row = qseq_len;
	} else {
		for (next_dbseq_ptr = dbseq_end; qseq_ptr->right != NULL; qseq_ptr = qseq_ptr->right, next_dbseq_ptr = next_dbseq_ptr->right) {
			qseq_ptr->latest = (ConPos *)NULL;
			if (next_dbseq_ptr->right == NULL) {
				fprintf(stderr, "ERROR: Alignment should have been restarted by increasing right end!!\n");
				exit(1);
			}
		}
	}
	next_dbseq_ptr = dbseq_ptr;
	realpos = dbseq_ptr->realpos;
	pos = dbseq_ptr->pos;
	do {
		next_dbseq_ptr->realpos = realpos++;
		if (next_dbseq_ptr->cons_val == DNA_GAP) {
			next_dbseq_ptr->pos = pos;
		} else {
			next_dbseq_ptr->pos = pos++;
		}
		next_dbseq_ptr = next_dbseq_ptr->right;
	} while (next_dbseq_ptr != (ConPos *)NULL);
#ifdef DEBUG
	check_realpos(dbseq_ptr, dbseq_end);
#endif
	free((char *)trace_back);
	return(GOOD_MATCH);
}

int
consensus(
		ConPos *cell_ptr,
		int max_quality
	)
{
int	max, index, i, total;

	total = (int)cell_ptr->total;
	max = (int)cell_ptr->base[DNA_GAP];
	index = DNA_GAP;
	for (i = 0; i < NUM_BASES; i++) {
		if ((int)cell_ptr->base[i] > max) {
			max = (int)cell_ptr->base[i];
			index = i;
		}
	}
	if ((2 * max) > total) {
		cell_ptr->cons_val = index;
		if (max == total) {
			cell_ptr->cons_good = 5;
		} else if ((10 * max) > (9 * total)) {
			cell_ptr->cons_good = 4;
		} else if ((5 * max) > (4 * total)) {
			cell_ptr->cons_good = 3;
		} else if ((4 * max) > (3 * total)) {
			cell_ptr->cons_good = 2;
		} else if ((3 * max) > (2 * total)) {
			cell_ptr->cons_good = 1;
		} else {
			cell_ptr->cons_good = 0;
		}
	} else {
		cell_ptr->cons_val = DNA_XN;
		cell_ptr->cons_good = 0;
	}
	if (cell_ptr->cons_good > max_quality) {
		cell_ptr->cons_good = max_quality;
	}
	return(index);
}

void
cell_incr(
		ConPos *cell_ptr,
		ConPos *inc_ptr
	)
{
ConPos	*tmp_ptr;
	cell_ptr->base[DNA_A] += inc_ptr->base[DNA_A];
	cell_ptr->base[DNA_C] += inc_ptr->base[DNA_C];
	cell_ptr->base[DNA_G] += inc_ptr->base[DNA_G];
	cell_ptr->base[DNA_TU] += inc_ptr->base[DNA_TU];
	cell_ptr->base[DNA_GAP] += inc_ptr->base[DNA_GAP];
	cell_ptr->total += inc_ptr->total;
	cell_ptr->coverage += inc_ptr->coverage;
	inc_ptr->latest = cell_ptr;
	tmp_ptr = inc_ptr->best_seg;
	inc_ptr->best_seg = cell_ptr->best_seg;
	cell_ptr->best_seg = tmp_ptr;
	consensus(cell_ptr, cell_ptr->cons_good + inc_ptr->cons_good + 2);
	return;
}

void
cell_incr_gap(
		ConPos *new_cell,
		ConPos *left_cell,
		ConPos *right_cell
	)
{
int	min_total, min_coverage, min_good;

	min_total = left_cell->total;
	if ((int)right_cell->total < min_total) {
		min_total = right_cell->total;
	}
	new_cell->base[DNA_GAP] += min_total;
	new_cell->total += min_total;
	min_coverage = left_cell->coverage;
	if ((int)right_cell->coverage < min_coverage) {
		min_coverage = right_cell->coverage;
	}
	new_cell->coverage += min_coverage;
	min_good = left_cell->cons_good;
	if ((int)right_cell->cons_good < min_good) {
		min_good = right_cell->cons_good;
	}
	consensus(new_cell, new_cell->cons_good + min_good);
	return;
}

void
cell_create_gap(
		ConPos *new_cell,
		ConPos *left_cell,
		ConPos *right_cell
	)
{
int	min_total, min_coverage, min_good;

	min_total = left_cell->total;
	if ((int)right_cell->total < min_total) {
		min_total = right_cell->total;
	}
	new_cell->base[DNA_GAP] += min_total;
	new_cell->total += min_total;
	new_cell->right = right_cell;
	new_cell->left = left_cell;
	new_cell->realpos = left_cell->realpos;
	new_cell->pos = left_cell->pos;
	left_cell->right = new_cell;
	right_cell->left = new_cell;
	min_coverage = left_cell->coverage;
	if ((int)right_cell->coverage < min_coverage) {
		min_coverage = right_cell->coverage;
	}
	new_cell->coverage += min_coverage;
	min_good = left_cell->cons_good;
	if ((int)right_cell->cons_good < min_good) {
		min_good = right_cell->cons_good;
	}
	consensus(new_cell, new_cell->cons_good + min_good);
	return;
}

ConPos *
get_latest(
		register ConPos *con_seq_ptr
)
{
register ConPos	*latest;

	for (latest = con_seq_ptr->latest; (latest != (ConPos *)NULL) && (latest != con_seq_ptr); con_seq_ptr = latest, latest = latest->latest);
	return(latest);
}

void
reset_coords(
		register SeqRec *seq_ptr,
		int always
	)
{
register ConPos *con_seq_ptr, *align_ptr, *align_left, *align_right, *left, *right, *align;
register ConPos *beg_contig, *end_contig, *beg_ptr, *end_ptr;

	for (beg_ptr = beg_contig = seq_ptr->beg_contig; beg_ptr->latest != beg_ptr; beg_ptr = beg_ptr->latest);
	for (end_ptr = end_contig = seq_ptr->end_contig; end_ptr->latest != end_ptr; end_ptr = end_ptr->latest);
	beg_contig->latest = beg_ptr;
	end_contig->latest = end_ptr;
	if (beg_ptr->realpos > end_ptr->realpos) {
		seq_ptr->beg_contig = end_contig;
		seq_ptr->end_contig = beg_contig;
	}
	left = seq_ptr->left;
	right = seq_ptr->right;
	if (always || (left->latest != left) || (right->latest != right)) {
		align = seq_ptr->align;
		align_left = align + seq_ptr->align_left;
		align_right = align + seq_ptr->align_right;
		for (align_ptr = align_left; align_ptr <= align_right; align_ptr++) {
			for (
				con_seq_ptr = align_ptr;
				(con_seq_ptr->latest != (ConPos *)NULL) && (con_seq_ptr->latest != con_seq_ptr);
				con_seq_ptr = con_seq_ptr->latest
			    );
			align_ptr->latest = con_seq_ptr->latest;
		}
#ifdef DEBUG
		fprintf(stderr, "reset_coords: align_left %d align_right %d left_pos %d right_pos %d\n", seq_ptr->align_left, seq_ptr->align_right, left->pos, right->pos);
		fflush(NULL);
#endif
		for (;align_left->latest == (ConPos *)NULL; align_left++) {
			if (align_left > align_right) {
				fprintf(stderr, "ERROR: impossible alignment position align_left has crossed align_right!\n");
				exit(1);
			}
		}
		for (;align_right->latest == (ConPos *)NULL; align_right--) {
			if (align_left > align_right) {
				fprintf(stderr, "ERROR: impossible alignment position align_left has crossed align_right!\n");
				exit(1);
			}
		}
		seq_ptr->left = align_left->latest;
		seq_ptr->right = align_right->latest;
		seq_ptr->align_left = align_left - align;
		seq_ptr->align_right = align_right - align;
#ifdef DEBUG
		left = seq_ptr->left;
		right = seq_ptr->right;
		fprintf(stderr, "reset_coords: align_left %d align_right %d left_pos %d right_pos %d\n", seq_ptr->align_left, seq_ptr->align_right, left->pos, right->pos);
		fflush(NULL);
#endif
	}
	return;
}

void
processScoreRecords(
		SeqRec *seqrec_array,
		SeqRec *seqrec_end,
		AbScoreRec **abscore_sort,
		AbScoreRec **absort_end,
		AbScoreRec **resort_end,
		int no_norm,
		int next_restart,
		int merged,
		int score_restart,
		int restart_inc,
		int do_relink,
		int stop_repeats,
		int max_err_32,
		int median_1_5,
		float reg_min_per,
		int reg_min_len,
		int reg_max_end,
		float lax_min_per,
		int lax_min_len,
		int lax_max_end,
		float stringent_min_per,
		int stringent_min_len,
		int stringent_max_end,
		float min_per_incr,
		float min_per_diff,
		SubMat *sub_matrix
	)
{
	AbScoreRec	**absort_ptr,
			*abscore_rec;
	ConPos		*temp_ptr,
			*match_bestseq,
			*left_bestseq,
			*right_bestseq,
			*match_seq_ptr,
			*left_seq_ptr,
			*right_seq_ptr;
	SeqRec		*best_seq,
			*seqrec_ptr;
	int		best_seq_num,
			seq_num,
			pos,
			hit_pos,
			left_pos,
			left_extent_best,
			left_extent_seq,
			right_pos,
			right_extent_best,
			right_extent_seq,
			bestseq_len_over,
			seqrec_len_over,
			col_match,
			row_match,
			min_len,
			max_end,
			tmp_err_32,
			aligned,
			first_stop = TRUE;
	float		min_per;

	for (absort_ptr = abscore_sort; absort_ptr < absort_end; absort_ptr++) {
		abscore_rec = *absort_ptr;
		if (abscore_rec->status != UNTESTED) {
			break;
		}
		if (
			(abscore_rec->dist_from_med == MAX_PAIR_DIST) &&
			(abscore_rec->links == 0) &&
			(abscore_rec->do_first == 0) &&
			(abscore_rec->score <= score_restart)
		   ) {
			score_restart /= 2;
			restart_inc /= 2;
			if (restart_inc < 1) {
				restart_inc = 1;
			}
			next_restart = merged;
			fprintf(stderr,"resorting score restart_inc = %d\n", restart_inc);
			do_relink = TRUE;
		}
		if ((merged >= next_restart) && 
		    (abscore_rec->dist_from_med == MAX_PAIR_DIST)) {
			fprintf(stderr,"resorting %d matches\n", resort_end - absort_ptr);
			fflush(NULL);
			if (do_relink) {
				relink(seqrec_array, seqrec_end);
				do_relink = FALSE;
			}
			next_restart = merged + restart_inc;
			resort_scores(absort_ptr, resort_end, seqrec_array);
			abscore_rec = *absort_ptr;
		}
		if (
			(abscore_rec->score <= (100 * MED1_32_FACTOR)) &&
			(abscore_rec->dist_from_med == MAX_PAIR_DIST)
		   ) {
			if (stop_repeats) {
				if (first_stop) {
					first_stop = FALSE;
					next_restart = merged;
					fprintf(stderr,"resorting first_stop\n");
					absort_ptr--;
					continue;
				} else {
					break;
				}
			} else if ((abscore_rec->do_first == 0) && (abscore_rec->order > median_1_5)) {
				abscore_rec->status = LOW_SCORE;
				continue;
			}
		}
		best_seq_num = abscore_rec->con_seq_num;
		best_seq = seqrec_array + best_seq_num;
		reset_coords(best_seq, FALSE);
		seq_num = abscore_rec->seq_num;
		seqrec_ptr = seqrec_array + seq_num;
		reset_coords(seqrec_ptr, FALSE);
		if (
			(
				(((seqrec_ptr->end_contig)->latest)->left)->realpos - 
				(((seqrec_ptr->beg_contig)->latest)->right)->realpos
			) >
			(
				(((best_seq->end_contig)->latest)->left)->realpos -
				(((best_seq->beg_contig)->latest)->right)->realpos
			)
		   ) {
			seqrec_ptr = best_seq;
			best_seq_num = seq_num;
			best_seq = seqrec_array + best_seq_num;
			seq_num = abscore_rec->con_seq_num;
			pos = (int)abscore_rec->hit_pos;
			hit_pos = (int)abscore_rec->pos;
		} else {
			pos = (int)abscore_rec->pos;
			hit_pos = (int)abscore_rec->hit_pos;
		}
#ifdef SHOWHITS
		fprintf(stderr, "%s vs %s score %d hits %d stat %d F/R %d pos %d h_pos %d dist %d #%d ord %d do %d ln %d\n", best_seq->name, seqrec_ptr->name, (int)abscore_rec->score, (int)abscore_rec->hits, (int)abscore_rec->status, (int)abscore_rec->strand, pos, hit_pos, abscore_rec->dist_from_med, (int)abscore_rec->num_matches, (int)abscore_rec->order, (int)abscore_rec->do_first, (int)abscore_rec->links);
#endif
#ifdef DEBUG
		fprintf(stderr, "best_seq: %d - %d, seq: %d - %d\n", (int)(((best_seq->beg_contig)->latest)->right)->pos, (int)(((best_seq->end_contig)->latest)->left)->pos, (int)(((seqrec_ptr->beg_contig)->latest)->right)->pos, (int)(((seqrec_ptr->end_contig)->latest)->left)->pos);
		fprintf(stderr, "best_seq_con_len %d, seq_con_len %d\n", (int)((((best_seq->end_contig)->latest)->left)->realpos - (((best_seq->beg_contig)->latest)->right)->realpos), (int)((((seqrec_ptr->end_contig)->latest)->left)->realpos - (((seqrec_ptr->beg_contig)->latest)->right)->realpos));
		fflush(NULL);
#endif
		if ((seqrec_ptr->beg_contig)->latest == (best_seq->beg_contig)->latest) {
#ifdef SHOWHITS
			fprintf(stderr, "already in contig\n");
#endif
			abscore_rec->status = ALREADY_IN;
			continue;
		}
		if (
			(
				(abscore_rec->strand != IS_FORWARD_no_reset(best_seq)) && (IS_FORWARD_no_reset(seqrec_ptr))
			) ||
			(
				(abscore_rec->strand == IS_FORWARD_no_reset(best_seq)) && !(IS_FORWARD_no_reset(seqrec_ptr))
			)
		   ) {
#ifdef DEBUG
			fprintf(stderr, "revcomp_contig\n");
			fflush(NULL);
#endif
			revcomp_contig((seqrec_ptr->end_contig)->latest);
			temp_ptr = seqrec_ptr->beg_contig;
			seqrec_ptr->beg_contig = seqrec_ptr->end_contig;
			seqrec_ptr->end_contig = temp_ptr;
		}
		match_bestseq = left_bestseq = right_bestseq = get_latest(best_seq->align + (pos - 1));
		match_seq_ptr = left_seq_ptr = right_seq_ptr = get_latest(seqrec_ptr->align + (hit_pos - 1));
		if ((left_bestseq == NULL) || (left_seq_ptr == NULL)) {
#ifdef SHOWHITS
			fprintf(stderr, "WARNING aligned match position is NULL\n");
			fflush(NULL);
#endif
			abscore_rec->status = FAILED;
			continue;
		}
		left_extent_best = left_bestseq->pos - (((best_seq->beg_contig)->latest)->right)->pos;
		left_extent_seq = left_seq_ptr->pos - (((seqrec_ptr->beg_contig)->latest)->right)->pos;
		right_extent_best = (((best_seq->end_contig)->latest)->left)->pos - right_bestseq->pos;
		right_extent_seq = (((seqrec_ptr->end_contig)->latest)->left)->pos - right_seq_ptr->pos;
		if (left_extent_best < left_extent_seq) {
			left_bestseq = ((best_seq->beg_contig)->latest)->right;
			left_pos = ((((seqrec_ptr->beg_contig)->latest)->right)->pos + (left_extent_seq - left_extent_best));
			left_pos -= (left_extent_best / 20);
			left_pos -= (2 * EXTRA_EXTEND);
			for (; (left_seq_ptr->left != NULL) && (left_pos < left_seq_ptr->pos); left_seq_ptr = left_seq_ptr->left);
			if (left_seq_ptr->left == NULL) {
				left_seq_ptr = left_seq_ptr->right;
			}
		} else {
			left_seq_ptr = ((seqrec_ptr->beg_contig)->latest)->right;
			left_pos = ((((best_seq->beg_contig)->latest)->right)->pos + (left_extent_best - left_extent_seq));
			left_pos -= (left_extent_seq / 20);
			left_pos -= (2 * EXTRA_EXTEND);
			for (; (left_bestseq->left != NULL) && (left_pos < left_bestseq->pos); left_bestseq = left_bestseq->left);
			if (left_bestseq->left == NULL) {
				left_bestseq = left_bestseq->right;
			}
		}
		if (right_extent_best < right_extent_seq) {
			right_bestseq = ((best_seq->end_contig)->latest)->left;
			right_pos = ((((seqrec_ptr->end_contig)->latest)->left)->pos - (right_extent_seq - right_extent_best));
			right_pos += (right_extent_best / 20);
			right_pos += (2 * EXTRA_EXTEND);
			for (; (right_seq_ptr->right != NULL) && (right_pos > right_seq_ptr->pos); right_seq_ptr = right_seq_ptr->right);
			if (right_seq_ptr->right == NULL) {
				right_seq_ptr = right_seq_ptr->left;
			}
		} else {
			right_seq_ptr = ((seqrec_ptr->end_contig)->latest)->left;
			right_pos = ((((best_seq->end_contig)->latest)->left)->pos - (right_extent_best - right_extent_seq));
			right_pos += (right_extent_seq / 20);
			right_pos += (2 * EXTRA_EXTEND);
			for (; (right_bestseq->right != NULL) && (right_pos > right_bestseq->pos); right_bestseq = right_bestseq->right);
			if (right_bestseq->right == NULL) {
				right_bestseq = right_bestseq->left;
			}
		}
		bestseq_len_over = (right_bestseq->realpos - left_bestseq->realpos) + 1;
		seqrec_len_over = (right_seq_ptr->realpos - left_seq_ptr->realpos) + 1;
		col_match = (match_bestseq->realpos - left_bestseq->realpos) + 1;
		row_match = (match_seq_ptr->realpos - left_seq_ptr->realpos) + 1;
#ifdef DEBUG
		fprintf(stderr, "hit stats: %s vs %s, length %d, seqrec_len_over %d, bestseq_len_over %d, best_seq_len %d\n", best_seq->name, seqrec_ptr->name, seqrec_ptr->len, seqrec_len_over, bestseq_len_over, best_seq->len);
		fprintf(stderr, "left_extent_best %d, left_extent_seq %d, left_pos %d, right_extent_best %d, right_extent_seq %d, right_pos %d\n", left_extent_best, left_extent_seq, left_pos, right_extent_best, right_extent_seq, right_pos);
		fflush(NULL);
#endif
		if ((bestseq_len_over > MAX_MATCH_LEN) || (seqrec_len_over > MAX_MATCH_LEN)) {
#ifdef SHOWHITS
			fprintf(stderr, "exceeded MAX_MATCH_LEN %d\n", (int)MAX_MATCH_LEN);
#endif
			abscore_rec->status = BIG_OVERLAP;
			continue;
		}
		tmp_err_32 = max_err_32;
		if (no_norm) {
			min_per = reg_min_per;
			min_len = reg_min_len;
			max_end = reg_max_end;
		} else if (abscore_rec->score > (100 * MAX_32_FACTOR)) {
			min_per = lax_min_per;
			min_len = lax_min_len;
			max_end = lax_max_end;
			tmp_err_32 += 2;
		} else if (abscore_rec->score > (100 * MED1_32_FACTOR)) {
			min_per = stringent_min_per - (min_per_diff * ((double)(abscore_rec->score - (100 * MED1_32_FACTOR)) / (double)((100 * MAX_32_FACTOR) - (100 * MED1_32_FACTOR))));
			min_len = reg_min_len;
			max_end = reg_max_end;
		} else {
			min_per = stringent_min_per;
			min_len = stringent_min_len;
			max_end = stringent_max_end;
			tmp_err_32 -= 2;
		}
		if (abscore_rec->dist_from_med <= GOOD_DIST) {
			min_per -= min_per_incr;
			min_len -= (reg_min_len / 2);
			max_end += (reg_max_end / 2);
			tmp_err_32 += 2;
		}
		if (tmp_err_32 <= 0) {
			tmp_err_32 = 1;
		}
#ifdef DEBUG
		print_consensus(left_bestseq, right_bestseq->right);
		print_consensus(left_seq_ptr, right_seq_ptr->right);
		fflush(NULL);
#endif
		aligned = find_align(left_seq_ptr, right_seq_ptr, match_seq_ptr, left_bestseq, right_bestseq, match_bestseq,
				 seqrec_len_over, bestseq_len_over, row_match, col_match, sub_matrix, min_len, max_end,
				 min_per, tmp_err_32);
		if (aligned == GOOD_MATCH) {
			merged++;
			fprintf(stderr, "merged(%d)\n", merged);
			abscore_rec->status = MERGED;
			((seqrec_ptr->beg_contig)->latest)->latest = (best_seq->beg_contig)->latest;
			((seqrec_ptr->end_contig)->latest)->latest = (best_seq->end_contig)->latest;
			temp_ptr = (seqrec_ptr->beg_contig)->best_seg;
			(seqrec_ptr->beg_contig)->best_seg = (best_seq->beg_contig)->best_seg;
			(best_seq->beg_contig)->best_seg = temp_ptr;
			temp_ptr = (seqrec_ptr->end_contig)->best_seg;
			(seqrec_ptr->end_contig)->best_seg = (best_seq->end_contig)->best_seg;
			(best_seq->end_contig)->best_seg = temp_ptr;
			reset_coords(seqrec_ptr, FALSE);
#ifdef SHOWSTATS
			fprintf(stderr, "merge# %d, align_left %d align_right %d left_pos %d right_pos %d\n", merged, seqrec_ptr->align_left, seqrec_ptr->align_right, (seqrec_ptr->left)->pos, (seqrec_ptr->right)->pos);
			fflush(NULL);
#endif
		} else {
#ifdef SHOWHITS
			fprintf(stderr, "failed\n");
#endif
			abscore_rec->status = FAILED;
			if (aligned & (POSSIBLE_CHIMERA | POSSIBLE_MATCH | SPLICE_VARIANT)) {
				if (aligned & POSSIBLE_CHIMERA) {
					fprintf(stderr, "!!%s vs. %s - is a possible chimera/repeat/splice variant/etc\n", seqrec_ptr->name, best_seq->name);
				} else if (aligned & SPLICE_VARIANT) {
					fprintf(stderr, "!!%s vs. %s -  appears to be a splice variant/gene duplication\n", seqrec_ptr->name, best_seq->name);
				} else {
					fprintf(stderr, "!!%s vs. %s - is a slight mismatch due to sequencing error/gene duplication/etc\n", seqrec_ptr->name, best_seq->name);
				}
			}
		}
	}
}
