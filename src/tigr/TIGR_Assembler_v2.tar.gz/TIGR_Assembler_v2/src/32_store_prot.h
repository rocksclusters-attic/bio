/*

Copyright (c) 2003, The Institute for Genomic Research (TIGR), Rockville,
Maryland, U.S.A.  All rights reserved.

*/

#include <stdio.h>
#include <stdlib.h>
#include "typedefs.h"

#ifndef __32_STORE_PROT_H
#define __32_STORE_PROT_H

#define MY_BLOCK	1024

static R32Hash	*free_ptr,
		*store;
static int	left,
		store_size,
		increment;

void	init_32_store	(register int);
void	re_init_32_store(register int);
R32Hash*	get_32	();
R32Hash*	get_32_store	();
void	free_32_store	();

#endif
