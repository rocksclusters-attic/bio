/*

Copyright (c) 2003, The Institute for Genomic Research (TIGR), Rockville,
Maryland, U.S.A.  All rights reserved.

*/

#include "32_store_ext.h"
#include "consensus_ext.h"
#include "quad_store_ext.h"

#include "32_hash_prot.h"

int
initHash(
		int tot_length,
		int num_seqs,
		int est_cov,
		R32Hash ***hash_array,
		R32Hash ***hash_end
	)
{
	R32Hash	**hash_rec;

	init_32_store((2 * (tot_length - (num_seqs * (HASH_IDKEY_SIZE - 1)))) / est_cov);
	init_quad_store((tot_length - (num_seqs * (HASH_IDKEY_SIZE - HASH_STEP_SIZE))) / HASH_STEP_SIZE);
	if ((*hash_array = (R32Hash **)malloc((unsigned)(HASH_TABLE_SIZE * sizeof(**hash_array)))) == NULL) {
		fprintf(stderr, "ERROR: Could not allocate memory for hash_array\n");
		exit(1);
	}
	*hash_end = *hash_array + HASH_TABLE_SIZE;
	for (hash_rec = *hash_array; hash_rec < *hash_end; hash_rec++) {
		*hash_rec = (R32Hash *)NULL;
	}
	return 1;
}
	
int
buildHash(
		SeqRec *seqrec_array,
		SeqRec *seqrec_end,
		R32Hash **hash_array,
		FILE *scratch
	)
{
	SeqRec	*seqrec_ptr;
	R32Hash	*cur,
		*next,
		**prev;
	QuadHash
		*quad_cur;
	int	length,
		seq_num,
		ident1,
		ident2,
		pos;
	char	*char_ptr,
		*char2_ptr,
		inputline[MAX_LINE + 2];
	unsigned short
		quad_val;

	for (seqrec_ptr = seqrec_array; seqrec_ptr < seqrec_end; seqrec_ptr++) {
		seq_num = seqrec_ptr - seqrec_array;
		length = seqrec_ptr->len;
		/* FORWARD STRAND */
		fseek(scratch, seqrec_ptr->class_filepos, 0);
		fread(inputline, sizeof(*inputline), length, scratch);
		char_ptr = inputline;
		char2_ptr = inputline + HASH_KEY_SIZE;
		for (quad_val = 0, ident1 = 0, ident2 = 0, pos = 0; pos < HASH_KEY_SIZE; pos++, char_ptr++, char2_ptr++) {
			ident1 <<= 2;
			ident1 += ((unsigned)*char_ptr);
			ident2 <<= 2;
			ident2 += ((unsigned)*char2_ptr);
			quad_val <<= 1;
			quad_val += (((unsigned)*char_ptr) >> 1);
		}
		pos += HASH_IDENT_SIZE;
		for (; pos <= length; ident1 <<= 2, ident1 += ((unsigned)*char_ptr), ident2 <<= 2, ident2 += ((unsigned)*char2_ptr), quad_val <<= 1, quad_val += (((unsigned)*char_ptr) >> 1), pos++, char_ptr++, char2_ptr++) {
			for (prev = hash_array + quad_val, next = *prev; (next != NULL) && ((ident2 > next->ident2) || ((ident2 == next->ident2) && (ident1 > next->ident1))); prev = &(next->next_hash), next = *prev);
			if ((next == NULL) || (ident2 != next->ident2) || (ident1 != next->ident1)) {
				*prev = cur = get_32();
				cur->count = 1;
				cur->ident1 = ident1;
				cur->ident2 = ident2;
				cur->next_hash = next;
				cur->next = NULL;
				cur->seq_num = seq_num;
				next = cur;
			} else if (next->count == 0) {
			} else if (next->seq_num == seq_num) {
				next->count = 0;
			} else {
				next->seq_num = seq_num;
				(next->count)++;
			}
			if ((pos % HASH_STEP_SIZE) == 0) {
				quad_cur = get_quad();
				quad_cur->seq_num = seq_num;
				quad_cur->pos = pos;
				quad_cur->next = next->next;
				next->next = quad_cur;
			}
		}
		/* REVERSE STRAND virtually identical code */
		revcomp(inputline, length);
		char_ptr = inputline;
		char2_ptr = inputline + HASH_KEY_SIZE;
		for (quad_val = 0, ident1 = 0, ident2 = 0, pos = 0; pos < HASH_KEY_SIZE; pos++, char_ptr++, char2_ptr++) {
			ident1 <<= 2;
			ident1 += ((unsigned)*char_ptr);
			ident2 <<= 2;
			ident2 += ((unsigned)*char2_ptr);
			quad_val <<= 1;
			quad_val += (((unsigned)*char_ptr) >> 1);
		}
		pos += HASH_IDENT_SIZE;
		for (; pos <= length; ident1 <<= 2, ident1 += ((unsigned)*char_ptr), ident2 <<= 2, ident2 += ((unsigned)*char2_ptr), quad_val <<= 1, quad_val += (((unsigned)*char_ptr) >> 1), pos++, char_ptr++, char2_ptr++) {
			for (prev = hash_array + quad_val, next = *prev; (next != NULL) && ((ident2 > next->ident2) || ((ident2 == next->ident2) && (ident1 > next->ident1))); prev = &(next->next_hash), next = *prev);
			if ((next == NULL) || (ident2 != next->ident2) || (ident1 != next->ident1)) {
				*prev = cur = get_32();
				cur->count = 1;
				cur->ident1 = ident1;
				cur->ident2 = ident2;
				cur->next_hash = next;
				cur->next = NULL;
				cur->seq_num = seq_num;
				next = cur;
			} else if (next->count == 0) {
			} else if (next->seq_num == seq_num) {
				next->count = 0;
			} else {
				next->seq_num = seq_num;
				(next->count)++;
			}
		}
	}
	return 1;
}

void
freeHash(
		R32Hash **hash_array
	)
{
	free_quad_store();
	free_32_store();
	free(hash_array);
}
