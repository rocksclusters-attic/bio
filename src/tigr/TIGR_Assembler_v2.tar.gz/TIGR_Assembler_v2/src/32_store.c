/*

Copyright (c) 2003, The Institute for Genomic Research (TIGR), Rockville,
Maryland, U.S.A.  All rights reserved.

*/

#include "32_store_prot.h"

void
init_32_store(
		register int size
	)
{
register R32Hash	*prev, *cur, *end;

	size = ((size / MY_BLOCK) + 1) * MY_BLOCK;
	if ((free_ptr = (R32Hash *)malloc((unsigned)((size + 1) * sizeof(*free_ptr)))) == NULL) {
		fprintf(stderr, "ERROR: Could not allocate memory for hash 32 records\n");
		exit(1);
	}
	store_size = size;
	increment = ((size / (10 * MY_BLOCK)) + 1) * MY_BLOCK;
	free_ptr->next_hash = (R32Hash *) NULL;
	store = free_ptr;
	free_ptr++;
	left = size;
#ifdef DEBUG
	fprintf(stderr, "init_32_store: left = %d\n", left);
	fflush(stderr);
#endif
	return;
}

void
re_init_32_store(
		register int size
	)
{

	if ((free_ptr = (R32Hash *)malloc((unsigned)((size + 1) * sizeof(*free_ptr)))) == NULL) {
		fprintf(stderr, "ERROR: Could not allocate memory for hash 32 records\n");
		exit(1);
	}
	store_size += size;
	free_ptr->next_hash = store;
	store = free_ptr;
	free_ptr++;
	left = size;
#ifdef DEBUG
	fprintf(stderr, "re_init_32_store: left = %d\n", left);
	fflush(stderr);
#endif
	return;
}

R32Hash *
get_32()
{
register R32Hash	*ptr;

	ptr = free_ptr;
	if (!left) {
#ifdef DEBUG
		fprintf(stderr, "Ran out of hash 32 records - left = %d (getting more)\n", left);
		fflush(stderr);
#endif
		re_init_32_store(increment);
		ptr = free_ptr;
	}
	free_ptr++;
	left--;
	return(ptr);
}

R32Hash *
get_32_store()
{
	return store;
}

void
free_32_store()
{
register R32Hash	*ptr;

	for (ptr = store; ptr != (R32Hash *)NULL;) {
		store = ptr;
		ptr = ptr->next_hash;
		free(store);
	}
	return;
}

