/*

Copyright (c) 2003, The Institute for Genomic Research (TIGR), Rockville,
Maryland, U.S.A.  All rights reserved.

*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <ctype.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <errno.h>
#include "typedefs.h"
#include "matrices.h"

#ifndef CONSENSUS_PROT_H
#define CONSENSUS_PROT_H

void	defineSequenceRecords	(SeqRec **, int *, int *, int *, int *, 
				 FILE *, FILE *, FILE *, int);
void	defineExistingContigs	(SeqRec **, int *, int *, int *, int *,
				 FILE *, int, int);
void	cell_incr_unlink	(ConPos *, ConPos *);
ConPos*	cell_new_gap		(ConPos *, ConPos *);
void	create_conseq		(ConPos *, char *, char *, ConPos *,
				 ConPos *, IncMat *, SeqRec *);
void	fix_seqrec_ptr		(SeqRec *);
void*	allocateConsensus	(SeqRec *, SeqRec *, IncMat *, FILE *);
void	revcomp			(char *, int);
void	revcomp_contig		(ConPos *);
void	check_realpos		(ConPos *, ConPos *);
void	print_consensus		(ConPos *, ConPos *);

#endif
