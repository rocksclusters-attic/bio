/*

Copyright (c) 2003, The Institute for Genomic Research (TIGR), Rockville,
Maryland, U.S.A.  All rights reserved.

*/

#ifndef	MATRICES_H
#define MATRICES_H

#include	<limits.h>

#define NUM_LABELS	17
#define NUM_CLASSES	4
#define NUM_BASES	4
#define MAX_LINE	65536
#define MAX_SEQS	8 * 65536
#define LINE_OUT	60
#define TRUE		1
#define FALSE		0

#define LINKED		0
#define UNLINKED	1
#define TRIED		2
#define NO_MATE		3

#define DONE		0
#define WORKING		1
#define IN_CONTIG	2
#define CONF_IN_CONTIG	3
#define COUNTED		4
#define LOADED		5
#define REP_CONTAIN	6
#define REP_LINKED	7
#define REP_NO_MATE	8
#define ZAP_CONFLICT	9

#define UNASSIGNED	2
#define FORWARD		1
#define REVERSE		0

#define UNTESTED	0
#define REPEAT		1
#define LOW_SCORE	2
#define MERGED		3
#define ALREADY_IN	4
#define FAILED		5
#define BIG_OVERLAP	6
#define DUPLICATE	7

#define BAD_PEP_CHAR	-1
#define SKIP_PEP_CHAR	-2
#define DNA_A		 0
#define DNA_C		 1
#define DNA_G		 2
#define DNA_TU		 3
#define DNA_GAP		 4
#define DNA_XN		 5
#define DNA_M		 6
#define DNA_R		 7
#define DNA_W		 8
#define DNA_S		 9
#define DNA_Y		10
#define DNA_K		11
#define DNA_V		12
#define DNA_H		13
#define DNA_D		14
#define DNA_B		15
#define DNA_dot		16

#define STOP	0
#define NORTH	1
#define WEST	2
#define NWEST	3

#define SCALE_INCR	18

#define ROW_LEN		60
#define ACE_ROW_LEN	50

#define LAX		5
#define REGULAR		2
#define STRINGENT	1

#define PAIR_GOOD	3
#define PAIR_OK		2
#define PAIR_NONE	1
#define PAIR_BAD	0

#define HIST_SIZE	5000

#define GOOD_MATCH		0
#define OUT_OF_MEMORY		01
#define LENGTH_TOO_SHORT	02
#define PERCENT_TOO_SMALL	04
#define POSSIBLE_CHIMERA	010
#define POSSIBLE_MATCH		020
#define SPLICE_VARIANT		040

#define MATCH		32
#define MISMATCH	-95
#define GAP_GAP_SCORE	-3

#define CONS_QUALITY_CUTOFF	3

#define QUALITY_CUTOFF	3
#define QUAL_AMBIG_MULTIPLE			22
#define QUAL_AMBIG_SINGLE			21
#define QUAL_BOTH_NOCONFLICT			 1
#define QUAL_NONQUAL_BOTH_NOCONFLICT		 2
#define QUAL_ONE_CONFIRM_NOCONFLICT		 3
#define NONQUAL_BOTH_NOCONFLICT			 4
#define NONQUAL_ONE_CONFIRM_NOCONFLICT		 5
#define QUAL_SINGLE				 9
#define NONQUAL_SINGLE				11
#define QUAL_BOTH_QCONFLICT			15
#define QUAL_NONQUAL_BOTH_QCONFLICT		16
#define QUAL_ONE_CONFIRM_QCONFLICT		17
#define NONQUAL_BOTH_QCONFLICT			18
#define NONQUAL_ONE_CONFIRM_QCONFLICT		19
#define QUAL_SINGLE_QCONFLICT			20
#define QUAL_BOTH_NQCONFLICT			 6
#define QUAL_NONQUAL_BOTH_NQCONFLICT		 7
#define QUAL_ONE_CONFIRM_NQCONFLICT		 8
#define NONQUAL_BOTH_NQCONFLICT			10
#define NONQUAL_ONE_CONFIRM_NQCONFLICT		12
#define QUAL_SINGLE_NQCONFLICT			13
#define NONQUAL_SINGLE_NQCONFLICT		14
#define NONQUAL_SINGLE_QCONFLICT		23

#define HASH_IDKEY_SIZE	32
#define HASH_IDENT_SIZE	16
#define HASH_KEY_SIZE	16
#define HASH_STEP_SIZE	8
#define HASH_TABLE_SIZE	(64 * 1024)

#define MAX_DIFF_EXTENT	20
#define MAX_MATCH_LEN	4000

#define EXTRA_EXTEND	5

#define MAX_PAIR_DIST	INT_MAX
#define GOOD_DIST	500

#define MAX_32_FACTOR	1000000
#define MED1_32_FACTOR	100000
#define MED2_32_FACTOR	10000
#define MED3_32_FACTOR	1000
#define MED4_32_FACTOR	100
#define MIN_32_FACTOR	10
#define REP_32_FACTOR	1

#define REPEAT_32	1
#define UNIQUE_32	0
#define POOR_QUAL_32	-1

#define MAX_SPAN_LEN	5000

#define MAX_CONFLICTS	2

#define REPEAT_NUM_CUTOFF	1

#endif MATRICES_H
