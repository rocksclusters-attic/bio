/*

Copyright (c) 2003, The Institute for Genomic Research (TIGR), Rockville,
Maryland, U.S.A.  All rights reserved.

*/

#include <stdio.h>
#include "typedefs.h"
#include "matrices.h"

#ifndef OUTPUT_EXT_H
#define OUTPUT_EXT_H

extern void	output	(SeqRec *, SeqRec *, FILE *, FILE *, FILE *, FILE *,
			 char *, char *, char *, int, int, int, int, int, FILE *,
			 int, int, int, FILE *, int);
extern int	offset_compare	(register SeqRec **, register SeqRec **);
extern void	comp_seq	(ConPos *, int);

#endif
