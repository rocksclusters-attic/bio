/*

Copyright (c) 2003, The Institute for Genomic Research (TIGR), Rockville,
Maryland, U.S.A.  All rights reserved.

*/

#include <stdio.h>
#include <stdlib.h>
#include "typedefs.h"
#include "matrices.h"

#ifndef RELINK_PROT_H
#define RELINK_PROT_H

static int	first_time = TRUE,
		*links_array,
		*links_end;

void	relink	(SeqRec *, SeqRec *);

#endif

