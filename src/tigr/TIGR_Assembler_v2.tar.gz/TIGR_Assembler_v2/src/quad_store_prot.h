/*

Copyright (c) 2003, The Institute for Genomic Research (TIGR), Rockville,
Maryland, U.S.A.  All rights reserved.

*/

#include <stdio.h>
#include <stdlib.h>
#include "typedefs.h"

#ifndef QUAD_STORE_PROT_H
#define QUAD_STORE_PROT_H

static	QuadHash	*free_ptr,
			*store;
static	int		left;

void		init_quad_store	(register int);
QuadHash*	get_quad	();
QuadHash*	get_quad_store	();
void		free_quad_store ();

#endif
