/*

Copyright (c) 2003, The Institute for Genomic Research (TIGR), Rockville,
Maryland, U.S.A.  All rights reserved.

*/

#include <stdio.h>
#include <stdlib.h>
#include "typedefs.h"
#include "matrices.h"

#ifndef SCORING_PROT_H
#define SCORING_PROT_H

void	initHisto		(int *);
void	graphRecordCounts	(int *, int *, R32Hash **, R32Hash **);
void	computeRecordStats	(int *, int *, int *, int *, int *, int *, int *,
				 int *, int *, int *, int *, int *, int *);
void	computeRecordScores	(R32Hash **, R32Hash **, int, int, int, int, int, int,
				 int, int, int, int);
void	computePairRecords	(SeqRec *, int, int, int, R32Hash **, int, FILE *);
void	graphSequenceLengths	(int *, SeqRec *, int);
void	computeSequenceStats	(int *, SeqRec *, int, int *, int *, int *, int *, int);
void	normalizeSequences	(SeqRec *, int, int, int);
void	orderByFile		(SeqRec *, int, FILE *);
void	orderScoreRecords	(SeqRec *, int, int, int, int, AbScoreRec **, AbScoreRec **, AbScoreRec ***);
void	printScoreOrder		(SeqRec *, int, AbScoreRec **, AbScoreRec **, char *);
void	resort_scores		(register AbScoreRec **, register AbScoreRec **, register SeqRec *);

#endif
