/*

Copyright (c) 2003, The Institute for Genomic Research (TIGR), Rockville,
Maryland, U.S.A.  All rights reserved.

*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "matrices.h"
#include "typedefs.h"

#ifndef __32_HASH_PROT_H
#define __32_HASH_PROT_H

int	initHash	(int, int, int, R32Hash***, R32Hash***);
int	buildHash	(SeqRec *, SeqRec *, R32Hash **, FILE *);
void	freeHash	(R32Hash **);

#endif
