/*

Copyright (c) 2003, The Institute for Genomic Research (TIGR), Rockville,
Maryland, U.S.A.  All rights reserved.

*/

#include "asmg_global_ext.h"
#include "align_ext.h"
#include "comparisons_ext.h"

#include "consensus_prot.h"

void
defineSequenceRecords(
		SeqRec **ret_seqrec_array,
		int *ret_num_seqs,
		int *ret_tot_length,
		int *ret_merged,
		int *ret_max_full_length,
		FILE *fp_in,
		FILE *fp_qual,
		FILE *scratch,
		int fasta_desc
	)
{
int	num_seqs = *ret_num_seqs, tot_length, max_length, max_full_length, min_length;
SeqRec	*seqrec_fwd, *seqrec_rev, *seqrec_array, *seqrec_ptr, *seqrec_end;
int	no_qual_vals;
char	quality_name[256], clone_name[256];
int	clone_min_len, clone_max_len, clone_med_len;
int	no_vec_left, no_vec_right, clear_left, clear_right, clear_length;
char	*char_ptr, *char2_ptr;
int	*qv_store, *qv_end, *qv2_end, *qv_ptr, *qv2_ptr;
int	*start_good, *end_good, *start_med, *end_med, *start_low, *end_low;
char	*start_clr, *end_clr;
int	bad_char;
char	curchar, prevchar, aa_id;
int	intchar;
int	length;
int	quality_value;
int	q_range_0 = 0, q_range_1 = 19, q_range_2 = 29, q_range_3 = 39, q_range_4 = 99;
int	range_index;
char	*name, *db;
int	name_len;
int	merged;
char	inputline[MAX_LINE];
char	qualityline[MAX_LINE];

	inputline[MAX_LINE - 2] = 0;
	qualityline[MAX_LINE - 2] = 0;
	if ((seqrec_array = (SeqRec *)malloc((unsigned)(num_seqs * sizeof(*seqrec_array)))) == NULL) {
		fprintf(stderr, "ERROR: Could not allocate memory for seqrec_array\n");
		exit(1);
	}
	seqrec_ptr = seqrec_array;
	seqrec_end = seqrec_array + num_seqs;

	tot_length = 0;
	max_length = 0;
	max_full_length = 0;
	min_length = MAX_LINE;

	if (fgets(inputline, MAX_LINE, fp_in) == NULL) {
		fprintf(stderr, "No input!\n");
		exit(1);
	}

	no_qual_vals = FALSE;
	do {
#ifdef DEBUG
		fprintf(stderr, "%d: ", (int)(seqrec_ptr - seqrec_array));
		fputs(inputline, stderr);
		fflush(NULL);
#endif
		if ((fp_qual != NULL) && (!no_qual_vals)) {
			if (fgets(qualityline, MAX_LINE, fp_qual) == NULL) {
				fprintf(stderr, "WARNING: Fewer sequences in quality values file than in sequence file!\n");
				no_qual_vals = TRUE;
				quality_name[0] = '\0';
			} else if (qualityline[MAX_LINE - 2] != '\0') {
				fprintf(stderr, "ERROR: Line too long in quality values file! %s\n", clone_name);
				exit(1);
			}
		}
		clone_min_len = 0;
		clone_med_len = 1600;
		clone_max_len = 10000000;
		no_vec_left = 0;
		no_vec_right = 0;
		clear_left = 0;
		clear_right = 0;
		if (sscanf(inputline, ">%s %d%d%d%d%d%d%d", clone_name, &clone_min_len, &clone_max_len, &clone_med_len, &no_vec_left, &no_vec_right, &clear_left, &clear_right) < 1) {
			fprintf(stderr, "ERROR: Sequence header line is not properly formatted in input file!\n");
			fputs(inputline, stderr);
			exit(1);
		}
		if (inputline[MAX_LINE - 2] != '\0') {
			fprintf(stderr, "ERROR: Line too long in input file! %s\n", clone_name);
			exit(1);
		}
		if (fp_qual != NULL) {
			if (!no_qual_vals) {
				if (sscanf(qualityline, ">%s", quality_name) < 1) {
					fprintf(stderr, "ERROR: Sequence header line is not properly formatted in quality values file!\n");
					fputs(qualityline, stderr);
					exit(1);
				}
			}
			if (strcmp(clone_name, quality_name) != 0) {
				fprintf(stderr, "WARNING: Input file sequence names and quality values file sequence names are not in the same order - %s , %s !\nAssuming no quality values for sequence %s\n", clone_name, quality_name, clone_name);
				no_qual_vals = TRUE;
			} else {
				no_qual_vals = FALSE;
			}
		}
		if (seqrec_ptr >= seqrec_end) {
			if ((seqrec_array = (SeqRec *)realloc((void *)seqrec_array, (unsigned)((2 * num_seqs) * sizeof(*seqrec_array)))) == NULL) {
				fprintf(stderr, "ERROR: Could not allocate memory for seqrec_array\n");
				exit(1);
			}
			seqrec_ptr = seqrec_array + num_seqs;
			num_seqs *= 2;
			seqrec_end = seqrec_array + num_seqs;
		}
		seqrec_ptr->dl_filepos = ftell(scratch);
		fputs(inputline, scratch);
		if (fasta_desc && ((char_ptr = strstr(inputline, "CHROMAT_FILE")) != NULL)) {
			seqrec_ptr->consed_filepos = seqrec_ptr->dl_filepos + (char_ptr - inputline);
		} else {
			seqrec_ptr->consed_filepos = -1;
		}
		bad_char = FALSE;
		for (curchar = (char)(intchar = getc(fp_in)), prevchar = '\n', length = 0, char_ptr = inputline, char2_ptr = qualityline; intchar != EOF; prevchar = curchar, curchar = (char)(intchar = getc(fp_in))) {
			if ((curchar == '>') && (prevchar == '\n')) {
				ungetc(curchar, fp_in);
				break;
			}
			if (((aa_id = trans_char[intchar]) >= 0) && (aa_id != DNA_GAP)) {
				length++;
				if ((fp_qual != NULL) && (!no_qual_vals)) {
					if (fscanf(fp_qual, "%d", &quality_value) != 1) {
						fprintf(stderr, "ERROR: Fewer quality values than nucleotides: ignoring %s\n", clone_name);
						bad_char = TRUE;
					} else {
						if (quality_value > q_range_4) {
							range_index = 5;
						} else if (quality_value > q_range_3) {
							range_index = 4;
						} else if (quality_value > q_range_2) {
							range_index = 3;
						} else if (quality_value > q_range_1) {
							range_index = 2;
						} else if (quality_value > q_range_0) {
							range_index = 1;
						} else {
							range_index = 0;
						}
						*char2_ptr++ = aa_id + (NUM_LABELS * range_index);
					}
				} else {
					*char2_ptr++ = aa_id;
				}
				*char_ptr++ = trans_class[aa_id];
			} else if (aa_id == BAD_PEP_CHAR) {
				fprintf(stderr, "WARNING: Unexpected character '%c' '%d' in sequence: ignoring %s\n", curchar, intchar, clone_name);
				bad_char = TRUE;
			}
		}
		if ((fp_qual != NULL) && (!no_qual_vals)) {
			if (fscanf(fp_qual, "%d", &quality_value) == 1) {
				fprintf(stderr, "ERROR: More quality values than nucleotides: ignoring %s\n", clone_name);
				bad_char = TRUE;
			}
			while (fscanf(fp_qual, "%d", &quality_value) == 1);
		}
		if (bad_char) {
			fseek(scratch, seqrec_ptr->dl_filepos, 0);
			continue;
		}
		if ((no_vec_left <= 0) || (no_vec_left > length)) {
			no_vec_left = 1;
		}
		if ((no_vec_right <= 0) || (no_vec_right > length)) {
			no_vec_right = length;
		}
		if (no_vec_right < no_vec_left) {
			no_vec_right = no_vec_left;
		}
		if ((clear_left <= 0) || (clear_left > length)) {
			clear_left = no_vec_left;
		}
		if ((clear_right <= 0) || (clear_right > length)) {
			clear_right = no_vec_right;
		}
		if (clear_right < clear_left) {
			clear_right = clear_left;
		}
		clear_length = (clear_right - clear_left) + 1;
		if (clear_length < HASH_IDKEY_SIZE) {
			fprintf(stderr, "WARNING: Sequence is too short(%d)! %s\n", clear_length, clone_name);
			fseek(scratch, seqrec_ptr->dl_filepos, 0);
			continue;
		}
		start_clr = qualityline + (clear_left - 1);
		end_clr = qualityline + (clear_right - 1);
		if ((fp_qual == NULL) || no_qual_vals) {
			if (clear_length && ((qv_store = (int *)malloc((unsigned)(clear_length * sizeof(*qv_store)))) == NULL)) {
				fprintf(stderr, "ERROR: Could not allocate memory for qv_store\n");
				exit(1);
			}
			qv_end = qv_store + clear_length;
			start_low = qv_store + 10;
			start_med = qv_store + 20;
			start_good = qv_store + 40;
			if (clear_length < 500) {
				end_good = qv_store + (clear_length * 50) / 100;
				end_med = qv_store + (clear_length * 85) / 100;
				end_low = qv_store + (clear_length * 95) / 100;
			} else {
				end_good = qv_store + (clear_length - 250);
				end_med = qv_store + (clear_length - 75);
				end_low = qv_store + (clear_length - 25);
			}
			for (qv_ptr = qv_store; qv_ptr < start_low; *qv_ptr++ = 0);
			for (; qv_ptr < start_med; *qv_ptr++ = 1);
			for (; qv_ptr < start_good; *qv_ptr++ = 2);
			for (; qv_ptr < end_good; *qv_ptr++ = 3);
			for (; qv_ptr < end_med; *qv_ptr++ = 2);
			for (; qv_ptr < end_low; *qv_ptr++ = 1);
			for (; qv_ptr < qv_end; *qv_ptr++ = 0);
			for (char2_ptr = end_clr, qv_ptr = qv_end - 1; char2_ptr >= start_clr; char2_ptr--, qv_ptr--) {
				if (*char2_ptr == DNA_XN) {
					qv2_end = qv_ptr - 5;
					if (qv2_end < qv_store) {
						qv2_end = qv_store;
					}
					for (qv2_ptr = qv_ptr; qv2_ptr >= qv2_end; qv2_ptr--) {
						*qv2_ptr = 0;
					}
					qv2_end = qv2_ptr - 4;
					if (qv2_end < qv_store) {
						qv2_end = qv_store;
					}
					for (; qv2_ptr >= qv2_end; qv2_ptr--) {
						if (*qv2_ptr > 1) {
							*qv2_ptr = 1;
						}
					}
					qv2_end = qv2_ptr - 4;
					if (qv2_end < qv_store) {
						qv2_end = qv_store;
					}
					for (; qv2_ptr >= qv2_end; qv2_ptr--) {
						if (*qv2_ptr > 2) {
							*qv2_ptr = 2;
						}
					}
				}
			}
			for (char2_ptr = start_clr, qv_ptr = qv_store; char2_ptr <= end_clr; char2_ptr++, qv_ptr++) {
				if (*char2_ptr == DNA_XN) {
					qv2_end = qv_ptr + 6;
					if (qv2_end > qv_end) {
						qv2_end = qv_end;
					}
					for (qv2_ptr = qv_ptr; qv2_ptr < qv2_end; qv2_ptr++) {
						*qv2_ptr = 0;
					}
					qv2_end = qv2_ptr + 5;
					if (qv2_end > qv_end) {
						qv2_end = qv_end;
					}
					for (; qv2_ptr < qv2_end; qv2_ptr++) {
						if (*qv2_ptr > 1) {
							*qv2_ptr = 1;
						}
					}
					qv2_end = qv2_ptr + 5;
					if (qv2_end > qv_end) {
						qv2_end = qv_end;
					}
					for (; qv2_ptr < qv2_end; qv2_ptr++) {
						if (*qv2_ptr > 2) {
							*qv2_ptr = 2;
						}
					}
				}
			}
			for (char2_ptr = start_clr, qv_ptr = qv_store; char2_ptr <= end_clr; *char2_ptr++ += *qv_ptr++ * NUM_LABELS);
			free(qv_store);
		}
		seqrec_ptr->filepos = ftell(scratch);
		fwrite(qualityline, sizeof(*qualityline), length, scratch);
		seqrec_ptr->class_filepos = ftell(scratch);
		fwrite(inputline + (clear_left - 1), sizeof(*inputline), clear_length, scratch);
		seqrec_ptr->no_vec_left = no_vec_left;
		seqrec_ptr->no_vec_right = no_vec_right;
		seqrec_ptr->clear_left = clear_left;
		seqrec_ptr->clear_right = clear_right;
		seqrec_ptr->min_len = clone_min_len;
		seqrec_ptr->med_len = clone_med_len;
		seqrec_ptr->max_len = clone_max_len;
		seqrec_ptr->full_len = length;
		seqrec_ptr->len = clear_length;
		seqrec_ptr->max_score = 0;
		seqrec_ptr->status = WORKING;
		seqrec_ptr->tandem = UNASSIGNED;
		seqrec_ptr->pair = -1;
		seqrec_ptr->score_array = NULL;
		seqrec_ptr->num_conflicts = 0;
		for (db = name = clone_name; TRUE; name++) {
			if ((*name == '|') && (*(name + 1) != '\0')) {
				*name++ = '\0';
				break;
			}
			if (*name == '\0') {
				name = db;
				db = "";
				break;
			}
		}
		if ((seqrec_ptr->name = strdup(name)) == NULL) {
			fprintf(stderr, "ERROR: Could not allocate memory for seqrec_ptr->name\n");
			exit(1);
		}
		if ((seqrec_ptr->db = strdup(db)) == NULL) {
			fprintf(stderr, "ERROR: Could not allocate memory for seqrec_ptr->db\n");
			exit(1);
		}
		name_len = strlen(name);
		if (name_len < 8) {
			seqrec_ptr->direction = UNASSIGNED;
		} else {
			curchar = toupper(name[7]);
			if ((curchar == 'F') || (curchar == 'S')) {
				seqrec_ptr->direction = FORWARD;
			} else if ((curchar == 'R') || (curchar == 'V')) {
				seqrec_ptr->direction = REVERSE;
			} else if (curchar == 'T') {
				curchar = toupper(name[8]);
				if ((curchar == 'F') || (curchar == 'H') || (curchar == '3')) {
					seqrec_ptr->direction = FORWARD;
				} else if ((curchar == 'R') || (curchar == 'V') || (curchar == '7')) {
					seqrec_ptr->direction = REVERSE;
				} else if ((strcmp(&name[8], "644") == 0) || (strcmp(&name[8], "1748") == 0)) {
					seqrec_ptr->direction = FORWARD;
				} else if ((strcmp(&name[8], "646") == 0) || (strcmp(&name[8], "1749") == 0)) {
					seqrec_ptr->direction = REVERSE;
				} else {
					seqrec_ptr->direction = UNASSIGNED;
				}
			} else {
				seqrec_ptr->direction = UNASSIGNED;
			}
			name[7] = '\0';
		}
		if ((seqrec_ptr->clone_name = strdup(name)) == NULL) {
			fprintf(stderr, "ERROR: Could not allocate memory for seqrec_ptr->clone_name\n");
			exit(1);
		}
		seqrec_ptr++;
		if (clear_length < min_length) {
			min_length = clear_length;
		}
		if (clear_length > max_length) {
			max_length = clear_length;
		}
		if (length > max_full_length) {
			max_full_length = length;
		}
		tot_length += clear_length;
	} while (fgets(inputline, MAX_LINE, fp_in) != NULL);
	if (fp_qual != NULL) {
		if (fgets(qualityline, MAX_LINE, fp_qual) != NULL) {
			fprintf(stderr, "More sequences in quality values file than in sequence file!\n");
			exit(1);
		}
	}

	if (max_length > MAX_LINE) {
		fprintf(stderr, "ERROR: Can't handle sequences longer than %d\n sequence of length %d encountered!\n", MAX_LINE, max_length);
		exit(1);
	}
	num_seqs = seqrec_ptr - seqrec_array;
	if (num_seqs > MAX_SEQS) {
		fprintf(stderr, "ERROR: Can't handle more than %d sequences\n %d sequences encountered!\n", MAX_SEQS, num_seqs);
		exit(1);
	}
	if ((seqrec_array = (SeqRec *)realloc((void *)seqrec_array, (unsigned)(num_seqs * sizeof(*seqrec_array)))) == NULL) {
		fprintf(stderr, "ERROR: Could not allocate memory for seqrec_array\n");
		exit(1);
	}
	seqrec_end = seqrec_array + num_seqs;
	qsort((char *)seqrec_array, (size_t)(num_seqs), sizeof(*seqrec_array), clone_name_compare);
	for (seqrec_ptr = seqrec_array; seqrec_ptr < seqrec_end; ) {
		for (; (seqrec_ptr < seqrec_end) && (seqrec_ptr->direction != REVERSE); seqrec_ptr++);
		if (seqrec_ptr >= seqrec_end) {
			break;
		}
		seqrec_rev = seqrec_ptr;
		for (seqrec_ptr++; (seqrec_ptr < seqrec_end) && (strcmp(seqrec_rev->clone_name, seqrec_ptr->clone_name) == 0) && (seqrec_ptr->direction == REVERSE); seqrec_ptr++);
		if (seqrec_ptr >= seqrec_end) {
			break;
		}
		if ((seqrec_ptr->direction != FORWARD) || (strcmp(seqrec_rev->clone_name, seqrec_ptr->clone_name) != 0)) {
			continue;
		}
		seqrec_fwd = seqrec_ptr;
		for (seqrec_ptr = seqrec_rev; seqrec_ptr < seqrec_fwd; seqrec_ptr++) {
			seqrec_ptr->pair = seqrec_fwd - seqrec_array;
		}
		for (; (seqrec_ptr < seqrec_end) && (seqrec_ptr->direction == FORWARD) && (strcmp(seqrec_rev->clone_name, seqrec_ptr->clone_name) == 0); seqrec_ptr++) {
			seqrec_ptr->pair = seqrec_rev - seqrec_array;
		}
	}
	for (seqrec_ptr = seqrec_array; seqrec_ptr < seqrec_end; seqrec_ptr++) {
#ifdef SHOWSTATS
		fprintf(stderr, "seq# %d, name %s, dir %d, pair# %d\n", (int)(seqrec_ptr - seqrec_array), seqrec_ptr->name, (int)seqrec_ptr->direction, seqrec_ptr->pair);
		fflush(NULL);
#endif
		free(seqrec_ptr->clone_name);
		seqrec_ptr->count = 0;
	}
	fprintf(stderr, "input stats: num_seqs %d, tot_length %d, max_length %d, min_length %d, ave_length %d\n", num_seqs, tot_length, max_length, min_length, tot_length / num_seqs);
	fflush(NULL);

	merged = 0;
	*ret_seqrec_array = seqrec_array;
	*ret_num_seqs = num_seqs;
	*ret_tot_length = tot_length;
	*ret_merged = merged;
	*ret_max_full_length = max_full_length;
	return;
}
 
void
defineExistingContigs(
		SeqRec **ret_seqrec_array,
		int *ret_num_seqs,
		int *ret_tot_length,
		int *ret_merged,
		int *ret_max_full_length,
		FILE *fp_contig,
		int contig_ace_format,
		int exclude_seqs
	) 
{
int	num_seqs = *ret_num_seqs, tot_length = *ret_tot_length,
	max_full_length = *ret_max_full_length;
SeqRec	*seqrec_array = *ret_seqrec_array, *seqrec_ptr, *seqrec_end;
char	contig_name[256], seq_name[256];
char	*char_ptr;
char	term_char, *ptr_trans_char;
int	bad_char;
char	curchar, prevchar, aa_id, init_val;
int	intchar;
int	length;
int	merged = *ret_merged;
SeqRec	**seqrec_sort, **sort_ptr;
int	contig_num, contig_num_seqs, contig_len, cur_num_seqs, contig_offset, contig_seq_left, contig_seq_right, contig_skip;
long	contig_filepos;
char	*end_of_input;
ConPos	**contig_array, **contig_ptr, **contig_prev, **contig_next, **contig_end;
SeqRec	search_seqrec;
SeqRec	*first_seq, *cur_seq, *original_seq;
int	forward;
ConPos	*align_ptr, *align_end, *temp_ptr;
int	pos, realpos;
int	i;
int	first_pos;
char	inputline[MAX_LINE];
char	qualityline[MAX_LINE];

	inputline[MAX_LINE - 2] = 0;
	qualityline[MAX_LINE - 2] = 0;
	seqrec_end = seqrec_array + num_seqs;

	if ((seqrec_sort = (SeqRec **)malloc(num_seqs * sizeof(*seqrec_sort))) == NULL) {
		fprintf(stderr, "Out of Memory for seqrec_sort\n");
		exit(1);
	}
	sort_ptr = seqrec_sort;
	for (seqrec_ptr = seqrec_array; seqrec_ptr < seqrec_end; seqrec_ptr++) {
		*sort_ptr++ = seqrec_ptr;
	}
	qsort((char *)seqrec_sort, (size_t)(num_seqs), sizeof(*seqrec_sort), seq_name_compare);
	if (fgets(inputline, MAX_LINE, fp_contig) == NULL) {
		fprintf(stderr, "No contig input!\n");
		exit(1);
	}

#ifdef DEBUG
	fprintf(stderr, "Contig Input\n");
	fflush(NULL);
#endif
	if (contig_ace_format) {
		ptr_trans_char = trans_char_ace;
		term_char = '\n';
	} else {
		ptr_trans_char = trans_char;
		term_char = '#';
	}
	contig_num = 1;
	do {
#ifdef DEBUG
		fprintf(stderr, "%d: ", contig_num);
		fputs(inputline, stderr);
		fflush(NULL);
#endif
		if (inputline[MAX_LINE - 2] != '\0') {
			fprintf(stderr, "ERROR: Line too long in contig input file! %s\n", contig_name);
			exit(1);
		}
		if (contig_ace_format) {
			while (sscanf(inputline, "DNA Contig%s", contig_name) != 1) {
				if (fgets(inputline, MAX_LINE, fp_contig) == NULL) {
					fprintf(stderr, "Unexpected end of contig file while looking for [DNA Contig] line!\n");
					exit(1);
				}
				if (inputline[MAX_LINE - 2] != '\0') {
					fprintf(stderr, "ERROR: Line too long in contig input file! %s\n", contig_name);
					exit(1);
				}
			}
		} else {
			if (sscanf(inputline, "##%s %d%d", contig_name, &contig_num_seqs, &contig_len) != 3) {
				fprintf(stderr, "ERROR: Contig header line is not properly formatted!\n");
				fputs(inputline, stderr);
				exit(1);
			}
		}
		bad_char = FALSE;
		for (curchar = (char)(intchar = getc(fp_contig)), prevchar = '\n', length = 0; intchar != EOF; prevchar = curchar, curchar = (char)(intchar = getc(fp_contig))) {
			if ((curchar == term_char) && (prevchar == '\n')) {
				ungetc(curchar, fp_contig);
				break;
			}
			if ((aa_id = ptr_trans_char[intchar]) >= 0) {
				length++;
			} else if (aa_id == BAD_PEP_CHAR) {
				fprintf(stderr, "WARNING: Unexpected character '%c' '%d' in contig: %s\n", curchar, intchar, contig_name);
				bad_char = TRUE;
			}
		}
		if (bad_char) {
			exit(1);
		}
		if (contig_ace_format) {
			contig_len = length;
			contig_num_seqs = 0;
			while (sscanf(inputline, "Base_segment %d", &i) != 1) {
				if (sscanf(inputline, "Assembled_from* %s %d", seq_name, &contig_offset) == 2) {
					if ((char_ptr = strstr(seq_name, ".comp")) != NULL) {
						*char_ptr = '\0';
					}
					search_seqrec.name = seq_name;
					seqrec_ptr = &search_seqrec;
					if ((sort_ptr = (SeqRec **)bsearch((void *)&seqrec_ptr, (void *)seqrec_sort, (size_t)num_seqs, sizeof(*seqrec_sort), seq_name_compare)) == NULL) {
						if (exclude_seqs) {
							fprintf(stderr, "WARNING: seq_name (%s) in contig (%s) not found in input!\n", seq_name, contig_name);
						} else {
							fprintf(stderr, "ERROR: seq_name (%s) in contig (%s) not found in input!\n", seq_name, contig_name);
							exit(1);
						}
					} else {
						seqrec_ptr = *sort_ptr;
						seqrec_ptr->offset = contig_offset - 1;
						contig_num_seqs++;
					}
				}
				if (fgets(inputline, MAX_LINE, fp_contig) == NULL) {
					fprintf(stderr, "Unexpected end of contig file while looking for [Assembled_from* ] lines!\n");
					exit(1);
				}
				if (inputline[MAX_LINE - 2] != '\0') {
					fprintf(stderr, "ERROR: Line too long in contig input file! %s\n", contig_name);
					exit(1);
				}
			}
		} else {
			if (contig_len != length) {
				fprintf(stderr, "ERROR: Contig header length (%d) does not agree with actual contig length (%d) for contig (%s)\n", contig_len, length, contig_name);
				exit(1);
			}
		}
		if ((contig_array = (ConPos **)malloc((unsigned)((contig_len + 2) * sizeof(*contig_array)))) == NULL) {
			fprintf(stderr, "ERROR: Could not allocate memory for contig_array\n");
			exit(1);
		}
		for (contig_ptr = contig_array++, contig_end = contig_array + contig_len; contig_ptr <= contig_end; contig_ptr++) {
			*contig_ptr = (ConPos *)NULL;
		}

		cur_num_seqs = 0;
		first_seq = NULL;
		while ((end_of_input = fgets(inputline, MAX_LINE, fp_contig)) != NULL) {
			if (inputline[MAX_LINE - 2] != '\0') {
				fprintf(stderr, "ERROR: Line too long in contig input file! %s %s\n", contig_name, seq_name);
				exit(1);
			}
			if (contig_ace_format) {
				while (sscanf(inputline, "DNA %s", seq_name) != 1) {
					if ((end_of_input = fgets(inputline, MAX_LINE, fp_contig)) == NULL) {
						break;
					}
					if (inputline[MAX_LINE - 2] != '\0') {
						fprintf(stderr, "ERROR: Line too long in contig input file! %s\n", contig_name);
						exit(1);
					}
				}
				if ((end_of_input == NULL) || (strncmp(seq_name, "Contig", 6) == 0)) {
					break;
				}
				if ((char_ptr = strstr(seq_name, ".comp")) != NULL) {
					*char_ptr = '\0';
					forward = FALSE;
				} else {
					forward = TRUE;
				}
				cur_num_seqs++;
				if (cur_num_seqs > contig_num_seqs) {
					fprintf(stderr, "ERROR: Assembled_from* lines count (%d) is less\nthan the actual number of sequences for the contig (%s)\n", contig_num_seqs, contig_name);
					fputs(inputline, stderr);
					exit(1);
				}
				contig_filepos = ftell(fp_contig);
				while (sscanf(inputline, "Clipping %d %d", &contig_seq_left, &contig_seq_right) != 2) {
					if ((end_of_input = fgets(inputline, MAX_LINE, fp_contig)) == NULL) {
						fprintf(stderr, "Unexpected end of contig file while looking for [Clipping # #] line!\n");
						exit(1);
					}
					if (inputline[MAX_LINE - 2] != '\0') {
						fprintf(stderr, "ERROR: Line too long in contig input file! %s\n", contig_name);
						exit(1);
					}
				}
				while (sscanf(inputline, "Clipping* %d", &contig_skip) != 1) {
					if ((end_of_input = fgets(inputline, MAX_LINE, fp_contig)) == NULL) {
						fprintf(stderr, "Unexpected end of contig file while looking for [Clipping* # #] line!\n");
						exit(1);
					}
					if (inputline[MAX_LINE - 2] != '\0') {
						fprintf(stderr, "ERROR: Line too long in contig input file! %s\n", contig_name);
						exit(1);
					}
				}
				contig_skip--;
				fseek(fp_contig, contig_filepos, 0);
			} else {
				if (inputline[1] == '#') {
					break;
				}
				cur_num_seqs++;
				if (cur_num_seqs > contig_num_seqs) {
					fprintf(stderr, "ERROR: Contig header line num_seqs field (%d) is less\nthan the actual number of sequences for the contig (%s)\n", contig_num_seqs, contig_name);
					fputs(inputline, stderr);
					exit(1);
				}
				if (sscanf(inputline, "#%[^(](%d)%[^{}]{%d%d}", seq_name, &contig_offset, qualityline, &contig_seq_left, &contig_seq_right) != 5) {
					fprintf(stderr, "ERROR: Contig sequence header line is not properly formatted!\n");
					fputs(inputline, stderr);
					exit(1);
				}
				contig_skip = 0;
			}
#ifdef DEBUG
			fprintf(stderr, "%d: ", cur_num_seqs);
			fputs(inputline, stderr);
			fflush(NULL);
#endif
			search_seqrec.name = seq_name;
			seqrec_ptr = &search_seqrec;
			if ((sort_ptr = (SeqRec **)bsearch((void *)&seqrec_ptr, (void *)seqrec_sort, (size_t)num_seqs, sizeof(*seqrec_sort), seq_name_compare)) == NULL) {
				if (exclude_seqs) {
					fprintf(stderr, "WARNING: seq_name (%s) in contig (%s) not found in input!\n", seq_name, contig_name);
					seqrec_ptr = NULL;
				} else {
					fprintf(stderr, "ERROR: seq_name (%s) in contig (%s) not found in input!\n", seq_name, contig_name);
					exit(1);
				}
			} else {
				seqrec_ptr = *sort_ptr;
			}
			if ((seqrec_ptr == NULL) || (seqrec_ptr->status == IN_CONTIG) || (seqrec_ptr->status == CONF_IN_CONTIG)) {
				if (seqrec_ptr == NULL) {
				} else if (seqrec_ptr->status == IN_CONTIG) {
					fprintf(stderr, "WARNING: sequence (%s) in contig (%s) was already present in this contig - IGNORING!\n", seq_name, contig_name);
				} else if (seqrec_ptr->status == CONF_IN_CONTIG) {
					fprintf(stderr, "WARNING: sequence (%s) in contig (%s) was already present in another contig - IGNORING!\n", seq_name, contig_name);
				}
				for (curchar = (char)(intchar = getc(fp_contig)), prevchar = '\n'; intchar != EOF; prevchar = curchar, curchar = (char)(intchar = getc(fp_contig))) {
					if ((curchar == term_char) && (prevchar == '\n')) {
						ungetc(curchar, fp_contig);
						break;
					}
				}
				continue;
			} else {
				seqrec_ptr->status = IN_CONTIG;
			}
			length = seqrec_ptr->full_len;
			if (contig_ace_format) {
				contig_offset = seqrec_ptr->offset + contig_skip;
			}
			if (contig_offset < 0) {
				fprintf(stderr, "WARNING: offset (%d) is < 0 for sequence (%s) in contig (%s) - trimming these leading bases!\n", contig_offset, seq_name, contig_name);
				contig_skip -= contig_offset;
				contig_seq_left -= contig_offset;
				contig_offset = 0;
			}
			if (contig_ace_format) {
				if (!forward) {
					contig_seq_left = (length - contig_seq_left) + 1;
					contig_seq_right = (length - contig_seq_right) + 1;
				}
			}
			length = seqrec_ptr->len;
			if (contig_seq_left > contig_seq_right) {
				revcomp_contig(seqrec_ptr->end_contig);
				temp_ptr = seqrec_ptr->beg_contig;
				seqrec_ptr->beg_contig = seqrec_ptr->end_contig;
				seqrec_ptr->end_contig = temp_ptr;
				forward = FALSE;
				i = contig_seq_left;
				contig_seq_left = contig_seq_right;
				contig_seq_right = i;
			} else {
				forward = TRUE;
			}
			if ((contig_seq_left < seqrec_ptr->clear_left) || (contig_seq_right > seqrec_ptr->clear_right)) {
				fprintf(stderr, "ERROR: alignment range (%d-%d) is not within clear range (%d-%d) for %s\n", contig_seq_left, contig_seq_right, seqrec_ptr->clear_left, seqrec_ptr->clear_right, seqrec_ptr->name);
				exit(1);
			}
			seqrec_ptr->align_left = contig_seq_left - seqrec_ptr->clear_left;
			seqrec_ptr->align_right = contig_seq_right - seqrec_ptr->clear_left;
			seqrec_ptr->left = seqrec_ptr->align + seqrec_ptr->align_left;
			seqrec_ptr->right = seqrec_ptr->align + seqrec_ptr->align_right;
			for (align_ptr = seqrec_ptr->align, align_end = seqrec_ptr->left; align_ptr < align_end; align_ptr++) {
				align_ptr->latest = (ConPos *)NULL;
			}
			for (align_end = seqrec_ptr->align + length, align_ptr = seqrec_ptr->right + 1; align_ptr < align_end; align_ptr++) {
				align_ptr->latest = (ConPos *)NULL;
			}
			if (forward) {
				align_ptr = seqrec_ptr->left;
				align_end = seqrec_ptr->right + 1;
			} else {
				align_ptr = seqrec_ptr->right;
				align_end = seqrec_ptr->left - 1;
			}
			if (first_seq == NULL) {
				first_seq = seqrec_ptr;
			} else {
				merged++;
			}
			contig_ptr = contig_array + contig_offset;
			bad_char = FALSE;
			for (curchar = (char)(intchar = getc(fp_contig)), prevchar = '\n'; intchar != EOF; prevchar = curchar, curchar = (char)(intchar = getc(fp_contig))) {
				if ((curchar == term_char) && (prevchar == '\n')) {
					ungetc(curchar, fp_contig);
					break;
				}
				if ((aa_id = ptr_trans_char[intchar]) >= 0) {
					if (contig_skip > 0) {
						contig_skip--;
						continue;
					}
					if (contig_ace_format) {
						if (align_ptr == align_end) {
							break;
						}
					} else {
						if (align_ptr == align_end) {
							fprintf(stderr, "WARNING: characters in sequence (%s) exceeds number in alignment range (%d-%d) - IGNORING!\n", seq_name, contig_seq_left, contig_seq_right);
							for (curchar = (char)(intchar = getc(fp_contig)), prevchar = '\n'; intchar != EOF; prevchar = curchar, curchar = (char)(intchar = getc(fp_contig))) {
								if ((curchar == term_char) && (prevchar == '\n')) {
									ungetc(curchar, fp_contig);
									break;
								}
							}
							break;
						}
					}
					if (contig_ptr == contig_end) {
						fprintf(stderr, "WARNING: characters in sequence (%s) exceeds number in contig (%s) - trimming these trailing bases!\n", seq_name, contig_name);
						if (forward) {
							seqrec_ptr->right = align_ptr - 1;
							seqrec_ptr->align_right = seqrec_ptr->right - seqrec_ptr->align;
							for (; align_ptr < align_end; align_ptr++) {
								align_ptr->latest = (ConPos *)NULL;
							}
						} else {
							seqrec_ptr->left = align_ptr + 1;
							seqrec_ptr->align_left = seqrec_ptr->left - seqrec_ptr->align;
							for (; align_ptr > align_end; align_ptr--) {
								align_ptr->latest = (ConPos *)NULL;
							}
						}
						for (curchar = (char)(intchar = getc(fp_contig)), prevchar = '\n'; intchar != EOF; prevchar = curchar, curchar = (char)(intchar = getc(fp_contig))) {
							if ((curchar == term_char) && (prevchar == '\n')) {
								ungetc(curchar, fp_contig);
								break;
							}
						}
						break;
					}
					if (aa_id == DNA_GAP) {
						if (*contig_ptr != NULL) {
							if (forward) {
								cell_incr_gap(*contig_ptr, (align_ptr - 1), align_ptr);
							} else {
								cell_incr_gap(*contig_ptr, (align_ptr + 1), align_ptr);
							}
						} else {
							if (forward) {
								*contig_ptr = cell_new_gap((align_ptr - 1), align_ptr);
							} else {
								*contig_ptr = cell_new_gap((align_ptr + 1), align_ptr);
							}
						}
					} else {
						if (forward) {
							init_val = align_ptr->init_val;
						} else {
							init_val = trans_comp[align_ptr->init_val];
						}
						if (aa_id != init_val) {
							fprintf(stderr, "WARNING: sequence (%s) in contig (%s) appears to have been editted!\n", seq_name, contig_name);
						}
						if (*contig_ptr != NULL) {
							if ((*contig_ptr)->best_seg != NULL) {
							cell_incr(*contig_ptr, align_ptr);
							} else {
								cell_incr_unlink(align_ptr, *contig_ptr);
								*contig_ptr = align_ptr;
							}
						} else {
							*contig_ptr = align_ptr;
						}
						if (forward) {
							align_ptr++;
						} else {
							align_ptr--;
						}
					}
					contig_ptr++;
				}
				else if (aa_id == BAD_PEP_CHAR) {
					fprintf(stderr, "WARNING: Unexpected character '%c' '%d' in sequence: ignoring %s\n", curchar, intchar, seq_name);
					bad_char = TRUE;
				}
			}
			if (align_ptr != align_end) {
				fprintf(stderr, "WARNING: sequence (%s) in contig (%s) has fewer characters than expected!\n", seq_name, contig_name);
				if (forward) {
					seqrec_ptr->right = align_ptr - 1;
					seqrec_ptr->align_right = seqrec_ptr->right - seqrec_ptr->align;
					for (; align_ptr < align_end; align_ptr++) {
						align_ptr->latest = (ConPos *)NULL;
					}
				} else {
					seqrec_ptr->left = align_ptr + 1;
					seqrec_ptr->align_left = seqrec_ptr->left - seqrec_ptr->align;
					for (; align_ptr > align_end; align_ptr--) {
						align_ptr->latest = (ConPos *)NULL;
					}
				}
			}
			if (bad_char) {
				exit(1);
			}
		}
		if (cur_num_seqs < contig_num_seqs) {
			if (contig_ace_format) {
				fprintf(stderr, "ERROR: Assembled_from* lines count (%d) is greater\nthan the actual number of sequences for the contig (%s)\n", contig_num_seqs, contig_name);
			} else {
				fprintf(stderr, "ERROR: Contig header line num_seqs field (%d) is greater\nthan the actual number of sequences for the contig (%s)\n", contig_num_seqs, contig_name);
			}
			exit(1);
		}
		if (contig_num_seqs == 0) {
			fprintf(stderr, "WARNING: Contig (%s) did not specify any underlying sequences - IGNORING!\n", contig_name);
			free(--contig_array);
			continue;
		}
		for (contig_ptr = contig_array; (contig_ptr < contig_end) && (*contig_ptr == NULL); contig_ptr++);
		if (contig_ptr != contig_array) {
			fprintf(stderr, "WARNING: first %d positions of contig (%s) were not supported by any underlying sequences - IGNORING!\n", contig_ptr - contig_array, contig_name);
		}
		for (contig_prev = --contig_end; (contig_end >= contig_ptr) && (*contig_end == NULL); contig_end--);
		if (contig_end != contig_prev) {
				fprintf(stderr, "WARNING: last %d positions of contig (%s) were not supported by any underlying sequences - IGNORING!\n", contig_prev - contig_end, contig_name);
		}
		if (contig_end < contig_ptr) {
			fprintf(stderr, "ERROR: Contig (%s) was not supported by any underlying sequences\n", contig_name);
			exit(1);
		}
		first_seq = (*contig_ptr)->best_seqrec;
		first_seq->status = CONF_IN_CONTIG;
		(first_seq->beg_contig)->right = *contig_ptr;
		(first_seq->beg_contig)->realpos = (first_seq->beg_contig)->pos = 0;
		contig_end++;
		*contig_end = first_seq->end_contig;
		contig_prev = contig_ptr;
		contig_prev--;
		*contig_prev = first_seq->beg_contig;
		pos = realpos = 1;
		for (contig_next = contig_ptr, contig_next++; contig_ptr < contig_end;) {
			align_ptr = *contig_ptr;
			if (align_ptr == NULL) {
				temp_ptr = *contig_prev;
				temp_ptr->right = first_seq->end_contig;
				(first_seq->end_contig)->left = temp_ptr;
				(first_seq->end_contig)->realpos = realpos;
				(first_seq->end_contig)->pos = pos;
#ifdef DEBUG
				check_realpos(first_seq->beg_contig, first_seq->end_contig);
#endif
				first_pos = (contig_ptr - contig_array) + 1;
				for (; (contig_ptr < contig_end) && (*contig_ptr == NULL); contig_ptr++);
				fprintf(stderr, "WARNING: Contig (%s) positions (%d-%d) were not supported by any underlying sequence\n", contig_name, first_pos, contig_ptr - contig_array);
				align_ptr = *contig_ptr;
				first_seq = align_ptr->best_seqrec;
				first_seq->status = CONF_IN_CONTIG;
				(first_seq->beg_contig)->right = *contig_ptr;
				(first_seq->beg_contig)->realpos = (first_seq->beg_contig)->pos = 0;
				*contig_end = first_seq->end_contig;
				contig_prev = contig_ptr;
				contig_prev--;
				*contig_prev = first_seq->beg_contig;
				pos = realpos = 1;
				contig_next = contig_ptr;
				contig_next++;
			}
			if (align_ptr->best_seg != NULL) {
				cur_seq = original_seq = align_ptr->best_seqrec;
				do {
					if (cur_seq->status != CONF_IN_CONTIG) {
						cur_seq->status = CONF_IN_CONTIG;
						(cur_seq->beg_contig)->latest = first_seq->beg_contig;
						(cur_seq->end_contig)->latest = first_seq->end_contig;
						temp_ptr = (cur_seq->beg_contig)->best_seg;
						(cur_seq->beg_contig)->best_seg = (first_seq->beg_contig)->best_seg;
						(first_seq->beg_contig)->best_seg = temp_ptr;
						temp_ptr = (cur_seq->end_contig)->best_seg;
						(cur_seq->end_contig)->best_seg = (first_seq->end_contig)->best_seg;
						(first_seq->end_contig)->best_seg = temp_ptr;
					}
					align_ptr = align_ptr->best_seg;
					cur_seq = align_ptr->best_seqrec;
				} while (cur_seq != original_seq);
				align_ptr->left = *contig_prev;
				align_ptr->right = *contig_next;
				align_ptr->realpos = realpos++;
				if (align_ptr->cons_val == DNA_GAP) {
					align_ptr->pos = pos;
				} else {
					align_ptr->pos = pos++;
				}
				contig_prev = contig_ptr;
			} else {
				temp_ptr = *contig_prev;
				temp_ptr->right = *contig_next;
				free(align_ptr);
			}
			contig_ptr = contig_next;
			contig_next++;
		}
		(first_seq->end_contig)->left = *contig_prev;
		(first_seq->end_contig)->realpos = realpos;
		(first_seq->end_contig)->pos = pos;
#ifdef DEBUG
		check_realpos(first_seq->beg_contig, first_seq->end_contig);
#endif
		free(--contig_array);
		contig_num++;
	} while (end_of_input != NULL);
	free(seqrec_sort);
	*ret_seqrec_array = seqrec_array;
	*ret_num_seqs = num_seqs;
	*ret_tot_length = tot_length;
	*ret_merged = merged;
	*ret_max_full_length = max_full_length;
	return;
}

void
cell_incr_unlink(
		ConPos *cell_ptr,
		ConPos *inc_ptr
	)
{
	cell_ptr->base[DNA_A] += inc_ptr->base[DNA_A];
	cell_ptr->base[DNA_C] += inc_ptr->base[DNA_C];
	cell_ptr->base[DNA_G] += inc_ptr->base[DNA_G];
	cell_ptr->base[DNA_TU] += inc_ptr->base[DNA_TU];
	cell_ptr->base[DNA_GAP] += inc_ptr->base[DNA_GAP];
	cell_ptr->total += inc_ptr->total;
	cell_ptr->coverage += inc_ptr->coverage;
	consensus(cell_ptr, cell_ptr->cons_good + inc_ptr->cons_good + 2);
	free(inc_ptr);
	return;
}

ConPos *
cell_new_gap(
		ConPos *left_cell,
		ConPos *right_cell
	)
{
ConPos	*new_cell;
int	min_total, min_coverage, min_good;

	if ((new_cell = (ConPos *)malloc(sizeof(*new_cell))) == NULL) {
		fprintf(stderr, "Out of Memory for new_cell(new gap)\n");
		exit(1);
	}
	min_total = left_cell->total;
	if ((int)right_cell->total < min_total) {
		min_total = right_cell->total;
	}
	new_cell->base[DNA_A] = 0;
	new_cell->base[DNA_C] = 0;
	new_cell->base[DNA_G] = 0;
	new_cell->base[DNA_TU] = 0;
	new_cell->base[DNA_GAP] = min_total;
	new_cell->total = min_total;
	min_coverage = left_cell->coverage;
	if ((int)right_cell->coverage < min_coverage) {
		min_coverage = right_cell->coverage;
	}
	new_cell->coverage = min_coverage;
	min_good = left_cell->cons_good;
	if ((int)right_cell->cons_good < min_good) {
		min_good = right_cell->cons_good;
	}
	new_cell->cons_val = DNA_GAP;
	new_cell->cons_good = min_good;
	new_cell->latest = new_cell;
	new_cell->best_seg = NULL;
	new_cell->best_seqrec = NULL;
	return(new_cell);
}

void
create_conseq(
		ConPos *align,
		char *sym_ptr,
		char *end_sym,
		ConPos *left_end,
		ConPos *right_end,
		IncMat *incr_matrix,
		SeqRec *seqrec_ptr
	)
{
ConPos	*new_cell;
IncMat	*incr_ptr;
int	realpos;

	left_end->pos = left_end->realpos = realpos = 0;
	left_end->right = align;
	left_end->left = (ConPos *)NULL;
	left_end->base[DNA_A] = 0;
	left_end->base[DNA_C] = 0;
	left_end->base[DNA_G] = 0;
	left_end->base[DNA_TU] = 0;
	left_end->base[DNA_GAP] = 0;
	left_end->total = 0;
	left_end->coverage = 0;
	left_end->init_val = left_end->cons_val = DNA_GAP;
	left_end->init_good = left_end->cons_good = 0;
	left_end->latest = left_end;
	left_end->best_seg = left_end;
	left_end->best_seqrec = seqrec_ptr;
	for (; sym_ptr <= end_sym; sym_ptr++) {
		incr_ptr = incr_matrix + *sym_ptr;
		new_cell = align++;
		new_cell->base[DNA_A] = incr_ptr->base[DNA_A];
		new_cell->base[DNA_C] = incr_ptr->base[DNA_C];
		new_cell->base[DNA_G] = incr_ptr->base[DNA_G];
		new_cell->base[DNA_TU] = incr_ptr->base[DNA_TU];
		new_cell->base[DNA_GAP] = incr_ptr->base[DNA_GAP];
		new_cell->total = incr_ptr->total;
		new_cell->coverage = 1;
		new_cell->init_val = new_cell->cons_val = incr_ptr->init_val;
		new_cell->init_good = new_cell->cons_good = incr_ptr->good;
		new_cell->left = left_end;
		new_cell->pos = new_cell->realpos = ++realpos;
		new_cell->right = align;
		new_cell->latest = new_cell;
		new_cell->best_seg = new_cell;
		new_cell->best_seqrec = seqrec_ptr;
		left_end = new_cell;
	}
	new_cell->right = right_end;
	right_end->left = new_cell;
	right_end->right = (ConPos *)NULL;
	right_end->pos = right_end->realpos = ++realpos;
	right_end->base[DNA_A] = 0;
	right_end->base[DNA_C] = 0;
	right_end->base[DNA_G] = 0;
	right_end->base[DNA_TU] = 0;
	right_end->base[DNA_GAP] = 0;
	right_end->total = 0;
	right_end->coverage = 0;
	right_end->init_val = right_end->cons_val = DNA_GAP;
	right_end->cons_good = right_end->init_good = 0;
	right_end->latest = right_end;
	right_end->best_seg = right_end;
	right_end->best_seqrec = seqrec_ptr;
	return;
}

void
fix_seqrec_ptr(
		SeqRec *seqrec_ptr
	)
{
ConPos	*left_end, *right_end;

	left_end = seqrec_ptr->beg_contig;
	right_end = seqrec_ptr->end_contig;
	do {
		left_end->best_seqrec = seqrec_ptr;
		left_end++;
	} while (left_end <= right_end);
	return;
}

void *
allocateConsensus(
		SeqRec *seqrec_array,
		SeqRec *seqrec_end,
		IncMat *incr_matrix,
		FILE *scratch
	)
{
	char qualityline[MAX_LINE];
	SeqRec *seqrec_ptr;

	qualityline[MAX_LINE - 2] = 0;

	for(seqrec_ptr = seqrec_array; seqrec_ptr < seqrec_end; seqrec_ptr++) {
		fseek(scratch, seqrec_ptr->filepos, SEEK_SET);
		fread(qualityline, sizeof(*qualityline), seqrec_ptr->full_len, scratch);
		if ((seqrec_ptr->align = (ConPos *)malloc((seqrec_ptr->len + 2) * sizeof(*(seqrec_ptr->align)))) == NULL) {
			fprintf(stderr, "Out of Memory for (seqrec_ptr->align)\n");
			exit(1);
		}
		seqrec_ptr->beg_contig = seqrec_ptr->align;
		seqrec_ptr->align++;
		seqrec_ptr->end_contig = seqrec_ptr->align + seqrec_ptr->len;
		create_conseq(seqrec_ptr->align, qualityline + (seqrec_ptr->clear_left - 1), qualityline + (seqrec_ptr->clear_right - 1), seqrec_ptr->beg_contig, seqrec_ptr->end_contig, incr_matrix, seqrec_ptr);
		seqrec_ptr->left = seqrec_ptr->align;
		seqrec_ptr->right = seqrec_ptr->align + (seqrec_ptr->len - 1);
		seqrec_ptr->align_left = 0;
		seqrec_ptr->align_right = (unsigned short)(seqrec_ptr->len - 1);
		fix_seqrec_ptr(seqrec_ptr);
	}
	return NULL;
}

void
revcomp(
		char *f_ptr,
		int len
	)
{
char	*r_ptr, tmp;

	for (r_ptr = f_ptr + len - 1; f_ptr <= r_ptr; f_ptr++, r_ptr--) {
		tmp = *f_ptr;
		*f_ptr = trans_comp[*r_ptr];
		*r_ptr = trans_comp[tmp];
	}
	return;
}

void
revcomp_contig(
		ConPos *right_end
	)
{
int	realpos, pos;
unsigned	temp_base;
ConPos	*temp_ptr;

	pos = realpos = 0;
	do {
		temp_base = right_end->base[DNA_A];
		right_end->base[DNA_A] = right_end->base[DNA_TU];
		right_end->base[DNA_TU] = temp_base;
		temp_base = right_end->base[DNA_C];
		right_end->base[DNA_C] = right_end->base[DNA_G];
		right_end->base[DNA_G] = temp_base;
		right_end->cons_val = trans_comp[right_end->cons_val];
		temp_ptr = right_end->left;
		right_end->left = right_end->right;
		right_end->right = temp_ptr;
		right_end->realpos = realpos++;
		if (right_end->cons_val == DNA_GAP) {
			right_end->pos = pos;
		} else {
			right_end->pos = pos++;
		}
	} while ((right_end = right_end->right) != (ConPos *)NULL);
	return;
}

void
check_realpos(
		ConPos *beg,
		ConPos *end
	)
{
int	realpos;
ConPos	*ptr;

	for (ptr = beg, realpos = ptr->realpos; TRUE; ptr = ptr->right) {
		if (realpos != ptr->realpos) {
			fprintf(stderr, "\nbad realpos %d -> %d\n", realpos, ptr->realpos);
		}
		realpos = ptr->realpos;
		realpos++;
		if (ptr == end) {
			break;
		}
	}
}

void
print_consensus(
		ConPos *beg,
		ConPos *end
	)
{
int	i_align, realpos;
ConPos	*ptr;

	fprintf(stderr, "cons: ");
	i_align = 0;
	for (ptr = beg, realpos = ptr->realpos; ptr != end; ptr = ptr->right) {
		if (realpos != ptr->realpos) {
			fprintf(stderr, "\nbad realpos\n");
		}
		realpos = ptr->realpos;
		realpos++;
		if (i_align >= ROW_LEN) {
			i_align = 0;
			fprintf(stderr, "\n      ");
		}
		fputc((int)trans_case[ptr->cons_val + (ptr->cons_good * NUM_LABELS)], stderr);
		i_align++;
	}
	fprintf(stderr, "\nqual: ");
	i_align = 0;
	for (ptr = beg; ptr != end; ptr = ptr->right) {
		if (i_align >= ROW_LEN) {
			i_align = 0;
			fprintf(stderr, "\n      ");
		}
		fputc((int)'0' + (int)ptr->cons_good, stderr);
		i_align++;
	}
	fputc((int)'\n', stderr);
	fflush(NULL);
}
