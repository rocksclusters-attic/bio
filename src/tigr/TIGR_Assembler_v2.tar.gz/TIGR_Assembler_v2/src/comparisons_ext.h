/*

Copyright (c) 2003, The Institute for Genomic Research (TIGR), Rockville,
Maryland, U.S.A.  All rights reserved.

*/

#include "matrices.h"
#include "typedefs.h"

#ifndef COMPARISONS_EXT_H
#define COMPARISONS_EXT_H

extern int	best_match_compare	(register AbScoreRec **, register AbScoreRec **);
extern int	duplicate_compare	(register AbScoreRec **, register AbScoreRec **);
extern int	clone_name_compare	(register SeqRec *, register SeqRec *);
extern int	seq_name_compare	(register SeqRec **, register SeqRec **);
extern int	count_compare		(register SeqRec **, register SeqRec **);
extern int	IS_FORWARD		(SeqRec *);
extern int	IS_FORWARD_no_reset	(SeqRec *);

#endif
