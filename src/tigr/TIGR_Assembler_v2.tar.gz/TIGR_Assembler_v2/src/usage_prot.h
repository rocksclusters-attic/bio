/*

Copyright (c) 2003, The Institute for Genomic Research (TIGR), Rockville,
Maryland, U.S.A.  All rights reserved.

*/

#include <stdio.h>

#ifndef USAGE_PROT_H
#define USAGE_PROT_H

void	usage	();

#endif
