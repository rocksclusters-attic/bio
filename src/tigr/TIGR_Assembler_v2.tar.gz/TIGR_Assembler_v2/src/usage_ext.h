/*

Copyright (c) 2003, The Institute for Genomic Research (TIGR), Rockville,
Maryland, U.S.A.  All rights reserved.

*/

#ifndef USAGE_EXT_H
#define USAGE_EXT_H

extern void	usage	();

#endif
