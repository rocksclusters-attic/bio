/*

Copyright (c) 2003, The Institute for Genomic Research (TIGR), Rockville,
Maryland, U.S.A.  All rights reserved.

*/

#include <string.h>
#include "matrices.h"
#include "typedefs.h"

#ifndef COMPARISONS_PROT_H
#define COMPARISONS_PROT_H

int	best_match_compare	(register AbScoreRec **, register AbScoreRec **);
int	duplicate_compare	(register AbScoreRec **, register AbScoreRec **);
int	clone_name_compare	(register SeqRec *, register SeqRec *);
int	seq_name_compare	(register SeqRec **, register SeqRec **);
int	count_compare		(register SeqRec **, register SeqRec **);
int	IS_FORWARD		(SeqRec *);
int	IS_FORWARD_no_reset	(SeqRec *);

#endif
