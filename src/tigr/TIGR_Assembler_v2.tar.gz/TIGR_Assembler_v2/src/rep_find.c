/*

Copyright (c) 2003, The Institute for Genomic Research (TIGR), Rockville,
Maryland, U.S.A.  All rights reserved.

*/

#include	"32_hash_ext.h"
#include	"32_store_ext.h"
#include	"asmg_global_ext.h"
#include	"align_ext.h"
#include	"comparisons_ext.h"
#include	"consensus_ext.h"

#include	"rep_find_prot.h"

void
init_asm_32mers(
		register int size
	)
{
R32Asm	**hash_rec, **hash_end;

	if ((hash_array = (R32Asm **)malloc((unsigned)(HASH_TABLE_SIZE * sizeof(*hash_array)))) == NULL) {
		fprintf(stderr, "ERROR: Could not allocate memory for hash_array\n");
		exit(1);
	}
	hash_end = hash_array + HASH_TABLE_SIZE;
	for (hash_rec = hash_array; hash_rec < hash_end; hash_rec++) {
		*hash_rec = (R32Asm *)NULL;
	}
	
	size = ((size / MY_BLOCK) + 1) * MY_BLOCK;
	if ((free_ptr = (R32Asm *)malloc((unsigned)((size + 1) * sizeof(*free_ptr)))) == NULL) {
		fprintf(stderr, "ERROR: Could not allocate memory for hash 32 records\n");
		exit(1);
	}
	store_size = size;
	increment = ((size / (10 * MY_BLOCK)) + 1) * MY_BLOCK;
	free_ptr->next_hash = (R32Asm *)NULL;
	store = free_ptr;
	free_ptr++;
	left = size;
#ifdef DEBUG
	fprintf(stderr, "init_asm_32mers: left = %d\n", left);
	fflush(stderr);
#endif
	return;
}

void
re_init_asm_32mers(
		register int size
	)
{

	if ((free_ptr = (R32Asm *)malloc((unsigned)((size + 1) * sizeof(*free_ptr)))) == NULL) {
		fprintf(stderr, "ERROR: Could not allocate memory for hash 32 records\n");
		exit(1);
	}
	store_size += size;
	free_ptr->next_hash = store;
	store = free_ptr;
	free_ptr++;
	left = size;
#ifdef DEBUG
	fprintf(stderr, "re_init_asm_32mers: left = %d\n", left);
	fflush(stderr);
#endif
	return;
}

R32Asm *
get_32_asm()
{
register R32Asm	*ptr;

	ptr = free_ptr;
	if (!left) {
#ifdef DEBUG
		fprintf(stderr, "Ran out of hash 32 records - left = %d (getting more)\n", left);
		fflush(stderr);
#endif
		re_init_asm_32mers(increment);
		ptr = free_ptr;
	}
	free_ptr++;
	left--;
	return(ptr);
}


void
free_32_store_asm()
{
register R32Asm	*ptr;

	for (ptr = store; ptr != (R32Asm *)NULL;) {
		store = ptr;
		ptr = ptr->next_hash;
		free(store);
	}
	return;
}

void
load_asm_32mers(
		ConPos *con_left_end,
		ConPos *con_right_end
	)
{
ConPos	*con_seq_ptr;
int	length, pos;
int	max, index, i;
char	*con_values, *con_val_ptr;
R32Asm	*cur, **prev, *next;
char	*char_ptr, *char2_ptr;
unsigned	ident1, ident2;
unsigned short	quad_val;

	for (length = 0, con_seq_ptr = con_left_end->right; con_seq_ptr != con_right_end; con_seq_ptr = con_seq_ptr->right) {
		max = (int)con_seq_ptr->base[DNA_GAP];
		index = DNA_GAP;
		for (i = 0; i < NUM_BASES; i++) {
			if ((int)con_seq_ptr->base[i] > max) {
				max = (int)con_seq_ptr->base[i];
				index = i;
			}
		}
		con_seq_ptr->cons_val = index;
		if (index != DNA_GAP) {
			length++;
		}
	}
	if ((con_values = (char *)malloc((unsigned)((length + 1) * sizeof(*con_values)))) == NULL) {
		fprintf(stderr, "ERROR: Could not allocate memory for con_values\n");
		exit(1);
	}
	for (con_val_ptr = con_values, con_seq_ptr = con_left_end->right; con_seq_ptr != con_right_end; con_seq_ptr = con_seq_ptr->right) {
		if (con_seq_ptr->cons_val != DNA_GAP) {
			*con_val_ptr++ = con_seq_ptr->cons_val;
		}
	}
/* FORWARD STRAND */
	char_ptr = con_values;
	char2_ptr = con_values + HASH_KEY_SIZE;
	for (quad_val = 0, ident1 = 0, ident2 = 0, pos = 0; pos < HASH_KEY_SIZE; pos++, char_ptr++, char2_ptr++) {
		ident1 <<= 2;
		ident1 += ((unsigned)*char_ptr);
		ident2 <<= 2;
		ident2 += ((unsigned)*char2_ptr);
		quad_val <<= 1;
		quad_val += (((unsigned)*char_ptr) >> 1);
	}
	pos += HASH_IDENT_SIZE;
	for (; pos <= length; ident1 <<= 2, ident1 += ((unsigned)*char_ptr), ident2 <<= 2, ident2 += ((unsigned)*char2_ptr), quad_val <<= 1, quad_val += (((unsigned)*char_ptr) >> 1), pos++, char_ptr++, char2_ptr++) {
		for (prev = hash_array + quad_val, next = *prev; (next != NULL) && ((ident2 > next->ident2) || ((ident2 == next->ident2) && (ident1 > next->ident1))); prev = &(next->next_hash), next = *prev);
		if ((next == NULL) || (ident2 != next->ident2) || (ident1 != next->ident1)) {
			*prev = cur = get_32_asm();
			cur->count = 1;
			cur->ident1 = ident1;
			cur->ident2 = ident2;
			cur->next_hash = next;
			next = cur;
		} else {
			(next->count)++;
		}
	}
/* REVERSE STRAND virtually identical code */
	revcomp(con_values, length);
	char_ptr = con_values;
	char2_ptr = con_values + HASH_KEY_SIZE;
	for (quad_val = 0, ident1 = 0, ident2 = 0, pos = 0; pos < HASH_KEY_SIZE; pos++, char_ptr++, char2_ptr++) {
		ident1 <<= 2;
		ident1 += ((unsigned)*char_ptr);
		ident2 <<= 2;
		ident2 += ((unsigned)*char2_ptr);
		quad_val <<= 1;
		quad_val += (((unsigned)*char_ptr) >> 1);
	}
	pos += HASH_IDENT_SIZE;
	for (; pos <= length; ident1 <<= 2, ident1 += ((unsigned)*char_ptr), ident2 <<= 2, ident2 += ((unsigned)*char2_ptr), quad_val <<= 1, quad_val += (((unsigned)*char_ptr) >> 1), pos++, char_ptr++, char2_ptr++) {
		for (prev = hash_array + quad_val, next = *prev; (next != NULL) && ((ident2 > next->ident2) || ((ident2 == next->ident2) && (ident1 > next->ident1))); prev = &(next->next_hash), next = *prev);
		if ((next == NULL) || (ident2 != next->ident2) || (ident1 != next->ident1)) {
			*prev = cur = get_32_asm();
			cur->count = 1;
			cur->ident1 = ident1;
			cur->ident2 = ident2;
			cur->next_hash = next;
			next = cur;
		} else {
			(next->count)++;
		}
	}
	free(con_values);
	return;
}

void
find_asm_32mers(
		ConPos *con_left_end,
		ConPos *con_right_end,
		int asm_num,
		FILE *fp_rep,
		SeqRec *seqrec_array,
		int max_span_len
	)
{
ConPos	*con_seq_ptr;
ConPos	*con_left_ptr, *con_right_ptr, *con_tmp_ptr;
ConPos	*con_stop_left_ptr, *con_stop_right_ptr;
int	length, pos;
int	max, index, i;
char	*con_values, *con_val_ptr;
char	*rep_values, *rep_val_ptr, *rep_val_end;
R32Asm	*next;
char	*char_ptr, *char2_ptr;
unsigned	ident1, ident2;
unsigned short	quad_val;
int	start_repeat, end_repeat;
SeqRec	*seqrec_ptr, *pair_ptr, *tmprec_ptr;
int	left_pos, right_pos, tmp_pos;
char	*rep_start, *rep_stop;
int	forward;
int	init_val;
int	pair_num, seq_dir, pair_dir, clone_len;
int	link_status;
int	realpos;

	for (realpos = 0, length = 0, con_seq_ptr = con_left_end->right; con_seq_ptr != con_right_end; con_seq_ptr = con_seq_ptr->right, realpos++) {
		max = (int)con_seq_ptr->base[DNA_GAP];
		index = DNA_GAP;
		for (i = 0; i < NUM_BASES; i++) {
			if ((int)con_seq_ptr->base[i] > max) {
				max = (int)con_seq_ptr->base[i];
				index = i;
			}
		}
		con_seq_ptr->cons_val = index;
		con_seq_ptr->pos = length;
		con_seq_ptr->realpos = realpos;
		if (index != DNA_GAP) {
			length++;
		}
	}
	con_left_end->pos = 0;
	con_left_end->realpos = 0;
	con_right_end->pos = length;
	con_right_end->realpos = realpos;
	if ((con_values = (char *)malloc((unsigned)((length + 1) * sizeof(*con_values)))) == NULL) {
		fprintf(stderr, "ERROR: Could not allocate memory for con_values\n");
		exit(1);
	}
	if ((rep_values = (char *)malloc((unsigned)((length + 1) * sizeof(*rep_values)))) == NULL) {
		fprintf(stderr, "ERROR: Could not allocate memory for rep_values\n");
		exit(1);
	}
	rep_val_end = rep_values + length;
	for (rep_val_ptr = rep_values, con_val_ptr = con_values, con_seq_ptr = con_left_end->right; con_seq_ptr != con_right_end; con_seq_ptr = con_seq_ptr->right) {
		if (con_seq_ptr->cons_val != DNA_GAP) {
			*con_val_ptr++ = con_seq_ptr->cons_val;
			*rep_val_ptr++ = UNIQUE_32;
		}
	}
/* FORWARD STRAND */
	char_ptr = con_values;
	char2_ptr = con_values + HASH_KEY_SIZE;
	for (quad_val = 0, ident1 = 0, ident2 = 0, pos = 0; pos < HASH_KEY_SIZE; pos++, char_ptr++, char2_ptr++) {
		ident1 <<= 2;
		ident1 += ((unsigned)*char_ptr);
		ident2 <<= 2;
		ident2 += ((unsigned)*char2_ptr);
		quad_val <<= 1;
		quad_val += (((unsigned)*char_ptr) >> 1);
	}
	pos += HASH_IDENT_SIZE;
	for (rep_val_ptr = rep_values; pos <= length; ident1 <<= 2, ident1 += ((unsigned)*char_ptr), ident2 <<= 2, ident2 += ((unsigned)*char2_ptr), quad_val <<= 1, quad_val += (((unsigned)*char_ptr) >> 1), pos++, char_ptr++, char2_ptr++, rep_val_ptr++) {
		for (next = *(hash_array + quad_val); (next != NULL) && ((ident2 > next->ident2) || ((ident2 == next->ident2) && (ident1 > next->ident1))); next = next->next_hash);
		if ((next != NULL) && (next->count > 1)) {
			*rep_val_ptr = REPEAT_32;
		}
	}
	for (rep_val_ptr = rep_values; rep_val_ptr < rep_val_end;) {
		for (; (rep_val_ptr < rep_val_end) && (*rep_val_ptr == UNIQUE_32); rep_val_ptr++);
		if (rep_val_ptr >= rep_val_end) {
			break;
		}
		for (; *rep_val_ptr == REPEAT_32; rep_val_ptr++);
		for (i = 1; i < HASH_IDKEY_SIZE; i++, rep_val_ptr++) {
			if (*rep_val_ptr == REPEAT_32) {
				for (rep_val_ptr++ ; *rep_val_ptr == REPEAT_32; rep_val_ptr++);
				i = 1;
			}
			*rep_val_ptr = REPEAT_32;
		}
	}
	fprintf(fp_rep, "Repeats:\n");
	for (rep_val_ptr = rep_values; (rep_val_ptr < rep_val_end) && (*rep_val_ptr == UNIQUE_32); rep_val_ptr++);
	start_repeat = (rep_val_ptr - rep_values) + 1;
	while (rep_val_ptr < rep_val_end) {
		for (; (rep_val_ptr < rep_val_end) && (*rep_val_ptr == REPEAT_32); rep_val_ptr++);
		end_repeat = (rep_val_ptr - rep_values);
		fprintf(fp_rep, "%d\t%d\t%d\n", asm_num, start_repeat, end_repeat);
		for (; (rep_val_ptr < rep_val_end) && (*rep_val_ptr == UNIQUE_32); rep_val_ptr++);
		start_repeat = (rep_val_ptr - rep_values) + 1;
	}

	for (rep_val_ptr = rep_values, con_seq_ptr = con_left_end->right; con_seq_ptr != con_right_end; con_seq_ptr = con_seq_ptr->right) {
		if (con_seq_ptr->cons_val != DNA_GAP) {
			if (((con_seq_ptr->cons_good < CONS_QUALITY_CUTOFF) || (con_seq_ptr->coverage <= 1)) && (*rep_val_ptr == UNIQUE_32)) {
				*rep_val_ptr = POOR_QUAL_32;
			}
			rep_val_ptr++;
		}
	}

	con_seq_ptr = con_left_end;
	do {
		seqrec_ptr = con_seq_ptr->best_seqrec;
		reset_coords(seqrec_ptr, FALSE);
		con_left_ptr = seqrec_ptr->left;
		con_right_ptr = seqrec_ptr->right;
		left_pos = con_left_ptr->pos;
		right_pos = con_right_ptr->pos;
		if (left_pos > right_pos) {
			tmp_pos = left_pos;
			left_pos = right_pos;
			right_pos = tmp_pos;
			con_tmp_ptr = con_left_ptr;
			con_left_ptr = con_right_ptr;
			con_right_ptr = con_tmp_ptr;
			forward = FALSE;
		} else {
			forward = TRUE;
		}
		if (con_right_ptr->cons_val == DNA_GAP) {
			right_pos--;
		}
		for (rep_start = rep_values + left_pos; con_left_ptr != con_right_ptr; con_left_ptr = con_left_ptr->right) {
			if (con_left_ptr->cons_val == DNA_GAP) {
				continue;
			}
			if (*rep_start++ != UNIQUE_32) {
				continue;
			}
			con_tmp_ptr = con_left_ptr;
			do {
				if (con_tmp_ptr->best_seqrec == seqrec_ptr) {
					break;
				}
				con_tmp_ptr = con_tmp_ptr->best_seg;
			} while (con_tmp_ptr != con_left_ptr);
			init_val = con_tmp_ptr->init_val;
			if (!forward) {
				init_val = trans_comp[init_val];
			}
			if ((con_tmp_ptr->best_seqrec == seqrec_ptr) && (init_val == con_left_ptr->cons_val)) {
				break;
			}
		}
		con_stop_left_ptr = con_left_ptr->left;
		for (rep_stop = rep_values + right_pos; con_stop_left_ptr != con_right_ptr; con_right_ptr = con_right_ptr->left) {
			if (con_right_ptr->cons_val == DNA_GAP) {
				continue;
			}
			if (*rep_stop-- != UNIQUE_32) {
				continue;
			}
			con_tmp_ptr = con_right_ptr;
			do {
				if (con_tmp_ptr->best_seqrec == seqrec_ptr) {
					break;
				}
				con_tmp_ptr = con_tmp_ptr->best_seg;
			} while (con_tmp_ptr != con_right_ptr);
			init_val = con_tmp_ptr->init_val;
			if (!forward) {
				init_val = trans_comp[init_val];
			}
			if ((con_tmp_ptr->best_seqrec == seqrec_ptr) && (init_val == con_right_ptr->cons_val)) {
				break;
			}
		}
		if (con_stop_left_ptr == con_right_ptr) {
			seqrec_ptr->status = REP_CONTAIN;
		}
		for (; rep_start <= rep_stop; rep_start++) {
			if (*rep_start > UNIQUE_32) {
				(*rep_start)++;
			}
		}
		con_seq_ptr = con_seq_ptr->best_seg;
	} while (con_seq_ptr != con_left_end);
	fprintf(fp_rep, "No Sequence Coverage:\n");
	for (rep_val_ptr = rep_values; (rep_val_ptr < rep_val_end) && (*rep_val_ptr != REPEAT_32); rep_val_ptr++);
	start_repeat = (rep_val_ptr - rep_values) + 1;
	while (rep_val_ptr < rep_val_end) {
		for (; (rep_val_ptr < rep_val_end) && (*rep_val_ptr == REPEAT_32); rep_val_ptr++);
		end_repeat = (rep_val_ptr - rep_values);
		fprintf(fp_rep, "%d\t%d\t%d\n", asm_num, start_repeat, end_repeat);
		for (; (rep_val_ptr < rep_val_end) && (*rep_val_ptr != REPEAT_32); rep_val_ptr++);
		start_repeat = (rep_val_ptr - rep_values) + 1;
	}

	con_seq_ptr = con_left_end;
	do {
		seqrec_ptr = con_seq_ptr->best_seqrec;
		seqrec_ptr->link_status = UNLINKED;
		con_seq_ptr = con_seq_ptr->best_seg;
	} while (con_seq_ptr != con_left_end);

	con_seq_ptr = con_left_end;
	do {
		seqrec_ptr = con_seq_ptr->best_seqrec;
		pair_num = seqrec_ptr->pair;
		if (pair_num < 0) {
			seqrec_ptr->link_status = NO_MATE;
		}
		if ((seqrec_ptr->link_status == UNLINKED) && (((pair_ptr = seqrec_array + pair_num)->beg_contig)->latest == con_left_end) && ((seq_dir = IS_FORWARD(seqrec_ptr)) != (pair_dir = IS_FORWARD(pair_ptr)))) {
			if (pair_dir == FORWARD) {
				tmprec_ptr = seqrec_ptr;
				seqrec_ptr = pair_ptr;
				pair_ptr = tmprec_ptr;
			}
			con_left_ptr = seqrec_ptr->left;
			con_right_ptr = pair_ptr->left;
			left_pos = con_left_ptr->pos;
			right_pos = con_right_ptr->pos;
			if (con_right_ptr->cons_val == DNA_GAP) {
				right_pos--;
			}
			clone_len = (right_pos - left_pos) + 1;
			if ((clone_len <= seqrec_ptr->max_len) && (clone_len >= seqrec_ptr->min_len)) {
				link_status = LINKED;
			} else {
				link_status = TRIED;
			}
			seqrec_ptr->link_status = link_status;
			if (pair_ptr->link_status != LINKED) {
				pair_ptr->link_status = link_status;
			}
			if ((link_status == LINKED) && (clone_len <= max_span_len)) {
				con_stop_left_ptr = (seqrec_ptr->right)->right;
				for (rep_start = rep_values + left_pos; con_left_ptr != con_stop_left_ptr; con_left_ptr = con_left_ptr->right) {
					if (con_left_ptr->cons_val == DNA_GAP) {
						continue;
					}
					if (*rep_start++ != UNIQUE_32) {
						continue;
					}
					con_tmp_ptr = con_left_ptr;
					do {
						if (con_tmp_ptr->best_seqrec == seqrec_ptr) {
							break;
						}
						con_tmp_ptr = con_tmp_ptr->best_seg;
					} while (con_tmp_ptr != con_left_ptr);
					init_val = con_tmp_ptr->init_val;
					if ((con_tmp_ptr->best_seqrec == seqrec_ptr) && (init_val == con_left_ptr->cons_val)) {
						break;
					}
				}
				con_stop_right_ptr = (pair_ptr->right)->left;
				for (rep_stop = rep_values + right_pos; con_stop_right_ptr != con_right_ptr; con_right_ptr = con_right_ptr->left) {
					if (con_right_ptr->cons_val == DNA_GAP) {
						continue;
					}
					if (*rep_stop-- != UNIQUE_32) {
						continue;
					}
					con_tmp_ptr = con_right_ptr;
					do {
						if (con_tmp_ptr->best_seqrec == pair_ptr) {
							break;
						}
						con_tmp_ptr = con_tmp_ptr->best_seg;
					} while (con_tmp_ptr != con_right_ptr);
					init_val = trans_comp[con_tmp_ptr->init_val];
					if ((con_tmp_ptr->best_seqrec == pair_ptr) && (init_val == con_right_ptr->cons_val)) {
						break;
					}
				}
				if ((con_left_ptr != con_stop_left_ptr) && (con_stop_right_ptr != con_right_ptr)) {
					for (; rep_start <= rep_stop; rep_start++) {
						if (*rep_start > UNIQUE_32) {
							(*rep_start)++;
						}
					}
				}
			}
		}
		con_seq_ptr = con_seq_ptr->best_seg;
	} while (con_seq_ptr != con_left_end);
	fprintf(fp_rep, "No Clone Coverage:\n");
	for (rep_val_ptr = rep_values; (rep_val_ptr < rep_val_end) && (*rep_val_ptr != REPEAT_32); rep_val_ptr++);
	start_repeat = (rep_val_ptr - rep_values) + 1;
	while (rep_val_ptr < rep_val_end) {
		for (; (rep_val_ptr < rep_val_end) && (*rep_val_ptr == REPEAT_32); rep_val_ptr++);
		end_repeat = (rep_val_ptr - rep_values);
		fprintf(fp_rep, "%d\t%d\t%d\n", asm_num, start_repeat, end_repeat);
		for (; (rep_val_ptr < rep_val_end) && (*rep_val_ptr != REPEAT_32); rep_val_ptr++);
		start_repeat = (rep_val_ptr - rep_values) + 1;
	}
	free(con_values);
	free(rep_values);
	return;
}
