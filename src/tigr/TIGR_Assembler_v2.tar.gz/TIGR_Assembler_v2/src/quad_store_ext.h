/*

Copyright (c) 2003, The Institute for Genomic Research (TIGR), Rockville,
Maryland, U.S.A.  All rights reserved.

*/

#ifndef QUAD_STORE_EXT_H
#define QUAD_STORE_EXT_H

extern void		init_quad_store	(register int);
extern QuadHash*	get_quad	();
extern QuadHash*	get_quad_store	();
extern void		free_quad_store ();

#endif
