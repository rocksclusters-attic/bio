/*

Copyright (c) 2003, The Institute for Genomic Research (TIGR), Rockville,
Maryland, U.S.A.  All rights reserved.

*/

#include "typedefs.h"
#include "matrices.h"

#ifndef RELINK_EXT_H
#define RELINK_EXT_H

void	relink	(SeqRec *, SeqRec *);

#endif

