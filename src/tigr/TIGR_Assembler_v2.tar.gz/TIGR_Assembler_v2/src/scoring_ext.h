/*

Copyright (c) 2003, The Institute for Genomic Research (TIGR), Rockville,
Maryland, U.S.A.  All rights reserved.

*/

#include <stdio.h>
#include "typedefs.h"
#include "matrices.h"

#ifndef SCORING_EXT_H
#define SCORING_EXT_H

extern void	initHisto		(int *);
extern void	graphRecordCounts	(int *, int *, R32Hash **, R32Hash **);
extern void	computeRecordStats	(int *, int *, int *, int *, int *, int *, int *,
					 int *, int *, int *, int *, int *, int *);
extern void	computeRecordScores	(R32Hash **, R32Hash **, int, int, int, int, int, int,
					 int, int, int, int);
extern void	computePairRecords	(SeqRec *, int, int, int, R32Hash **, int, FILE *);
extern void	graphSequenceLengths	(int *, SeqRec *, int);
extern void	computeSequenceStats	(int *, SeqRec *, int, int *, int *, int *, int *, int);
extern void	normalizeSequences	(SeqRec *, int, int, int);
extern void	orderByFile		(SeqRec *, int, FILE *);
extern void	orderScoreRecords	(SeqRec *, int, int, int, int, AbScoreRec **, AbScoreRec **, AbScoreRec ***);
extern void	printScoreOrder		(SeqRec *, int, AbScoreRec **, AbScoreRec **, char *);
extern void	resort_scores		(register AbScoreRec **, register AbScoreRec **, register SeqRec *);

#endif
