/*

Copyright (c) 2003, The Institute for Genomic Research (TIGR), Rockville,
Maryland, U.S.A.  All rights reserved.

*/

#include "quad_store_prot.h"

void
init_quad_store(
		register int size
	)
{

	if (size && ((free_ptr = (QuadHash *)malloc((unsigned)(size * sizeof(*free_ptr)))) == NULL)) {
		fprintf(stderr, "ERROR: Could not allocate memory for hash records\n");
		exit(1);
	}
	store = free_ptr;
	left = size;
#ifdef DEBUG
	fprintf(stderr, "init_quad_store: left = %d\n", left);
	fflush(stderr);
#endif
	return;
}


QuadHash *
get_quad()
{
register QuadHash	*ptr;

	ptr = free_ptr;
	if (!left) {
		fprintf(stderr, "ERROR: Ran out of hash records - left = %d\n", left);
		exit(1);
	}
	free_ptr++;
	left--;
	return(ptr);
}

QuadHash *
get_quad_store()
{
	return store;
}

void
free_quad_store()
{
	free(store);
	return;
}
