/*

Copyright (c) 2003, The Institute for Genomic Research (TIGR), Rockville,
Maryland, U.S.A.  All rights reserved.

*/

#include "typedefs.h"

#ifndef __32_STORE_EXT_H
#define __32_STORE_EXT_H

#define MY_BLOCK	1024

extern void	init_32_store	(register int);
extern void	re_init_32_store(register int);
extern R32Hash*	get_32		();
extern R32Hash*	get_32_store	();
extern void	free_32_store	();

#endif
