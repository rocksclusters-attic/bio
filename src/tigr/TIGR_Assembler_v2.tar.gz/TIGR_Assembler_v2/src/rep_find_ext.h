/*

Copyright (c) 2003, The Institute for Genomic Research (TIGR), Rockville,
Maryland, U.S.A.  All rights reserved.

*/

#include <stdio.h>
#include "typedefs.h"
#include "matrices.h"

#ifndef REP_FIND_EXT_H
#define REP_FIND_EXT_H

extern void	init_asm_32mers		(register int);
extern void	re_init_asm_32mers	(register int);
extern R32Asm*	get_32_asm		();
extern void	free_32_store_asm	();
extern void	load_asm_32mers		(ConPos *, ConPos *);
extern void	find_asm_32mers		(ConPos *, ConPos *, int, FILE *, SeqRec *, int);

#endif
